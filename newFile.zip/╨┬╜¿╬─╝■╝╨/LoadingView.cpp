﻿#include "LoadingView.h"
#include <unordered_set>
#include "CommonUI/Layout.h"
#include "ui/UILayout.h"
#include "ui/UILoadingBar.h"
#include "CommonUI/Bar.h"
#include "CommonUI/Image.h"
#include "CommonUI/Label.h"
#include "util/PanelUtil.h"
/*#include "ui/UIText.h"
#include "widget/CCNumber.h"*/
#include "base/UIConst.h"
#include "ui/UIText.h"
#include "base/EventDispatcher.h"
#include "base/InternalEvent.h"
#include "util/BattleSceneTemplateUtil.h"
#include "util/view_util.h"
#include "util/PanelUtil.h"
#include "util/MathUtil.h"
#include "util/SystemCfgUtil.h"
#include "util/GeneralCfgUtil.h"
#include "util/GeneralUtil.h"
#include "util/str_util.h"
#include "util/ActionRunner.h"
#include "util/LuaLogicUtil.h"
#include "protocol/mh_const.h"

#include "model/ResourceModel.h"
#include "battle/BattleScene.h"
#include "model/GamePvp.h"
#include "model/GameGeneralManager.h"
#include "battle/BattleTroopSet.h"

#include "model/GameSoldierManager.h"

#include "view/GeneralView.h"
#include "view/MainScene.h"
#include "configure/StringConfigure.h"
#include "configure/TextConfigure.h"
#include "configure/PassConfigure.h"

#include "configure/SoldierConfigure.h"
#include "configure/MonsterSoldierConfigure.h"

#include "configure/SkillConfigure.h"
#include "configure/GenGeneralPointConfigure.h"
#include "configure/GenGeneralPointActionConfigure.h"
#include "configure/EffectRotateConfigure.h"
#include "configure/SoldierCommonConfigure.h"

#include "configure/EffectUiConfigure.h"
#include "configure/TroopConfigure.h"
#include "xmlconfig/TerrainConfigure.h"
#include "xmlconfig/IntervalConfigure.h"
#include "xmlconfig/BattleSceneConfigure.h"
#include "spine/SkeletonAnimation.h"
#include "Classes/UpdateManager.h"

#include "cocos/editor-support/cocostudio/ActionTimeline/CSLoader.h"
#include "cocos/ui/UIText.h"

using namespace cocos2d;
using namespace std::placeholders;
using namespace spine;

LoadingView::LoadingView(int touchPriority, int type) 
	: m_touchPriority(touchPriority)
	, m_type(type)
	, m_bar(nullptr)
	, m_loadedResNum(0)
	, m_totalResNum(0)
	, m_runner(nullptr)
	, m_cloud1(nullptr)
	, m_cloud2(nullptr)
	, m_pureResNum(0)
	, m_curPreCalNum(0)
	, m_preCalNum(0)
{
	m_runner = ActionRunner::create();
	m_runner->retain();
}

LoadingView::~LoadingView()
{
	m_runner->clear();
	m_runner->release();
}

void LoadingView::onEnter()
{
	Node::onEnter();
	Director::getInstance()->getEventDispatcher()->addCustomEventListener("loadSoldier", std::bind(&LoadingView::loadingCallBack, this, 1, false));
	////CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, m_touchPriority, true);
}

void LoadingView::onExit()
{
	Node::onExit();
	Director::getInstance()->getEventDispatcher()->removeCustomEventListeners("loadSoldier");
	////CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);
}

void LoadingView::remove()
{
	removeFromParent();
	MainScene::theScene()->setLoadingView(nullptr);
}

void LoadingView::runFinishedAction()
{
	if (Director::getInstance()->getIsRender())
	{
		if (m_type == kBattleBegin)
		{
			m_cloud1->removeFromParent();
			spine::SkeletonAnimation *cloud2 = SkeletonAnimation::createWithFile(EFFECTUI_JSON(3), EFFECTUI_ATLAS(3));
			Size winSize = Director::getInstance()->getWinSize();
			cloud2->setPosition(ccp(winSize.width / 2, winSize.height / 2));
			cloud2->setAnimation(0, EFFECTUI_NAME(3), false);
			MainScene::theScene()->addChild(cloud2, 9999);
			cloud2->setEndListener([=](int){cloud2->setVisible(false); });
			
			//CCProgressTo *to = CCProgressTo::create(0.2f, 100.0f);
			//CCTargetedAction *toTarget = CCTargetedAction::create(m_bar->getTimer(), to);
			m_loadingBar->setPercent(100);

			CCCallFunc *func = CCCallFunc::create(this, callfunc_selector(LoadingView::remove));
			//CCSequence *seq = CCSequence::create(toTarget, func, nullptr);
			CCSequence *seq = CCSequence::create(func, nullptr);
			runAction(seq);
		}
		else
		{
			remove();
		}
	}
	else
	{
		CCCallFunc *func = CCCallFunc::create(this, callfunc_selector(LoadingView::remove));
		runAction(func);
	}

	BattleScene::getCurrentScene()->setIsRealStart(true);
	//BattleScene::getCurrentScene()->getTroopSet(kEnemyParty)->initTargetTroop();
	//BattleScene::getCurrentScene()->troopRunOutDoor();
	
}

bool LoadingView::init()
{
	if (Director::getInstance()->getIsRender())
	{
		Size winSize = Director::getInstance()->getWinSize();
		m_cloud1 = SkeletonAnimation::createWithFile(EFFECTUI_JSON(2), EFFECTUI_ATLAS(2));
		m_cloud1->setPosition(ccp(winSize.width / 2, winSize.height / 2));
		m_cloud1->setAnimation(0, EFFECTUI_NAME(2), false);
		//m_cloud1->setVisible(false);
		addChild(m_cloud1, 1);

		Node *skin = CSLoader::createNode("ccs/csb/loadingScence/loadingScence.csb");
		skin->setPosition(ccp(0, 0));
		addChild(skin, 2);

		setContentSize(winSize);
		skin->getChildByName("bg")->setVisible(false);
		m_loadingLabel = dynamic_cast<cocos2d::ui::Text*>(skin->getChildByName("bar")->getChildByName("loadingInfoText"));
		m_loadingLabel->setColor(ccc3(80, 80, 80));

		skin->getChildByName("newsTips")->setColor(ccc3(80, 80, 80));
		m_loadingBar = dynamic_cast<cocos2d::ui::LoadingBar*>(skin->getChildByName("bar")->getChildByName("loadingBar"));
		m_loadingBar->setPercent(0.0f);

		cocos2d::ui::Text *verTxt = dynamic_cast<cocos2d::ui::Text*>(skin->getChildByName("versionText"));
		std::string version = UpdateManager::theManager()->getClientVersion();
		char buf[128];
		snprintf(buf, sizeof(buf), "%s:", LuaLogicUtil::stringValue("version_loading_scene"));
		verTxt->setString(string(buf) + version);
		/*
		std::string src("");
		if (m_type == kBattleBegin) src = std::string("res/battleScence/login_loading3.xml");
		else src = std::string("res/battleScence/login_loading4.xml");

		m_layout = xyui::Layout::create(src.c_str());
		m_layout->setAnchorPoint(ccp(0, 0));
		m_layout->setPosition(ccp(0, 0));
		setContentSize(m_layout->getContentSize());

		
		addChild(m_layout, 2);

		xyui::Image* bg = dynamic_cast<xyui::Image*>(m_layout->getChildById(1));
		fixScreenSize(bg, m_layout);
		bg->setVisible(false);

		xyui::Label *percent = dynamic_cast<xyui::Label *>(m_layout->getChildById(12));
		percent->setString("0%");

		m_bar = dynamic_cast<xyui::Bar *>(m_layout->getChildById(10));
		m_bar->setCursor(xyui::Bar::kLoadingCursor);

		if (m_type == kBattleBegin)
		{
			xyui::Label *tipsLb = dynamic_cast<xyui::Label *>(m_layout->getChildById(14));
			const vector<int> &tips = system_cfg::getSysTips("loading_text");
			int index = getRandNum(0, tips.size() - 1);
			tipsLb->setString(TEXT_ZHCHS(tips[index]));
		}*/
		if (m_type == kBattleBegin)
		{
			m_tipLabel = dynamic_cast<cocos2d::ui::Text*>(skin->getChildByName("tipsText"));
			const vector<int> &tips = system_cfg::getSysTips("loading_text");
			int index = getRandNum(0, tips.size() - 1);
			m_tipLabel->setString(TEXT_ZHCHS(tips[index]));
			m_tipLabel->setColor(ccc3(80, 80, 80));
		}
	}
	
	
	return true;
}

void LoadingView::generalCard()
{
}

void LoadingView::setProgressPercentage(float percent, bool isUpdateTip)
{
	if (Director::getInstance()->getIsRender())
	{
		if (isUpdateTip)
		{
			char str[128];
			snprintf(str, sizeof(str), "%d%s", static_cast<int>(percent), "%");
			//xyui::Label *percent = dynamic_cast<xyui::Label *>(m_layout->getChildById(12));
			//percent->setString(str);
			m_loadingLabel->setString(str);
			m_loadingBar->setPercent(percent);
		}

		//m_bar->reset(percent, 100.0f);
	}	

}

void LoadingView::setTip(const char *text)
{
	/*cocos2d::Label *percent = dynamic_cast<cocos2d::Label *>(m_layout->getChildById(12));
	if (m_type == kBattleBegin)
	{
		cocos2d::Label *tips = dynamic_cast<cocos2d::Label *>(m_layout->getChildById(11));
		tips->setString(text);
		percent->setPositionX(tips->getPositionX() + tips->getContentSize().width/2 + percent->getContentSize().width);
	}*/
}

LoadingView *LoadingView::create(int touchPriority, int type)
{
	LoadingView *lv = new LoadingView(touchPriority, type);
	lv->init();
	lv->autorelease();

	return lv;
}

static int preLoadMonsterGeneralNum = 0;

static void getSkillEffectRes(int skillId, std::vector<std::string> *paths)
{
	const char *effects[] =
	{
		SKILL_PRE_ATTACK_EFFECT(skillId),
		SKILL_ATTACK_EFFECT(skillId),
		SKILL_HIT_EFFECT_RES(skillId),
	};

	for (int i = 0; i < 3; ++i)
	{
		std::vector<std::string> effectVec = split(effects[i], ";");
		if (!effectVec.empty())
		{
			for (size_t j = 0; j < effectVec.size(); ++j)
			{
				if (effectVec[j].find("custom") != std::string::npos)
				{
					std::string str = getCustomEffectRes(effectVec[j].c_str());
					if (!str.empty()) paths->push_back(str + ".pvr.ccz");
				}
				else
				{
					if (effectVec[j] == "nil") continue;
					if(EFFECTROTATE_MULTI_DIR(effectVec[j].c_str()))
					{
						std::string str = std::string(effectVec[j]) + "/right_up.pvr.ccz";
						paths->push_back(str.c_str());

						str = std::string(effectVec[j]) + "/right_down.pvr.ccz";
						paths->push_back(str.c_str());
					}
					else
					{
						std::string str = std::string(effectVec[j]) + ".pvr.ccz";
						paths->push_back(str.c_str());
					}
				}
			}

		}
	}

	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillId));
	std::vector<std::string> skillEffectVec = split(effectStr, ";");
	if (!skillEffectVec.empty())
	{
		for (size_t i = 0; i < skillEffectVec.size(); ++i)
		{
			if (skillEffectVec[i] == "nil") continue;
			std::vector<std::string> subVec = split(skillEffectVec[i], ",");
			for (size_t j = 0; j < subVec.size(); ++j)
			{
				if (subVec[j].find("custom") != std::string::npos)
				{
					std::string str = getCustomEffectRes(subVec[j].c_str());
					if (!str.empty()) paths->push_back(str + ".pvr.ccz");
				}
				else
				{
					paths->push_back(subVec[j] + ".pvr.ccz");
				}
			}
		}
	}
}

static void getGenGeneralPointInfos(int GenGeneralPointId, std::vector<int> *generalTids)
{
	std::vector<int> genGeneralActionVec = GENGENERALPOINT_ACTION(GenGeneralPointId);
	for (size_t i = 0; i < genGeneralActionVec.size(); ++i)
	{
		std::vector<const char *> generalVec = GENGENERALPOINTACTION_GENERAL_ID(genGeneralActionVec[i]);
		for (size_t j = 0; j < generalVec.size(); ++j)
		{
			std::vector<std::string> generals = split(generalVec[j], ",");
			for (size_t k = 0; k < generals.size(); ++k)
			{
				generalTids->push_back(atoi(generals[k].c_str()));
			}
		}
	}
}

static void getAniFiles(unordered_set<string, hash<string>, StringEqualFn> *files, int tid, bool isMonster, bool isGeneral)
{
	string preStr, file;

	int skillId = 0;
	if (isMonster)
	{
		preStr = std::string(SOLDIERCOMMON_CHARACTER_ENEMY(MONSTERSOLDIER_COMMON_ID(tid))) + "/";
		if (preStr == "/")
		{
			preStr = std::string(SOLDIERCOMMON_CHARACTER_FRIEND(MONSTERSOLDIER_COMMON_ID(tid))) + "/";
		}
	}
	else
		preStr = std::string(SOLDIERCOMMON_CHARACTER_FRIEND(SOLDIER_COMMON_ID(tid))) + "/";

	std::string fullPath = FileUtils::getInstance()->fullPathForFilename(preStr + "idle_left_down.plist");
	if (fullPath.size() == 0)
	{
		// return if plist file doesn't exist
		CCLOG("can not find path %s,use Default", preStr.c_str());
		preStr = "res/model/soldier/30002/";
	}


	// 怪物方武将不预加载技能特效
	if (skillId != 0 && !isMonster)
	{
		std::vector<std::string> skillEffects;
		getSkillEffectRes(skillId, &skillEffects);
		for (size_t i = 0; i < skillEffects.size(); ++i)
		{
			files->insert(skillEffects[i].c_str());
		}
	}

	// 玩家方武将不预加载动作
	if(!isMonster && isGeneral)
	{
		return;
	}

// 	if(preLoadMonsterGeneralNum == 6)
// 	{
// 		return;
// 	}

	preLoadMonsterGeneralNum++;
	INFO_MSG("preLoadMonsterGeneralNum=%d", preLoadMonsterGeneralNum);

	int i = 0;
	bool isExist = false;
	while(true)
	{
		file = preStr + string(resource::aniNames[i]);

		if(i % resource::kAniDirNum == 0)
		{
			int stateIndex = i / resource::kAniDirNum;
			isExist = isAniFileExist(file + ".pvr.ccz", stateIndex);
		}

		if(isExist)
		{
			files->insert(file + ".pvr.ccz");
		}

		i++;
		if(i >= resource::kAniNum) break;
	}
}

static void getGenGeneralPointAniFiles(unordered_set<string, hash<string>, StringEqualFn> *files, int GenGeneralPointId)
{
	std::vector<int> generals;
	getGenGeneralPointInfos(GenGeneralPointId, &generals);
	for (size_t i = 0; i < generals.size(); ++i)
	{
		getAniFiles(files, generals[i], true, true);
	}
}

static void getSceneAniFiles(unordered_set<string, hash<string>, StringEqualFn> *files, const BattleSceneProperty &scenePty)
{
	unordered_set<int>::const_iterator iter = scenePty.enemy_general_tids.begin();
	for (; iter != scenePty.enemy_general_tids.end(); ++iter)
	{
		getAniFiles(files, *iter, true, true);
	}

	iter = scenePty.enemy_soldier_tids.begin();
	for (; iter != scenePty.enemy_soldier_tids.end(); ++iter)
	{
		getAniFiles(files, *iter, true, false);
	}

	iter = scenePty.enemy_gen_troop_point_tids.begin();
	for (; iter != scenePty.enemy_gen_troop_point_tids.end(); ++iter)
	{
		getGenGeneralPointAniFiles(files, *iter);
	}
	iter = scenePty.friend_gen_troop_point_tids.begin();
	for (; iter != scenePty.friend_gen_troop_point_tids.end(); ++iter)
	{
		getGenGeneralPointAniFiles(files, *iter);
	}
}

static void getResFiles(unordered_set<string, hash<string>, StringEqualFn> *files, int sceneId)
{
	preLoadMonsterGeneralNum = 0;

	const BattleSceneProperty &scenePty = getBattleScene(sceneId);
	getSceneAniFiles(files, scenePty);

	if (isInThisBattleMode(MainScene::kBattlePVP) || isInThisBattleMode(MainScene::kBattlePass))
	{
		std::map<int, int> friendSoldier = LuaLogicVariable::theMgr()->getFriendSoldierIds();
		for (auto iter = friendSoldier.begin(); iter != friendSoldier.end(); ++iter)
		{
			int tid = iter->first;
			getAniFiles(files, tid, false, false);
		}
	}

	DefendArmy enemyArmy;
	if (isInThisBattleMode(MainScene::kBattlePVP))
	{
		std::map<int, int> enemySoldier = LuaLogicVariable::theMgr()->getEnemySoldierIds();
		for (auto iter = enemySoldier.begin(); iter != enemySoldier.end(); ++iter)
		{
			int tid = iter->first;
			getAniFiles(files, tid, false, false);
		}
	}
	
	char str[128];
	char resStr[256] = { 0 };
	bool isHave = false;
	
	const BattleMapProperty &mapPty = getBattleMap(scenePty.mapId);
	const TerrainProperty &terrainPty = getTerrainProperty(mapPty.path);
	for (int i = 0; i <= terrainPty.rightX; ++i)
	{
		for (int j = 0; j <= terrainPty.upY; ++j)
		{
			snprintf(str, sizeof(str), "%d,%d", i, j);
			if (std::find(terrainPty.pngBlocks.begin(), terrainPty.pngBlocks.end(), std::string(str)) != terrainPty.pngBlocks.end())
			{
				if(terrainPty.isPvr)
				{
					snprintf(resStr, sizeof(resStr), "%s/%d_%d.pvr.ccz", mapPty.path.c_str(), i, j);
				}
				else
				{
					snprintf(resStr, sizeof(resStr), "%s/%d_%d.png", mapPty.path.c_str(), i, j);
				}
				
				isHave = true;
			}
			else if (std::find(terrainPty.noneBlocks.begin(), terrainPty.noneBlocks.end(), std::string(str)) == terrainPty.noneBlocks.end())
			{
				if(terrainPty.isPvr)
				{
					snprintf(resStr, sizeof(resStr), "%s/%d_%d.pvr.ccz", mapPty.path.c_str(), i, j);
				}
				else
				{
					snprintf(resStr, sizeof(resStr), "%s/%d_%d.jpg", mapPty.path.c_str(), i, j);
				}
				
				isHave = true;
			}
			else
			{
				isHave = false;
			}

			if (isHave)
			{
				files->insert(resStr);
			}
		}
	}

	files->insert(resource::kScreenMaskName);
}
static int getSceneTroopSoldiers(int sceneId)
{
	int num = 0;
	const BattleSceneProperty &scenePty = getBattleScene(sceneId);

	std::vector<TroopInfoData> friendTroops = scenePty.friend_troops;
	for (auto it = friendTroops.begin(); it != friendTroops.end(); ++it)
	{
		num++;
	}

	std::vector<TroopInfoData> enemyTroops = scenePty.enemy_troops;
	for (auto it = enemyTroops.begin(); it != enemyTroops.end(); ++it)
	{
		num++;
	}
	return num;
}
void LoadingView::loadBattleRes(int sceneId)
{
	int sceneSoldiers = getSceneTroopSoldiers(sceneId);
	int soldiers = LuaLogicUtil::getNeedCreateTroopSoldiers();

	int battleType = MainScene::theScene()->getBattleType();
	if (battleType == MainScene::kBattleMagic || battleType == MainScene::kBattleElementStrom)
	{
		m_totalResNum = (sceneSoldiers + soldiers) * 10 * 2;
		m_preCalNum = kPreCalNum;
		m_totalResNum += m_preCalNum;
	}
	else
	{
		m_totalResNum = (sceneSoldiers + soldiers) * 10;
		m_preCalNum = 0;
	}

	unordered_set<string, hash<string>, StringEqualFn> files;
	getResFiles(&files, sceneId);
	m_pureResNum = files.size();
	m_totalResNum += m_pureResNum;
	m_loadedResNum = 0;

	unordered_set<string, hash<string>, StringEqualFn>::iterator iter = files.begin();
	for(; iter != files.end(); ++iter)
	{
		if (Director::getInstance()->getIsRender())
		{
			CCTextureCache::sharedTextureCache()->addImageAsync((*iter).c_str(), std::bind(&LoadingView::loadingCallBack, this, 1, false));
		}
		else
		{
			loadingCallBack();
		}
		
	}
}

void LoadingView::loadMainSceneRes()
{
	unordered_set<string, hash<string>, StringEqualFn> files;
	std::vector<std::string> paths = getBackgroundPath(MAIN_UI_FOREGROUND_NAME);
	for (size_t i = 0; i < paths.size(); ++i)
	{
		files.insert(paths[i]);
	}

	paths = getBackgroundPath(MAIN_UI_BACKGROUND_NAME);
	for (size_t i = 0; i < paths.size(); ++i)
	{
		files.insert(paths[i]);
	}

	m_totalResNum = files.size();
	m_loadedResNum = 0;

	unordered_set<string, hash<string>, StringEqualFn>::iterator iter = files.begin();
	for(; iter != files.end(); ++iter)
	{
		
		if(Director::getInstance()->getIsRender())
		{
			CCTextureCache::sharedTextureCache()->addImageAsync((*iter).c_str(), std::bind(&LoadingView::loadingCallBack, this, 1, false));
		}
		else
		{
			loadingCallBack();
		}
	}
}



void LoadingView::loadingCallBack(int num, bool isPreCalLoad)
{
	if (isPreCalLoad)
	{
		int tmp = m_curPreCalNum + num;
		if (tmp > m_preCalNum)
		{
			m_loadedResNum = m_loadedResNum + num - (tmp - m_preCalNum);
			m_curPreCalNum = m_preCalNum;
		}
		else
		{
			m_loadedResNum += num;
			m_curPreCalNum += num;
		}
	}
	else
	{
		m_loadedResNum += num;
	}
	if (m_type == kBattleBegin)
	{
		int soldierNum = m_totalResNum - m_pureResNum - m_preCalNum;
		int realTotalNum = m_pureResNum + soldierNum * 10 + m_preCalNum;
		if (m_loadedResNum <= m_pureResNum)
		{
			setProgressPercentage(m_loadedResNum / (float)realTotalNum * 100.0f);
		}
		else
		{
			int loadedSoldierNum = m_loadedResNum - m_pureResNum - m_curPreCalNum;
			if (m_preCalNum > 0)
			{
				setProgressPercentage((m_pureResNum + loadedSoldierNum * 10 + m_curPreCalNum) / (float)realTotalNum * 100.0f);
			}
			else
			{
				setProgressPercentage((m_pureResNum + loadedSoldierNum * 10) / (float)realTotalNum * 100.0f);
			}
			
		}
		
	}

	if (m_loadedResNum == m_pureResNum)
	{
		m_runner->queueAction(DelayNFrames::delay(1));
		m_runner->queueAction(CallFuncAction::withFunctor([=](void) ->void { if (m_func) m_func(); }));
	}
	//CCLOG("m_loadedResNum:%d m_totalResNum:%d", m_loadedResNum, m_totalResNum);
	
	if (m_preCalNum > 0)
	{
		int soldierNum = m_totalResNum - m_pureResNum - m_preCalNum;
		if (m_loadedResNum == m_totalResNum - soldierNum / 2 - m_preCalNum)   //开始预计算战斗
		{
			m_runner->queueAction(DelayNFrames::delay(1));
			m_runner->queueAction(CallFuncAction::withFunctor([=](){BattleScene::getCurrentScene()->setIsRealStart(true); }));
		}
	}
	if (m_loadedResNum == m_totalResNum)
	{
		if (m_type == kBattleBegin)
		{
			m_runner->queueAction(CallFuncAction::withFunctor(std::bind(&LoadingView::setTip, this, STRING_ZHCHS("loading_init_friend_troop"))));	
		}
		m_runner->queueAction(DelayNFrames::delay(1));
		m_runner->queueAction(CallFuncAction::withFunctor(std::bind(&LoadingView::runFinishedAction, this)));
	}
}
