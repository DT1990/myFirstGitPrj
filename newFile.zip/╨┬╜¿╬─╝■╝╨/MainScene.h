﻿#ifndef DREAM_VIEW_MAIN_SCENE_H__
#define DREAM_VIEW_MAIN_SCENE_H__

#include <cocos2d.h>
#include "protocol/mh_protocol.h"
#include "util/PanelUtil.h"

class ActionRunner;
class ChatPanel;
class UILayer;
class LoadingView;
class CCActionPanel;

class MainScene : public cocos2d::CCScene
{
public:
    static const int kTagBattleClosePanel;
    static MainScene *create();
    static MainScene *theScene() { return s_theScene; }

	static void  resetScene();
    
    virtual void onExit();

	int getCurPanelId();
	void addUIWidget(cocos2d::Node *node, int zOrder, bool closeBehind);
	bool removeUIWidget(CCActionPanel *panel);
	bool isUIWidgetEmpty() const { return m_uiWidgets.empty(); }
	void backUIWidget(int layer, bool showEachUi = true);

	void backOrCloseUIWidget();
	void updatePanelRecord(const PanelRecord &record, int index);
	void removePanelRecord(const PanelRecord &record);
	bool isPanelRecordEmpty() { return m_panelRecords.empty(); }
	const std::deque<PanelRecord> &getPanelRecord() { return m_panelRecords; }

	void addAnnouncement(cocos2d::Node *node);
	void setTip(cocos2d::Node *node, int tipType);
	void addNoTouchLayer();
	void removeNoTouchLayer();
	void addUiBg(const cocos2d::Size &size);
	void removeUiBg();
	bool isPanelSame(int panelId, int usage);

    virtual void update(float dt);
	virtual bool init();

	int getPlotPassId() const { return 9005; }
	void changeScene(int sceneType, cocos2d::Node *sceneNode);
	int getCurSceneType() const { return m_currentSceneType; }
	cocos2d::Node *getCurrentSceneView(){ return m_sceneView; }
	UILayer *getUiLayer(){ return m_uiLayer; }
	void challengeDungeonReward();
	void battleEnd();
	void reEnterBattle();
	int getBattleMode() const { return m_battleMode; }
	int getBattleType() const { return m_battleType; }
	bool isGm() const { return m_isGm; }
	void setIsGm(bool isGm) { m_isGm = isGm; }

	void updateDistantScenePosition(const cocos2d::CCPoint &offset);

	bool isReplay() const { return m_isReplay; }

	bool isShowPass() const { return m_isShowPass; }

	const std::vector<ItemInfo> &getPassDropOut() const { return m_passDropOut; }

	void battleBegin(int battleMode,int battleType);

	LoadingView* getLoadingView() { return m_loadingView;  }
	void setLoadingView(LoadingView* lv){ m_loadingView = lv; }

	ActionRunner *getRunner(){ return m_runner;  }
public:
	enum
	{
		kMainScene = 0,
		kBattleScene,
	};

	enum BattleMode
	{
		kBattlePass = 1,
		kBattlePVP,
		kBattleDungeonRes,					// 资源副本（多多益善）;
		kBattleDungeonEquipment,			// 讨伐群雄;
		kBattleDungeonReward,				// 军团悬赏副本;
		kBattleArena,
		kBattleCrusade,
		kBattleCrusadeSpecial,
		kBattlePlot,
		kBattleDungeonTraining,				//练兵副本
		kBattleDungeonGroup,				//组合副本
		kBattleDungeonGuild,				//公会副本
	};

	enum  BattleType
	{
		kBattleNormal = 1,		//正常的PVE和PVP
		kBattleAttackCity,		//攻城战
		kBattleMagic,			//魔法门关卡战
		kBattleElementStrom,	//元素风暴副本
		kDemoBattle				//演示关卡
	};

private:
    MainScene();
	~MainScene();

	
	void onBtnGMClicked();
	void createBattleView();
	void onChallengePassReply(int cmd, void *buf, int len, int passId);
	void onChallengePveReply(int cmd, void *buf, int len, int passId);
	void onChallengeTrainingReply(int cmd, void *buf, int len, int passId);
	void onChallengeDungeonEquipmentReply(int cmd, void *buf, int len);
	void onChallengeArenaCompetitorReply(int retCode);

private:
    static const int kZOrderLoadingLayer = 10;
    static const int kZOrderNotifyLayer = 7;
    static const int kZOrderBattleView = 5;
	static const int kZOrderUIView = 2;
	static const int kZOrderSceneView = 0;

    static MainScene *s_theScene;
	UILayer *m_uiLayer;
	cocos2d::Node *m_notifyLayer;
	cocos2d::Node *m_sceneView;
	cocos2d::Node *m_sceneDistant; // 战斗地图的远景层;
    ActionRunner *m_runner;
	int m_currentSceneType;
	std::vector<cocos2d::Node *> m_uiWidgets;
	int m_battleMode;
	int m_battleType;
	bool m_isGm;
	int m_eventId;
	std::deque<PanelRecord> m_panelRecords;

	bool m_isReplay;

	bool m_isShowPass;

	static const int kNoTouchTag = -100;
	static const int kBgTag = -101;

	int m_memoryWarningId;
	std::vector<ItemInfo> m_passDropOut;

	LoadingView *m_loadingView;
	
	CC_SYNTHESIZE(int, m_curPassId, CurPassId);
	
	CC_SYNTHESIZE(bool, m_isPreCalReady, IsPreCalReady);
};

class BattleSceneLuaHelper
{
public:
	
public:
	static BattleSceneLuaHelper *theHelper()
	{
		static BattleSceneLuaHelper helper;
		return &helper;
	}
	void battleBegin(int battleType, int passId);
	void setLogLvl(int level);

private:
	BattleSceneLuaHelper();
	~BattleSceneLuaHelper();
};

#endif
