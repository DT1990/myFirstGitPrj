module(..., package.seeall)

require 'UIMgr.Define'
prototype = Dialog.prototype:extend()

function prototype:initialize(...)
	super.initialize(self, ...)
end

function prototype:dispose()
    if self.mainCityScene then
        self.mainCityScene:exitScene(true)
        self.mainCityScene = nil
    end

    super.dispose(self)
end

function prototype:hasMaskBg()
	return false
end

function prototype:enter()
    self:switch('MAIN_CITY')

    -- 初始化喇叭
    self:initHornUI()
end

function prototype:isSceneType(sceneType)
    if self.preBattleScene then
        return 'BATTLE' == sceneType
    end

    return self.sceneType == sceneType
end

function prototype:createMainCity()
    if not self.mainCityScene then
        self.mainCityScene = require('maincity_scene.maincity_scene').new()
        self.mainCityScene:retain()
    end

    return self.mainCityScene
end

function prototype:switch(sceneType, data)
    local SWITCH = {
        MAIN_CITY   = bind(self.switchToMainCity, self),
        WILD_MAP    = bind(self.switchToWildmap, self),
        DUPLICATE   = bind(self.switchToDuplicate, self),
    }

    if not SWITCH[sceneType] then
        log4ui:warn('error fo switch to %s', sceneType)
        return
    end

    SWITCH[sceneType](data)
end

function prototype:switchToMainCity(data)
    sdk_android_util.startGameScence()

    if self.sceneType ~= 'WILD_MAP' then
        self:switchScene('MAIN_CITY', data)
        return
    end

    local callback = function()
        self:switchScene('MAIN_CITY', data)
        Game:enterCityAction()
    end
    Game:leaveCityOrMapAction(callback)

    -- 重新进入主场景刷新某些UI
    self.mainCityScene:refreshAfterLeaveMapEnterMaincity()
end

function prototype:switchToWildmap(data)
    if Game:get('roleCom'):getLv() < 10 then
        Game.tipMsg(stringConfigCom.content("map_cannot_enter_because_lv"))
        return
    end

    local data = data
    if data == nil then
        data = {}
    end
    self.onSwitchToWildmapQuery = function(self, ...)
        self:onQueryMapInfo(data, ...)
    end

	local REQUES_LIST = {
        {13018,     Game.mapDB.send13018, },
        {13014,     Game.mapDB.cityLocationReq, },
	}
    self.queryMapInfoCmds = {}
    for _, v in ipairs(REQUES_LIST) do
        self.queryMapInfoCmds[v[1]] = false
        v[2]()
    end
end

function prototype:realSwitchToWildmap(data)
    if self.sceneType ~= 'MAIN_CITY' then
        self:switchScene('WILD_MAP')
        return
    end

    Game:leaveCityOrMapAction(bind(self.switchScene, self, 'WILD_MAP', data))
end

function prototype:switchToDuplicate(data)
   self:switchScene('DUPLICATE', data.copyId) 
end

function prototype:enterBattle(data)
    assert(not self.preBattleScene, "DUPLICATE ENTER BATTLE")

    self.preBattleScene = self:getBaseScene()
    self.preBattleScene:retain()
    self.preBattleScene:removeFromParent(false)

    local battleScene = self:createBattleScene(data)
    self:attachBaseScene(battleScene)
end

function prototype:exitBattle()
    assert(self.preBattleScene, "DUPLICATE EXIT BATTLE")

    local battleScene = tolua.cast(self:getBaseScene(), "cc.Scene")
    battleScene:removeFromParent()

    if self.sceneType == 'DUPLICATE' then
        self.preBattleScene:updateContent()
    end

    self:attachBaseScene(self.preBattleScene)
    self.preBattleScene:release()
    self.preBattleScene = nil

    Game:onEnterScene()
end

function prototype:createBattleScene(data)
    local scene = MainScene:create()
    scene:setCurPassId(data.battleId)
    
    BattleLuaScene:setScenceEvent(tolua.cast(scene, "cc.Scene"))

    scene:battleBegin(data.battleMode,data.battleLuaValue.battleType)
    data.battleLuaValue.mainSceneObj = scene
    Game.dispatchCustomEvent("onEnterBattleScene", nil)

    return tolua.cast(scene, "cc.Scene")
end

function prototype:switchScene(sceneType, data)
    if self.sceneType == sceneType then
        return
    end

    if self.sceneType then
        self:getBaseScene():exitScene()
    end

    self.sceneType = sceneType
    local CREATE_SCENE = {
        MAIN_CITY   = bind(self.createMainCity, self),
        WILD_MAP    = require("map_scene.map_scene").new,
        DUPLICATE   = require("duplicate_scene.duplicate_scene").new,
    }

    local newSceneCreator = CREATE_SCENE[sceneType]
    if not newSceneCreator then
        log4ui:warn('error for create %s', sceneType)
        return
    end

    local newScene = newSceneCreator(data)
    self:attachBaseScene(newScene)
    newScene:enterScene(data)
end

function prototype:onQueryMapInfo(data, cmdId, cmdData)
    if not self.queryMapInfoCmds then
        return
    end

    if table.empty(self.queryMapInfoCmds) then
        return
    end

    if self.queryMapInfoCmds[cmdId] ~= false then
        return
    end

    self.queryMapInfoCmds[cmdId] = true
    for _, v in pairs(self.queryMapInfoCmds) do
        if v == false then
            return
        end
    end

    self.onSwitchToWildmapQuery = nil
    Singleton(Timer):After(300, self:Event('REAL_SWITCHTOWILDMAP', function()
        self:realSwitchToWildmap(data)
    end))
end

function prototype:initHornUI()
    local layer = require("ui.chat.HornMsgUI").new()
    self:addChild(layer, UIMgr.Define.PRIORITY.WINDOWPROMPT)
end

function prototype:onMsgInfo(cmdId, cmdData)
    baseScene = self:getBaseScene()
    if type(baseScene.notify) == 'function' then
        baseScene:notify(cmdId, cmdData)
    end

    if not self:isSceneType('MAIN_CITY') and self.mainCityScene then
        self.mainCityScene:notify(cmdId, cmdData)
    end

    if self.onSwitchToWildmapQuery then
        self:onSwitchToWildmapQuery(cmdId, cmdData)
    end
end


