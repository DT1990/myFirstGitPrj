
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG = 0

-- use framework, will disable all deprecated API, false - use legacy API
CC_USE_FRAMEWORK = true

-- show FPS on screen
CC_SHOW_FPS = true

-- disable create unexpected global variable
CC_DISABLE_GLOBAL = false

-- for module display
CC_DESIGN_RESOLUTION = {
    width = 640,
    height = 1136,
    autoscale = "SHOW_ALL",
    callback = function(framesize)
        local ratio = framesize.width / framesize.height
        if ratio <= 1.34 then
            -- iPad 768*1024(1536*2048) is 4:3 screen
            return {autoscale = "SHOW_ALL"}
        end
    end
}

 --战斗计算器
local platform = cc.Application:getInstance():getTargetPlatform()
BATTLE_CAL_MOD = cc.PLATFORM_OS_LINUX == platform
BATTLE_CAL_MOD_DEBUG = false --战斗计算器调试
DUPLICATE_MOD =  false   --副本
PRINT_TEST_TIME = true --打印计算器模式下每帧时间和总耗时
PRINT_LOG_FILE = false --输出打印日志
SHOW_CHECK_CODE = false --显示激活界面

BATTLE_CAL_GATEWAY = {      --战斗计算器的中转服务器
    host = "192.168.0.111",
    port = 8111
}

host = "rtsgame.eicp.net"   --稳定ip 129 服
port = 8022
