﻿#include "BattleScene.h"
#include <algorithm>
#include "cocos2d.h"
#include "base/UIColor.h"
#include "base/EventDispatcher.h"
#include "base/InternalEvent.h"
#include "battle/BattleTrap.h"
#include "battle/BattleTerrain.h"
#include "battle/BattleReport.h"
#include "battle/BattleSkill.h"
#include "battle/HitRange.h"
#include "battle/PriorTarget.h"
#include "battle/troop/GenGeneralPointTriggerArea.h"
#include "battle/GenGeneralPoint.h"
#include "battle/born/BarrackBornInfo.h"
#include "battle/BattlePvp.h"
#include "battle/BattleDropOut.h"
#include "battle/BattleAutoBattle.h"
#include "battle/formation/BattleGroup.h"
#include "battle/formation/BattleFormation.h"
#include "battle/formation/SoldierRecruiter.h"
#include "battle/BattleRoute.h"
#include "model/GameMetric.h"
#include "model/GameClientGM.h"
#include "model/GamePvp.h"
#include "model/GameGeneralManager.h"
#include "model/GameSoldierManager.h"
#include "model/GameSoldier.h"
#include "model/GamePlayer.h"
#include "model/ResourceModel.h"
#include "util/ActionRunner.h"
#include "util/view_util.h"
#include "util/LuaLogicUtil.h"
#include "util/snprintf.h"
#include "util/GridUtil.h"
#include "util/MathUtil.h"
#include "util/ConfigureUtil.h"
#include "util/AntiHack.h"
#include "util/BattlePveUtil.h"
#include "util/CrusadeUtil.h"
#include "util/GeneralUtil.h"
#include "skill/TargetSelectMgr.h"
#include "buff/BuffMgr.h"
#include "protocol/mh_protocol.h"
#include "xmlconfig/TerrainConfigure.h"
#include "xmlconfig/BattleSceneConfigure.h"
#include "view/MainScene.h"
#include "view/LoadingView.h"
#include "configure/PassiveSkillConfigure.h"
#include "configure/BattleHaloConfigure.h"

#include "configure/PassConfigure.h"
#include "configure/PassBuildingConfigure.h"
#include "configure/PassTowerConfigure.h"

#include "configure/SoldierConfigure.h"
#include "configure/TroopConfigure.h"
#include "configure/SystemConfigure.h"
#include "configure/PassSpecialCaseConfigure.h"
#include "configure/StringConfigure.h"
#include "configure/RecruitGeneralConfigure.h"
#include "configure/PvpMonsterSoldierConfigure.h"
#include "configure/MonsterSoldierConfigure.h"
#include "configure/SoldierCommonConfigure.h"
#include "configure/SoldierConfigure.h"
#include "configure/BattleParaConfigure.h"
#include "configure/GenGeneralPointActionConfigure.h"
#include "configure/GenGeneralPointConfigure.h"

#include "configure/SkillConfigure.h"
#include "configure/PassTrapConfigure.h"
#include "configure/PassConfigure.h"
#include "configure/MonsterPassTrapConfigure.h"
#include "replay/ReplayRecorder.h"
#include "replay/ReplayPlayer.h"
#include "replay/ReplayUtil.h"
#include "view/BattleSceneView.h"
#include "util/BattleSceneTemplateUtil.h"
#include "util/AutoBattleFocusToHelper.h"
#include "audio/AudioMgr.h"

using namespace std;
using namespace std::placeholders;
using namespace cocos2d;

#ifdef BUFF_MEMORY_LEAK_CHECK
extern int g_buffCount;
#endif

BattleScene *BattleScene::s_currentScene = nullptr;

// ----------------------------------------------------------------------------------

BattleScene::BattleRecord::BattleRecord(BattleScene *scene) : m_scene(scene)
{

}

static void releaseGroups(std::list<BattleGroup *> &groups)
{
	for(auto it = groups.begin(); it != groups.end(); ++it)
	{
		BattleGroup::destroy(*it);
	}

	groups.clear();
}
static void releaseSoldierRecruiters(std::map<uint16_t, SoldierRecruiter *> &recruiters)
{
	for(auto it = recruiters.begin(); it != recruiters.end(); ++it)
	{
		SoldierRecruiter::destroy(it->second);
	}

	recruiters.clear();
}
BattleScene::BattleRecord::~BattleRecord()
{
	releaseGroups(m_friendGroups);
	releaseGroups(m_enemyGroups);
	releaseSoldierRecruiters(m_soldierRecruiters);
}

void BattleScene::BattleRecord::addFriendGeneral(BattleMoveObject *general)
{
	m_friendGenerals.push_back(general);

	addGroup(kFriendParty, general);
	addSoliderRecruiter(kFriendParty, general);
}

void BattleScene::BattleRecord::removeFriendGeneral(BattleMoveObject *general)
{ 
	m_friendGenerals.erase(remove(m_friendGenerals.begin(), m_friendGenerals.end(), general), m_friendGenerals.end());

	removeGroup(kFriendParty, general);
	removeSoliderRecruiter(general->getId());
}

void BattleScene::BattleRecord::addEnemyGeneral(BattleMoveObject *general)
{
	m_enemyGenerals.push_back(general);

	addGroup(kEnemyParty, general);
	addSoliderRecruiter(kEnemyParty, general);
}

void BattleScene::BattleRecord::removeEnemyGeneral(BattleMoveObject *general)
{ 
	m_enemyGenerals.erase(remove(m_enemyGenerals.begin(), m_enemyGenerals.end(), general), m_enemyGenerals.end());

	removeGroup(kEnemyParty, general);
	removeSoliderRecruiter(general->getId());
}

void BattleScene::BattleRecord::addGroup(char party, BattleMoveObject *general)
{
	BattleGroup *group = BattleGroup::create(party, general->isMonster(), general->getId());
	if(party == kFriendParty)
	{
		m_friendGroups.push_back(group);
	}
	else
	{
		m_enemyGroups.push_back(group);
	}
}

void BattleScene::BattleRecord::removeGroup(char party, BattleMoveObject *general)
{
	auto &groups = (party == kFriendParty) ? m_friendGroups : m_enemyGroups;
	for(auto it = groups.begin(); it != groups.end(); ++it)
	{
		if((*it)->getGeneralId() == general->getId())
		{
			BattleGroup::destroy(*it);
			groups.erase(it);
			break;
		}
	}
}

void BattleScene::BattleRecord::addSoliderRecruiter(char party, BattleMoveObject *general)
{
	if(general->isMonster())
	{
		SoldierRecruiter *recruiter = SoldierRecruiter::create(party, general->getTid());
		m_soldierRecruiters.insert(make_pair(general->getId(), recruiter));
	}
}

void BattleScene::BattleRecord::removeSoliderRecruiter(uint16_t generalId)
{
	for(auto it = m_soldierRecruiters.begin(); it != m_soldierRecruiters.end(); ++it)
	{
		if(it->first == generalId)
		{
			SoldierRecruiter::destroy(it->second);
			m_soldierRecruiters.erase(it);
			break;
		}
	}
}

void BattleScene::BattleRecord::recruitSoldiers(char party, int soldierTid, int soldierNum)
{
	const auto &groups = (party == kFriendParty) ? m_friendGroups : m_enemyGroups;
	if(groups.empty()) return;
	int soliderProfession = SOLDIER_PROFESSION(soldierTid);
	
	int minSoldierNum = (numeric_limits<int>::max)();
	BattleGroup *candicateGroup = nullptr;
	BattleScene *scene = BattleScene::getCurrentScene();
	for(auto it = groups.cbegin(); it != groups.cend(); ++it)
	{
		BattleGroup *group = *it;
		if(group->isSoldierNumReachMax()) continue;
		int generalProfession = scene->getMoveObject(group->getGeneralId())->getProfession();
		if(generalProfession == soliderProfession)
		{
			int num = static_cast<int>(group->getTroopMembers().size());
			if(num < minSoldierNum)
			{
				minSoldierNum = num;
				candicateGroup = group;
			}
		}
	}
	if(candicateGroup)
	{
		candicateGroup->recruitSoldiers(soldierTid, soldierNum);
	}
}

void BattleScene::BattleRecord::recruitSoldiers(char party, uint16_t generalId, int soldierTid, int soldierNum)
{
	const auto &groups = (party == kFriendParty) ? m_friendGroups : m_enemyGroups;
	for(auto it = groups.cbegin(); it != groups.cend(); ++it)
	{
		BattleGroup *group = *it;
		if(group->getGeneralId() == generalId)
		{
			group->recruitSoldiers(soldierTid, soldierNum);
			break;
		}
	}
}

void BattleScene::BattleRecord::update(float dt)
{
	for(auto it = m_soldierRecruiters.begin(); it != m_soldierRecruiters.end(); ++it)
	{
		it->second->update(it->first, dt);
	}
}

void BattleScene::BattleRecord::recruitFullSoldiers(char party, uint16_t generalId, int soldierTid)
{
	const auto &groups = (party == kFriendParty) ? m_friendGroups : m_enemyGroups;
	for(auto it = groups.cbegin(); it != groups.cend(); ++it)
	{
		BattleGroup *group = *it;
		if(group->getGeneralId() == generalId)
		{
			group->recruitFullSoldiers(soldierTid);
			break;
		}
	}
}

int BattleScene::BattleRecord::getNearestOppoGeneralPos(GridPosition *targetPos, char party, const GridPosition &position, PriorTarget *priorTarget, bool isAntiCloak, int nodeIndex)
{
	int minSquare = (numeric_limits<int>::max)();

	LowestTarget &lowestTarget = BattleScene::getCurrentScene()->getLowestTarget();
	char oppoParty = getOppoParty(party);
	vector<BattleMoveObject *> &generals = (party == kFriendParty) ? m_enemyGenerals : m_friendGenerals;
	for(vector<BattleMoveObject *>::iterator iter = generals.begin(); iter != generals.end(); ++iter)
	{
		BattleMoveObject *general = *iter;
		if(priorTarget && !priorTarget->isCandidate(general)) continue;
		if(!general->canBeFound(isAntiCloak, nodeIndex)) continue;
		if(lowestTarget.isLowestObject(oppoParty, general->getId()) && !lowestTarget.isOnlyLeftLowestObject(oppoParty, isAntiCloak, nodeIndex)) continue;
		int square = squareOf(position, general->getGridPosition());
		if(square < minSquare)
		{
			minSquare = square;
			*targetPos = general->getGridPosition();
		}
	}

	return minSquare;
}

BattleGroup *BattleScene::BattleRecord::getGroupByEnemyGeneralId(int generalId)
{
	for (auto iter = m_enemyGroups.begin(); iter != m_enemyGroups.end(); ++iter)
	{
		if ((*iter)->getGeneralId() == generalId)
		{
			return *iter;
		}
	}
	return nullptr;
}

bool BattleScene::BattleRecord::isHaveCandidate(PriorTarget *priorTarget, char party)
{
	assert(priorTarget);
	vector<BattleMoveObject *> &generals = (party == kFriendParty) ? m_enemyGenerals : m_friendGenerals;
	for(vector<BattleMoveObject *>::iterator iter = generals.begin(); iter != generals.end(); ++iter)
	{
		BattleMoveObject *general = *iter;
		if(!priorTarget->isCandidate(general)) continue;
		return true;
	}
	return false;
}

void BattleScene::BattleRecord::getFriendGeneralIds(set<uint16_t> *objects)
{
	for(auto iter = m_friendGenerals.begin(); iter != m_friendGenerals.end(); ++iter)
	{
		SKILL_MSG("		objectId=%d", (*iter)->getId());
		objects->insert((*iter)->getId());
	}
}

void BattleScene::BattleRecord::getEnemyGeneralIds(set<uint16_t> *objects)
{
	for(auto iter = m_enemyGenerals.begin(); iter != m_enemyGenerals.end(); ++iter)
	{
		SKILL_MSG("		objectId=%d", (*iter)->getId());
		objects->insert((*iter)->getId());
	}
}

std::vector<uint16_t> BattleScene::BattleRecord::getFriendGeneralIds()
{
	std::vector<uint16_t> ids;
	for(auto iter = m_friendGenerals.begin(); iter != m_friendGenerals.end(); ++iter)
	{
		ids.push_back((*iter)->getId());
	}
	return ids;
}
std::vector<uint16_t> BattleScene::BattleRecord::getEnemyGeneralIds()
{
	std::vector<uint16_t> ids;
	for(auto iter = m_enemyGenerals.begin(); iter != m_enemyGenerals.end(); ++iter)
	{
		ids.push_back((*iter)->getId());
	}
	return ids;
}

bool BattleScene::BattleRecord::isTroopInGroup(char party, unsigned char troopId) const
{
	const auto &groups = (party == kFriendParty) ? m_friendGroups : m_enemyGroups;
	for(auto it = groups.cbegin(); it != groups.cend(); ++it)
	{
		if((*it)->getTroopId() == troopId)
		{
			return true;
		}
	}

	return false;
}

// ----------------------------------------------------------------------------------

#define RUN_STATIC_ACTIONS(objects, f) \
	do { \
		for(auto iter = objects.begin(); iter != objects.end(); ++iter) \
		{ \
			auto object = iter->second; \
			MonsterAI *priorTarget = object->getMonsterAI(); \
			if(priorTarget) priorTarget->f(object); \
			GenGeneralPoint *gtp = object->getGenGeneralPoint(); \
			if(gtp) \
			{ \
				const vector<MonsterAI *> &ais = gtp->getMonsterAIs(); \
				for(auto it = ais.begin(); it != ais.end(); ++it) \
				{ \
					(*it)->f(gtp); \
				} \
			} \
		} \
	} while(0)

#define RUN_STATIC_GTP_ACTIONS(objects, f, ...) \
	do { \
		for(auto iter = objects.begin(); iter != objects.end(); ++iter) \
		{ \
			GenGeneralPoint *gtp = iter->second->getGenGeneralPoint(); \
			if(gtp) \
			{ \
				const vector<MonsterAI *> &ais = gtp->getMonsterAIs(); \
				for(auto it = ais.begin(); it != ais.end(); ++it) \
				{ \
					(*it)->f(gtp, ##__VA_ARGS__); \
				} \
			} \
		} \
	} while(0)

#define RUN_GENERAL_ACTIONS(generals, f) \
	do { \
		for(auto iter = generals.begin(); iter != generals.end(); ++iter) \
		{ \
			auto priorTarget = (*iter)->getMonsterAI(); \
			if(priorTarget) priorTarget->f(*iter); \
		} \
	} while(0)

#define RUN_GTP_ACTIONS(gtps, f, ...) \
	do { \
		for(auto iter = gtps.begin(); iter != gtps.end(); ++iter) \
		{ \
			GenGeneralPoint *gtp = *iter; \
			const vector<MonsterAI *> &ais = gtp->getMonsterAIs(); \
			for(auto it = ais.begin(); it != ais.end(); ++it) \
			{ \
				(*it)->f(gtp, ##__VA_ARGS__); \
			} \
		} \
	} while(0)

#define RUN_AREA_TRIGGER_GTP_ACTIONS(areas, f, ...) \
	do { \
		for(auto iter = areas.begin(); iter != areas.end(); ++iter) \
		{ \
			GenGeneralPoint *gtp = (*iter)->getGenGeneralPoint(); \
			const vector<MonsterAI *> &ais = gtp->getMonsterAIs(); \
			for(auto it = ais.begin(); it != ais.end(); ++it) \
			{ \
				(*it)->f(gtp, ##__VA_ARGS__); \
			} \
		} \
	} while(0)

#define RUN_GUIDE_ACTIONS(f, ...) \
	do { \
		if(m_guideAi) m_guideAi->f(nullptr, ##__VA_ARGS__); \
	} while(0)

#define RUN_ACTIONS(f, ...) \
	do { \
		RUN_GENERAL_ACTIONS(m_battleRecord->getEnemyGenerals(), f); \
		\
		RUN_STATIC_ACTIONS(m_friendBuildings, f); \
		RUN_STATIC_ACTIONS(m_enemyBuildings, f); \
		RUN_STATIC_ACTIONS(m_friendTowers, f); \
		RUN_STATIC_ACTIONS(m_enemyTowers, f); \
		\
		RUN_GTP_ACTIONS(m_friendGenGeneralPoints, f, ##__VA_ARGS__); \
		RUN_GTP_ACTIONS(m_enemyGenGeneralPoints, f, ##__VA_ARGS__); \
		RUN_AREA_TRIGGER_GTP_ACTIONS(m_enemyGenGeneralPointTriggerAreas, f, ##__VA_ARGS__); \
		\
		RUN_GUIDE_ACTIONS(f, ##__VA_ARGS__); \
	} while(0)

BattleScene::BattleScene(int id) 
	: m_sceneId(id)
	, m_currentMoveObjId(0)
	, m_currentBuildingId(kBuildingIdBase)
	, m_currentTowerId(kTowerIdBase)
	, m_isLookingOver(false)
	, m_isPause(false)
	, m_isEnterBattle(false)
	, m_curUpdateTroopId(0)
	, m_battleDataCostTime(0.0f)
	, m_curGoToward(BattleObject::kRightUp)
	, m_friendPVPBossBuildingId(0)
	, m_enemyPVPBossBuildingId(0)
	, m_battleResources(0.0f)
	, m_battleResourcesSpeed(0.0f)
	, m_totalAddedResources(0.0f)
	, m_totalCostedResources(0.0f)
	, m_totalGeneralDeadTimes(0)
	, m_maxBattleResources(0)
	, m_battleTime(0)
	, m_guideAi(nullptr)
	, m_friendBossBarrack(0)
	, m_enemyBossBarrack(0)
	, m_isTriggeredFriendArea(false)
	, m_isTriggeredEnemyArea(false)
	, m_barrackBornInfo(nullptr)
	, m_isBossStageChanged(false)
	, m_isInAutoBattleMode(true)
	, m_isAutoFocusTo(false)
	, m_autoBattleIntervalTime(0.0f)
	, m_refreshStarInfoIntervalTime(0.0f)
    , m_oldFriendResourcesConsume(0)
	, m_isSceneInitFinished(false)
	, m_isRealBegan(false)
	, m_isGuideTriggerPause(false)
	, m_enemySceneGenGeneralPointTotalWaveNum(0)
    , m_friendCallGeneralNum(0)
    , m_enemyCallGeneralNum(0)
	, m_dropOut(nullptr)
	, m_friendAutoBattle(nullptr)
	, m_enemyAutoBattle(nullptr)
	, m_isBossDead(false)
	, m_autoFocus(nullptr)
	, m_isExit(false)
	, m_friendFormation(nullptr)
	, m_enemyFormation(nullptr)
	, m_currentNodeIndex(0)
	, m_nodeNum(0)
    , m_isFoodSkillCd(false)
	, m_isFighting(false)
    , m_currFoodSkillCdTime(0.0f)
	, m_isPassWarnPoint(false)
	, m_friendTroopBeginPos(-1, -1)
	, m_enemyTroopBeginPos(-1, -1)
	, m_isFirstAttack(true)
	, m_isRealStart(false)
{
#ifdef BUFF_MEMORY_LEAK_CHECK
	g_buffCount = 0;
#endif

	m_antiHack = new AntiHack();

	m_shouldStartCountDown = true;

	m_isInAutoBattleMode = isPvp();

	m_terrain = new BattleTerrain();
	const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);
	char filePath[128];
	snprintf(filePath, sizeof(filePath), "res/scenes/maps/%d/terrain.txt", scenePty.mapId);
	ssize_t buffSize = 0;
	std::string fullPath = FileUtils::sharedFileUtils()->fullPathForFilename(filePath);
	unsigned char *barrier = cocos2d::FileUtils::sharedFileUtils()->getFileData(fullPath.c_str(), "r", &buffSize);

	
	const BattleMapProperty &mapPty = getBattleMap(scenePty.mapId);
	const TerrainProperty &terrainPty = getTerrainProperty(mapPty.path);
	m_width = terrainPty.width;
	m_height = terrainPty.height;
	m_terrain->initMap(barrier + 1, m_width, m_height);
	m_terrain->setUseDiag(true);

	delete []barrier;

	m_friendAutoBattle = new auto_battle::BattleAutoBattle();
	if (isPvp())
	{
		m_enemyAutoBattle = new auto_battle::BattleAutoBattle();
	}
	else
	{
		m_friendAutoBattle->init(kFriendParty);
	}

	m_passType = kNormalPass;

	if(m_passType == kNormalPass || m_passType == kMOBAPass || m_passType == kBossPass)
	{
		m_barrackBornInfo = new BarrackBornInfo();
	}

	setCurrentScene(this);

	m_battleRecord = new BattleRecord(this);

	m_friendTroops = new BattleTroopSet();
	m_enemyTroops = new BattleTroopSet();

	initBattleResourceAndTime();

	const BattleSceneProperty &ptyModel = getBattleScene(m_sceneId);
	initTriggerAreas(ptyModel);

	cocos2d::Director::sharedDirector()->getScheduler()->scheduleUpdateForTarget(this, 1, false);

	_firstAttackEvent = cocos2d::Director::getInstance()->getEventDispatcher()->addCustomEventListener("firstAttack", std::bind(&BattleScene::onSceneFirstAttack,this));
	_firstAttackEvent->retain();
	TEST_MSG("========= Entering scene[%d] =========", m_sceneId);
}
//攻城战防守方受击之后开始反击
void BattleScene::onSceneFirstAttack()
{
	for (auto it = m_enemyMoveObjects.begin(); it != m_enemyMoveObjects.end(); ++it)
	{
		BattleMoveObject *object = it->second;
		if (object->getNodeIndex() != 1)
		{
			object->setNodeIndex(1);
		}
	}
	//m_enemyTroops->initTargetTroop();
	cocos2d::Director::getInstance()->getEventDispatcher()->removeEventListener(_firstAttackEvent);
}

void BattleScene::areaTroopInitFinish()
{
	static int s_count = 0;
	s_count++;
	if(s_count % 2 == 0)
	{
		arenaStartOff();
	}
}

void BattleScene::initBattleResourceAndTime()
{
	if (isInThisBattleMode(MainScene::kBattlePVP))
	{
		setBattleTime(SYSTEM_VALUE("pvp_battle_time"));
	}
	else
	{
		setBattleTime(PASS_BATTLE_TIME(MainScene::theScene()->getCurPassId()));
	}
	calcBattleResourcesSpeed();
}

void BattleScene::initTriggerAreas(const BattleSceneProperty &pty)
{
	for(auto it = pty.enemy_ambush_gen_troop_points.begin(); it != pty.enemy_ambush_gen_troop_points.end(); ++it)
	{
		GenGeneralPointTriggerArea *area = new GenGeneralPointTriggerArea(kEnemyParty, m_terrain, *it);
		m_enemyGenGeneralPointTriggerAreas.push_back(area);
	}
}

void BattleScene::releaseTriggerAreas()
{
	for(auto it = m_enemyGenGeneralPointTriggerAreas.begin(); it != m_enemyGenGeneralPointTriggerAreas.end(); ++it)
	{
		CC_SAFE_DELETE(*it);
	}

	m_enemyGenGeneralPointTriggerAreas.clear();
}

void BattleScene::releaseGenGeneralPoints()
{
	for(vector<GenGeneralPoint *>::iterator iter = m_friendGenGeneralPoints.begin(); iter != m_friendGenGeneralPoints.end(); ++iter)
	{
		(*iter)->release();
	}
	m_friendGenGeneralPoints.clear();

	for(vector<GenGeneralPoint *>::iterator iter = m_enemyGenGeneralPoints.begin(); iter != m_enemyGenGeneralPoints.end(); ++iter)
	{
		(*iter)->release();
	}
	m_enemyGenGeneralPoints.clear();
}

void BattleScene::updateTriggerAreas(float dt)
{
	for(auto it = m_enemyGenGeneralPointTriggerAreas.begin(); it != m_enemyGenGeneralPointTriggerAreas.end(); ++it)
	{
		(*it)->update(this, dt);
	}
}

template <typename T>
static void releaseObjects(map<uint16_t, T> &objects)
{
	typename map<uint16_t, T>::const_iterator iter = objects.begin();
	for(; iter != objects.end(); ++iter)
	{
		iter->second->cleanUp();
		iter->second->release();
	}

	objects.clear();
}

void BattleScene::onStarUiTouchEnd()
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBattleStarUiTouchEnd();
	}
}

void BattleScene::onInitFinish()
{
	if(m_passType == kBossPass)
	{
		m_enemyTroops->launchTroops();
	}
	else if(m_passType == kTowerDefensePass)
	{
		std::vector<GenGeneralPoint *> gtps = getSceneGenGeneralPoints(kEnemyParty);
		for(auto it = gtps.begin(); it != gtps.end(); ++it)
		{
			m_enemySceneGenGeneralPointTotalWaveNum += (*it)->getTotalWaveNum();
		}
	}

	m_friendTroops->launchTroops();

	//friendFormationStart();

	RUN_ACTIONS(runEnterSceneActions);

	m_isSceneInitFinished = true;
	/*m_autoFocus = new AutoBattleFocusToHelper();
	m_autoFocus->autorelease();
	m_autoFocus->retain();*/

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onSceneInitFinished();
	}

	LuaLogicUtil::onInitFinish();
}

void BattleScene::onExit()
{
	if (m_isExit) return;
	m_isExit = true;
	cocos2d::Director::sharedDirector()->getScheduler()->unscheduleUpdateForTarget(this);

	CC_SAFE_DELETE(m_friendFormation);
	CC_SAFE_DELETE(m_enemyFormation);

	releaseObjects(m_enemyMoveObjects);
	releaseObjects(m_friendMoveObjects);

	releaseObjects(m_enemyBuildings);
	releaseObjects(m_friendBuildings);

	releaseObjects(m_enemyTowers);
	releaseObjects(m_friendTowers);

	releaseTriggerAreas();
	releaseGenGeneralPoints();

	CC_SAFE_DELETE(m_friendTroops);
	CC_SAFE_DELETE(m_enemyTroops);
	CC_SAFE_DELETE(m_battleRecord);
	CC_SAFE_DELETE(m_terrain);
	CC_SAFE_DELETE(m_antiHack);
	CC_SAFE_DELETE(m_barrackBornInfo);

	vector<BattleTroop *> &bTroops = m_battleStatistics.getCageTroops();

	for(auto it = bTroops.begin(); it != bTroops.end(); ++it)
	{
		(*it)->release();
	}

	removeBattleHalos();
	removeAllSceneSoldierBuff();
	removeAllSoldierBuffs();
	MonsterAI::destroy(m_guideAi);
	CC_SAFE_DELETE(m_dropOut);

	TargetSelectMgr::theMgr().reset();
	FxMgr::theMgr().reset();
	BuffMgr::theMgr().reset();
	ResourceBattleData::theMgr().clearData();
	ChainDamageMgr::theMgr().reset();

	BattleTroopSet::resetCurTroopId();
	MonsterAI::reset();
	AudioMgr::theMgr()->reset();

	CC_SAFE_DELETE(m_friendAutoBattle);
	CC_SAFE_DELETE(m_enemyAutoBattle);
	/*if (m_autoFocus)
	{
		m_autoFocus->reset();
		m_autoFocus->release();
		m_autoFocus = nullptr;
	}*/

	if (MainScene::theScene() && !MainScene::theScene()->isReplay())
	{
		replay::ReplayRecorder::theRecorder()->stopRecord();
	}
	else
	{
		replay::ReplayPlayer::thePlayer()->stopReply();
	}

#ifdef BUFF_MEMORY_LEAK_CHECK
	assert(g_buffCount == 0 && "buff object memory leak!!!");
#endif
}

void BattleScene::getTroopAreaQuads(vector<AreaQuad> *quads)
{
	if(m_isExit)
	{
		return;
	}

	m_friendTroops->getTroopAreaQuads(quads, m_terrain);
	m_enemyTroops->getTroopAreaQuads(quads, m_terrain);
}

void BattleScene::getTowerInterestAreaQuads(vector<AreaQuad> *quads)
{
	for(IDTower::iterator iter = m_friendTowers.begin(); iter != m_friendTowers.end(); ++iter)
	{
		iter->second->getInterestAreaQuad(quads);
	}

	for(IDTower::iterator iter = m_enemyTowers.begin(); iter != m_enemyTowers.end(); ++iter)
	{
		iter->second->getInterestAreaQuad(quads);
	}
}

void BattleScene::getTowerAttAreaQuads(vector<AreaCircle> *circles)
{
	for(IDTower::iterator iter = m_friendTowers.begin(); iter != m_friendTowers.end(); ++iter)
	{
		iter->second->getAttAreaQuad(circles);
	}

	for(IDTower::iterator iter = m_enemyTowers.begin(); iter != m_enemyTowers.end(); ++iter)
	{
		iter->second->getAttAreaQuad(circles);
	}
}

void BattleScene::getTriggerTroopAreas(std::vector<AreaQuad> *quads)
{
	for(auto it = m_enemyGenGeneralPointTriggerAreas.begin(); it != m_enemyGenGeneralPointTriggerAreas.end(); ++it)
	{
		(*it)->getAreas(quads, kEnemyParty);
	}
}

BattleScene::~BattleScene()
{
	
	TEST_MSG("========= Leaving scene[%d] =========", m_sceneId);
	cocos2d::Director::getInstance()->getEventDispatcher()->removeEventListener(_firstAttackEvent);
	CC_SAFE_RELEASE(_firstAttackEvent);
}

void BattleScene::doInitScenePoint(const std::vector<ObjectInfo> &pointInfo)
{
	GridUtil &gridUtil = GridUtil::sharedGridUtil();
	for(size_t i = 0; i < pointInfo.size(); ++i)
	{
		const ObjectInfo &object = pointInfo[i];

		switch(object.tid)
		{
		case scenecfg::kFriendWayPoint:
			{
				m_friendWayPoint = gridUtil.pixToGrid(object.position.x, object.position.y);
				break;
			}
		case scenecfg::kEnemyWayPoint:
			{
				m_enemyWayPoint = gridUtil.pixToGrid(object.position.x, object.position.y);
				break;
			}
		case scenecfg::kFriendBornPoint:
			{
				m_friendBornPoint = gridUtil.pixToGrid(object.position.x, object.position.y);
				break;
			}
		case scenecfg::kEnemyBornPoint:
			{
				m_enemyBornPoint = gridUtil.pixToGrid(object.position.x, object.position.y);
				break;
			}
		default:
			assert(false);
		}
	}
}

void BattleScene::initFocusPoint()
{
	const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);
	const BattleMapProperty &pty = getBattleMap(scenePty.mapId);
	lookOver(pty.focus_point);
}

void BattleScene::initScenePoint(int sceneId)
{
	const BattleSceneProperty &ptyModel = getBattleScene(sceneId);
	doInitScenePoint(ptyModel.point_infos);

	const BattleMapProperty &ptyMap = getBattleMap(ptyModel.mapId);
	lookOver(ptyMap.focus_point);

	int passId = MainScene::theScene()->getCurPassId();
	std::vector<int> haloIds = PASS_HALO_IDS(passId);
	m_sceneSoldierHaloIds.clear();
	for (auto it = haloIds.begin(); it != haloIds.end(); ++it)
	{
		m_sceneSoldierHaloIds.push_back(*it);
	}
}

void BattleScene::getTroopRoutes(vector<vector<WayPoint> > *routes)
{
	m_friendTroops->getTroopRoutes(routes);
	m_enemyTroops->getTroopRoutes(routes);
}

static void updateTroop(unsigned char &curUpdateTroopId)
{
	const set<unsigned char> &troopIds = BattleTroopSet::getTroopIds();
	if(!troopIds.empty())
	{
		set<unsigned char>::iterator iter = troopIds.upper_bound(curUpdateTroopId);
		if(iter == troopIds.end())
		{
			iter = troopIds.upper_bound(0);
			assert(iter != troopIds.end());
		}
		curUpdateTroopId = *iter;
	}
}

void BattleScene::updateGenGeneralPoints(float dt)
{
	for(IDBuilding::iterator iter = m_enemyBuildings.begin(); iter != m_enemyBuildings.end(); ++iter)
	{
		iter->second->GenGeneralPointUpdate(dt);
	}
	
	for(IDTower::iterator iter = m_enemyTowers.begin(); iter != m_enemyTowers.end(); ++iter)
	{
		iter->second->GenGeneralPointUpdate(dt);
	}

	for(vector<GenGeneralPoint *>::iterator iter = m_friendGenGeneralPoints.begin(); iter != m_friendGenGeneralPoints.end(); ++iter)
	{
		GenGeneralPoint *gtp = *iter;
		gtp->update(dt);
	}

	for(vector<GenGeneralPoint *>::iterator iter = m_enemyGenGeneralPoints.begin(); iter != m_enemyGenGeneralPoints.end(); ++iter)
	{
		GenGeneralPoint *gtp = *iter;
		gtp->update(dt);
	}
}

std::vector<GenGeneralPoint *> BattleScene::getSceneGenGeneralPoints(char party) const
{
	std::vector<GenGeneralPoint *> gtps;
	if(party == kFriendParty)
	{
		gtps.insert(gtps.end(), m_friendGenGeneralPoints.begin(), m_friendGenGeneralPoints.end());
	}
	else
	{
		gtps.insert(gtps.end(), m_enemyGenGeneralPoints.begin(), m_enemyGenGeneralPoints.end());
		for(auto it = m_enemyGenGeneralPointTriggerAreas.cbegin(); it != m_enemyGenGeneralPointTriggerAreas.cend(); ++it)
		{
			gtps.push_back((*it)->getGenGeneralPoint());
		}
	}
	return gtps;
}

std::vector<GridPosition> BattleScene::getSceneTroopPointPositions(char party)
{
	std::vector<GridPosition> positions;

	std::vector<GenGeneralPoint *> gtps = getSceneGenGeneralPoints(party);
	for(auto it = gtps.cbegin(); it != gtps.cend(); ++it)
	{
		positions.push_back((*it)->getGridPosition());
	}

	return positions;
}

std::vector<GridPosition> BattleScene::getBuildingGenGeneralPointPositions(char party)
{
	std::vector<GridPosition> positions;
	auto &buildings = (party == kFriendParty) ? m_friendBuildings : m_enemyBuildings;
	for(auto it = buildings.begin(); it != buildings.end(); ++it)
	{
		GenGeneralPoint *gtp = it->second->getGenGeneralPoint();
		if(gtp)
		{
			positions.push_back(gtp->getGridPosition());
		}
	}

	return positions;
}

void BattleScene::doPvpResAction()
{
}

void BattleScene::setAutoBattle(bool isAuto)
{
	m_isInAutoBattleMode = isAuto;
	if (m_friendAutoBattle) m_friendAutoBattle->setAutoUseSkill(isAuto);
}

static void getGeneralInfos( std::vector<GeneralBase> *generalInfos, int party)
{
}

float BattleScene::getNotCallGeneralMp(int generalTid, int party) const
{
    auto &notCallGenerals = party == kFriendParty ? m_friendNotCallGeneralMp : m_enemyNotCallGeneralMp;
    auto mpIter = notCallGenerals.find(generalTid);
    if (mpIter != notCallGenerals.end())
    {
        return mpIter->second;
    }

    return 0.0f;
}

void BattleScene::updateNotCallGeneralMp(float dt, int party)
{
   
}

void BattleScene::updateNotCallGeneralMp(float dt)
{
    updateNotCallGeneralMp(dt, kFriendParty);
    if (isPvp())
    {
        updateNotCallGeneralMp(dt, kEnemyParty);
    }
}

//static int s_maxNum = 0;
void BattleScene::update(float dt)
{
	m_refreshStarInfoIntervalTime += dt;
	if (m_refreshStarInfoIntervalTime > 1.0f)
	{
		handleStarInfoRefresh();
		m_refreshStarInfoIntervalTime = 0.0f;
	}

	if (m_isPause || !MainScene::theScene()) return;

	m_battleRecord->update(dt);
	if(m_friendFormation)
	{
		m_friendFormation->update();
	}
	if(m_enemyFormation)
	{
		m_enemyFormation->update();
	}

    updateBattleHalos(dt);

    updateBattleResource();
    updateNotCallGeneralMp(dt);
    updateFoodSkillCDTime(dt);

	bool isUnitNumChange = false;
	if(MonsterAI::isUnitNumAdd())
	{
		RUN_ACTIONS(runUnitNumAddActions);
		MonsterAI::setUnitNumAdd(false);
		isUnitNumChange = true;
	}
	if(MonsterAI::isUnitNumReduce())
	{
		RUN_ACTIONS(runUnitNumReduceActions);
		MonsterAI::setUnitNumReduce(false);
		isUnitNumChange = true;
	}
	if(isUnitNumChange)
	{
		RUN_ACTIONS(runUnitNumChangeActions);
	}

	if(m_guideAi)
	{
		m_guideAi->update(dt, nullptr);
	}

	if (m_isInAutoBattleMode && !isPvp())
	{
		m_autoBattleIntervalTime += dt;
		if (m_autoBattleIntervalTime > 1.0f)
		{
			//m_friendAutoBattle->doResAction(static_cast<int>(getBattleResources()));
			m_autoBattleIntervalTime = 0.0f;
		}
	}

	BuffMgr::theMgr().update(dt);

	LuaLogicUtil::battleUpdateForlua(dt);

	updateTroop(m_curUpdateTroopId);
	//updateBattleData(dt);

	m_friendTroops->update();
	m_enemyTroops->update();

	updateTriggerAreas(dt);
	updateGenGeneralPoints(dt);

	updateBattleResSpeedAdds(dt);

// 	if(getIsInAutoBattleMode())
// 	{
// 		if(canOpenCurrentNodeGate())
// 		{
// 			trueStartBattle();
// 			
// 			//openCurrentNodeGate();
// 		}
// 	}

	/*int num = BattleTerrain::getTotalFindNodesNumPerFrame();
	INFO_MSG("nodes num = %d", num);
	if(num > s_maxNum)
	{
		s_maxNum = num;
	}*/
	BattleTerrain::resetTotalFindNodesNumPerFrame();

	if (MainScene::theScene()->isReplay())
	{
		if (m_shouldStartCountDown)
		{
			replay::ReplayPlayer::thePlayer()->update(dt);
		}
	}
	else
	{
		if (m_shouldStartCountDown)
		{
			replay::ReplayRecorder::theRecorder()->update(dt);
		}	
	}
}

static void clearCurrentTriggerArea(BattleTerrain *terrain, const GridPosition &position)
{
	static int offset[8][2] = {{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{0,1},{1,1}};
	terrain->removeTrigger(position.x, position.y);
	int	x = 0, y = 0;
	for(int i = 0; i < 8; i++)
	{
		x = position.x + offset[i][0];
		y = position.y + offset[i][1];
		GridPosition grid(x, y);
		if(terrain->getTrigger(grid.x, grid.y) > 0)
		{
			clearCurrentTriggerArea(terrain, grid);
		}
	}
}

void BattleScene::troopRunOutDoor()
{
	const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);
	std::vector<FormationPoint> formationPoints = scenePty.enemy_formation_points;
	std::sort(formationPoints.begin(), formationPoints.end(), [](FormationPoint l1, FormationPoint l2) {
		return l1.order < l2.order;
	});
	m_enemyTroops->initTargetTroop(formationPoints);
}

void BattleScene::trueStartBattle()
{
	friendFormationEnd();
	//BattleSceneView::getCurrentSceneView()->sentryRunToBarrack();
	//clearCurrentTriggerArea(m_terrain, position);
    openCurrentNodeGate();

	m_friendTroops->initTargetTroop();
	
	IDTower enemyObj = getTowers(kEnemyParty);
	cocos2d::Vector<BattleTower *> tmp;
	for (auto iter = enemyObj.begin(); iter != enemyObj.end(); ++iter)
	{
		tmp.pushBack(iter->second);
	}
	IDBuilding enemyBuildings = getEnmeyBuildings();
	cocos2d::Vector<BattleBuilding *> tmpDoors;

	for (auto iter = enemyBuildings.begin(); iter != enemyBuildings.end(); ++iter)
	{
		if (iter->second->getBuildingType() == BattleBuilding::kDoor)
		{
			tmpDoors.pushBack(iter->second);
		}
	}
	//非攻城模式下不需要出城展示
	if ((MainScene::theScene()->getBattleMode() == MainScene::kBattlePVP && tmpDoors.size() == 0) || MainScene::theScene()->getBattleMode() == MainScene::kBattlePass)
	{
		m_enemyTroops->initTargetTroop();
	}
}

void BattleScene::checkExactAreaTrigger(BattleMoveObject *object)
{
	const GridPosition &position = object->getGridPosition();
	if(object->getParty() == kFriendParty)
	{
		if(m_terrain->getTrigger(position.x, position.y) > 0)
		{
			friendFormationEnd();
			BattleSceneView::getCurrentSceneView()->sentryRunToBarrack();
			clearCurrentTriggerArea(m_terrain, position);
		}
		else if(m_terrain->isAreaGrid(kEnemyParty, position))
		{
			if(!m_isTriggeredEnemyArea)
			{
				RUN_GENERAL_ACTIONS(m_battleRecord->getEnemyGenerals(), runEnemyEnterMyAreaActions);
				RUN_STATIC_ACTIONS(m_enemyBuildings, runEnemyEnterMyAreaActions);
				RUN_STATIC_ACTIONS(m_enemyTowers, runEnemyEnterMyAreaActions);
				RUN_GTP_ACTIONS(m_enemyGenGeneralPoints, runEnemyEnterMyAreaActions);
			}
			enemyEnterMyArea(kEnemyParty, object->getId());
			m_isTriggeredEnemyArea = true;
		}
	}
	else
	{
		if(m_terrain->isAreaGrid(kFriendParty, position))
		{
			if(!m_isTriggeredFriendArea)
			{
				RUN_STATIC_ACTIONS(m_friendBuildings, runEnemyEnterMyAreaActions);
				RUN_STATIC_ACTIONS(m_friendTowers, runEnemyEnterMyAreaActions);
				RUN_GTP_ACTIONS(m_friendGenGeneralPoints, runEnemyEnterMyAreaActions);
			}
			enemyEnterMyArea(kFriendParty, object->getId());
			m_isTriggeredFriendArea = true;
		}
	}
}

void BattleScene::enemyEnterMyArea(char myParty, uint16_t enemyId)
{
	if(m_passType == kBossPass)
	{
		if(myParty == kEnemyParty)
		{
			const vector<BattleMoveObject *> &generals = m_battleRecord->getEnemyGenerals();
			for(auto it = generals.cbegin(); it != generals.cend(); ++it)
			{
				(*it)->setManualMode(false);				// 
			}

			m_enemyTroops->launchTroops();
		}
	}
	
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyEnterMyArea(myParty, enemyId);
	}
}

void BattleScene::getRoutePoints(std::vector<WayPoint> *routePoints, char party, const GridPosition &position, int type)
{
	return;
//	if(isInThisBattleMode(MainScene::kBattleDungeonRes)) return;
//
//	WayPoint wp;
//	if(party == kFriendParty)
//	{
//		if(!isInThisBattleMode(MainScene::kBattlePVP) && m_friendWayPoint.y > position.y)
//		{
//			wp.reset();
//			wp.position = m_friendWayPoint;
//			routePoints->push_back(wp);
//		}
//
//		for(auto iter = m_enemyBarracks.begin(); iter != m_enemyBarracks.end(); ++iter)
//		{
//			wp.reset();
//			wp.index = iter->first;
//			BattleBuilding *barrack = iter->second.building;
//			assert(barrack);
//			if(barrack->getGridPosition().y > position.y)
//			{
//				routePoints->push_back(wp);
//			}
//		}
//	}
//	else
//	{
//		for(auto iter = m_enemyBarracks.rbegin(); iter != m_enemyBarracks.rend(); ++iter)
//		{
//			wp.reset();
//			wp.index = iter->first;
//			BattleBuilding *barrack = iter->second.building;
//			assert(barrack);
//			if(barrack->getGridPosition().y < position.y)
//			{
//				routePoints->push_back(wp);
//			}
//		}
//
//		if(!isInThisBattleMode(MainScene::kBattlePVP))
//		{
//			wp.index = 0;
//			wp.position = m_enemyWayPoint;
//			routePoints->push_back(wp);
//		}
//	}
}

void BattleScene::addView(IBattleSceneView *view)
{
	m_views.push_back(view);
}

void BattleScene::removeView(IBattleSceneView *view)
{
	for(size_t i = 0; i < m_views.size(); ++i)
	{
		if(m_views[i] == view)
		{
			m_views[i] = m_views[m_views.size() - 1];
			m_views.resize(m_views.size() - 1);
			break;
		}
	}
}

void BattleScene::pathToGrid(const GridPosition &start, const GridPosition &end, vector<GridPosition> &path, int flagId, bool isFindNearBy)
{
	if(start == end)
	{
		assert(false);
		return;
	}
	m_terrain->findPath(start, end, path, flagId, isFindNearBy);
}

void BattleScene::fastFindPath(bool isCCW, const GridPosition &start, const GridPosition &end, vector<GridPosition> &path, int flagId)
{
	if(start == end)
	{
		assert(false);
		return;
	}
	m_terrain->fastFindPath(isCCW, start, end, path, flagId);
}

/*
规则：
1. 若该格上的对象是可移动的，则将该格上的对象统统移走；
2. 若该格上的对象是不可移动的，则自己乖乖的找周围可放置的格子放置吧
*/
void BattleScene::doForcePlaceInTerrain(BattleMoveObject *object)
{
	const GridPosition &grid = object->getGridPosition();
	int flagId = terrain::genFlagId(object->getParty(), object->getTroopId(), true, object->getSize());
	if(m_terrain->isGridCanEnter(grid, flagId)) return;

	bool isInBarrier = false;
	const GridRect &rect = object->getIntRect(grid);
	for(int16_t y = rect.rb.y; y <= rect.lt.y; ++y)
	{
		for(int16_t x = rect.lt.x; x <= rect.rb.x; ++x)
		{
			if(m_terrain->isStaicBarrier(x, y) || m_terrain->isDynamicBarrier(x, y))
			{
				isInBarrier = true;
				break;
			}
		}
	}

	if(isInBarrier)
	{
		object->setGridPosition(m_terrain->getNearNotBarrierNode(grid, flagId));
	}
	else
	{
		shoveAwayObjects(object, grid);
	}
}

void BattleScene::shoveAwayObjects(BattleMoveObject *shover, const GridPosition &grid)
{
	if(!shover->isMultiSize())
	{
		shoveAwayObjects(grid, nullptr);
	}
	else
	{
		// 注意：这里只能用拷贝
		GridRect rect = shover->getIntRect(grid);
		for(int16_t y = rect.rb.y; y <= rect.lt.y; ++y)
		{
			for(int16_t x = rect.lt.x; x <= rect.rb.x; ++x)
			{
				shoveAwayObjects(GridPosition(x, y), &rect);
			}
		}
	}
}

const GridPosition & BattleScene::getTroopMemberBeginPos(char party) const
{
	if (party == kFriendParty)
	{
		return m_friendTroopBeginPos;
	}
	else
	{
		return m_enemyTroopBeginPos;
	}
}

void BattleScene::setTroopMemberBeginPos(char party, GridPosition beginPos)
{
	if (party == kFriendParty)
	{
		m_friendTroopBeginPos = beginPos;
	}
	else
	{
		m_enemyTroopBeginPos = beginPos;
	}
}

void BattleScene::shoveAwayObjects(const GridPosition &grid, GridRect *rect)
{
	assert(!m_terrain->isStaicBarrier(grid.x, grid.y) && !m_terrain->isDynamicBarrier(grid.x, grid.y));

	// 注意：这里不能用引用（因为jumpTo会改变该list）;
	list<uint16_t> ids = m_terrain->getGridObjects(grid.x, grid.y);
	for(list<uint16_t>::iterator iter = ids.begin(); iter != ids.end(); ++iter)
	{
		BattleMoveObject *shovedObject = getMoveObject(*iter);
		if (shovedObject)
		{
			GridPosition position = m_terrain->getNearNotBarrierNode(grid, terrain::genFlagId(shovedObject->getParty(), shovedObject->getTroopId(), true, shovedObject->getSize()), rect);
			INFO_MSG("[%d] jump from (%d,%d) to (%d,%d)", shovedObject->getId(), grid.x,grid.y, position.x,position.y);
			shovedObject->jumpTo(skill::covertGridCenterToFloat(position), false);
		}
	}
}

void BattleScene::addEnemyMoveObject(BattleMoveObject *mo, bool isHide, bool isForcePlaceInTerrain, int toward)
{
	mo->setId(++m_currentMoveObjId);
	mo->setParty(kEnemyParty);
	mo->setToward(toward);
	mo->retain();
	if(isForcePlaceInTerrain)
	{
		doForcePlaceInTerrain(mo);
	}
	m_enemyMoveObjects.insert(std::make_pair(mo->getId(), mo));

	mo->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyMoveObjectAdd(mo, isHide);
	}

	if(mo->getType() == BattleMoveObject::kGeneral)
	{
		m_battleRecord->addEnemyGeneral(mo);
		MonsterAI *ai = mo->getMonsterAI();
		if(ai)
		{
			ai->runBornActions(mo);
		}
		if(m_guideAi)
		{
			m_guideAi->runObjectBornActions(mo);
		}
	}
	else
	{
		//addSoldierBuff(kEnemyParty, mo->getSoldierCommonId());
		//addSceneSoldierBuff();
		applySceneSoldierBuff(mo,0.0f);
	}
	
	MonsterAI::unitNum(mo, true);
    
    if (mo->getType() == BattleMoveObject::kSoldier)
    {
        calcPassiveSkillOpen(kEnemyParty, true);
    }
}

void BattleScene::removeEnemyMoveObject(uint16_t id, float resource)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyMoveObjectRemoved(id, resource);
	}
}

void BattleScene::addFriendMoveObject(BattleMoveObject *mo, bool isHide, bool isForcePlaceInTerrain, int toward)
{
	mo->setId(++m_currentMoveObjId);
	mo->setParty(kFriendParty);
	mo->setToward(toward);
	mo->retain();
	if(isForcePlaceInTerrain)
	{
		doForcePlaceInTerrain(mo);
	}

	m_friendMoveObjects.insert(std::make_pair(mo->getId(), mo));
	mo->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendMoveObjectAdd(mo, isHide);
	}

	if(mo->getType() == BattleMoveObject::kGeneral)
	{
		m_battleRecord->addFriendGeneral(mo);
		calcBattleResourcesSpeed();
		MonsterAI *ai = mo->getMonsterAI();
		if(ai)
		{
			ai->runBornActions(mo);
		}
		if(m_guideAi)
		{
			m_guideAi->runObjectBornActions(mo);
		}
        
        for (auto it = m_views.begin(); it != m_views.end(); ++it)
        {
            (*it)->onFriendGeneralNumChanged();
        }
		dealPassEnemyTroopRunAway(mo);
	}
	else
	{
		//addSoldierBuff(kFriendParty, mo->getSoldierCommonId());
		//addSceneSoldierBuff();
		applySceneSoldierBuff(mo, 0.0f);
	}
	
	MonsterAI::unitNum(mo, true);
    
    if (mo->getType() == BattleMoveObject::kSoldier)
    {
        calcPassiveSkillOpen(kFriendParty, true);
    }
	BattleSceneView::getCurrentSceneView()->fromInitBattleSceneCameraToAutoTracking();
}

void BattleScene::removeFriendMoveObject(uint16_t id, float resource)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendMoveObjectRemoved(id, resource);
	}
}

BattleScene::IDMoveObject::iterator BattleScene::disappearEnemyMoveObject(uint16_t id)
{
	IDMoveObject::iterator iter = removeMoveObject_(id, kEnemyParty);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyMoveObjectDisappear(id);
	}

	return iter;
}

BattleScene::IDMoveObject::iterator BattleScene::disappearFriendMoveObject(uint16_t id)
{
	IDMoveObject::iterator iter = removeMoveObject_(id, kFriendParty);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendMoveObjectDisappear(id);
	}

	return iter;
}

static BattleScene::IDBuilding::iterator removebuilding(BattleScene::IDBuilding *buildings, uint16_t id)
{
	BattleScene::IDBuilding::iterator iter = buildings->find(id);
	if (iter != buildings->end())
	{
		BattleBuilding *building = iter->second;
		building->cleanUp();
		building->release();
		return buildings->erase(iter);
	}
	else
	{
		assert(false);
		return iter;
	}
}
BattleScene::IDBuilding::iterator BattleScene::disappearEnemyBuilding(uint16_t id)
{
	IDBuilding::iterator iter = removebuilding(&m_enemyBuildings, id);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyBuildingDisappear(id);
	}

	return iter;
}

BattleScene::IDBuilding::iterator BattleScene::disappearFriendBuilding(uint16_t id)
{
	IDBuilding::iterator iter = removebuilding(&m_friendBuildings, id);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendBuildingDisappear(id);
	}

	return iter;
}

static BattleScene::IDTower::iterator removeTower(BattleScene::IDTower *towers, uint16_t id)
{
	BattleScene::IDTower::iterator iter = towers->find(id);
	if (iter != towers->end())
	{
		BattleTower *tower = iter->second;
		tower->cleanUp();
		tower->release();
		return towers->erase(iter);
	}
	else
	{
		assert(false);
		return iter;
	}
}

bool BattleScene::isOnlyLeftLowestObjects(char party, const AoiData &data, const std::set<uint16_t> &lowestObjects) const
{
	const IDBuilding &buildings = (party == kFriendParty) ? m_friendBuildings : m_enemyBuildings;
	const IDTower &towers = (party == kFriendParty) ? m_friendTowers : m_enemyTowers;
	const IDMoveObject &moveObjs = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;

	for (auto it = buildings.cbegin(); it != buildings.cend(); ++it)
	{
		if (it->second->canBeFound(data) && it->second->getSubType() == BattleStaticObject::kShelter)
		{
			if (lowestObjects.find(it->second->getId()) == lowestObjects.end())
			{
				return false;
			}
		}
	}

	for (auto it = towers.cbegin(); it != towers.cend(); ++it)
	{
		if (it->second->canBeFound(data))
		{
			if (lowestObjects.find(it->second->getId()) == lowestObjects.end())
			{
				return false;
			}
		}
	}

	for (auto it = moveObjs.cbegin(); it != moveObjs.cend(); ++it)
	{
		if (it->second->canBeFound(data))
		{
			if (lowestObjects.find(it->second->getId()) == lowestObjects.end())
			{
				return false;
			}
		}
	}

	return true;
}

BattleScene::IDTower::iterator BattleScene::disappearEnemyTower(uint16_t id)
{
	IDTower::iterator iter = removeTower(&m_enemyTowers, id);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyTowerDisappear(id);
	}

	return iter;
}

void BattleScene::addEnemyBuilding(BattleBuilding *building, bool isRunshowAction)
{
	building->setToward(BattleObject::kRightDown);
	building->setId(++m_currentBuildingId);
	building->setParty(kEnemyParty);
	building->retain();

	m_enemyBuildings.insert(std::make_pair(building->getId(), building));
	building->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyBuildingAdd(building, isRunshowAction);
	}

	MonsterAI *ai = building->getMonsterAI();
	if(ai)
	{
		ai->runBornActions(building);
	}
}

void BattleScene::addFriendBuilding(BattleBuilding *building, bool isRunshowAction)
{
	building->setToward(BattleObject::kRightDown);
	building->setId(++m_currentBuildingId);
	building->setParty(kFriendParty);
	building->retain();

	m_friendBuildings.insert(std::make_pair(building->getId(), building));
	building->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendBuildingAdd(building, isRunshowAction);
	}
}

void BattleScene::removeEnemyBuilding(uint16_t id, float resource)
{
	int barrackIndex = getBarrackIndex(id);
	bool isNotBossBarrack = (!isBossBarrack(kEnemyParty, id) && (barrackIndex >= 0));
	if(isNotBossBarrack)
	{
		handleBarrackOccupy(barrackIndex);
	}
	
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyBuildingRemoved(id, resource);
	}
}

void BattleScene::removeFriendBuilding(uint16_t id, float resource)
{
	int barrackIndex = getBarrackIndex(id);
	bool isNotBossBarrack = (!isBossBarrack(kFriendParty, id) && (barrackIndex >= 0));
	if(isNotBossBarrack)
	{
		handleBarrackOccupy(barrackIndex);
	}

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendBuildingRemoved(id, resource);
	}
}

void BattleScene::addEnemyTower(BattleTower *tower)
{
	tower->setToward(BattleObject::kRightDown);
	tower->setId(++m_currentTowerId);
	tower->setParty(kEnemyParty);
	tower->retain();

	m_enemyTowers.insert(std::make_pair(tower->getId(), tower));
	tower->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyTowerAdd(tower);
	}

	MonsterAI *ai = tower->getMonsterAI();
	if(ai)
	{
		ai->runBornActions(tower);
	}
}

void BattleScene::addFriendTower(BattleTower *tower)
{
	tower->setToward(BattleObject::kRightDown);
	tower->setId(++m_currentTowerId);
	tower->setParty(kFriendParty);
	tower->retain();

	m_friendTowers.insert(std::make_pair(tower->getId(), tower));
	tower->initWithTerrain(m_terrain);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendTowerAdd(tower);
	}
}

void BattleScene::removeEnemyTower(uint16_t id, float resource)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onEnemyTowerRemoved(id, resource);
	}
}

void BattleScene::removeFriendTower(uint16_t id, float resource)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendTowerRemoved(id, resource);
	}
}

void BattleScene::runStaticObjNumReduceActions()
{
	RUN_ACTIONS(runStaticObjNumReduceActions);
}

void BattleScene::runObjectsHpActions(BattleObject *object, int lastHp, int curHp)
{
	RUN_STATIC_GTP_ACTIONS(m_friendBuildings, runObjectsHpActions, object, lastHp, curHp);
	RUN_STATIC_GTP_ACTIONS(m_enemyBuildings, runObjectsHpActions, object, lastHp, curHp);
	RUN_STATIC_GTP_ACTIONS(m_friendTowers, runObjectsHpActions, object, lastHp, curHp);
	RUN_STATIC_GTP_ACTIONS(m_enemyTowers, runObjectsHpActions, object, lastHp, curHp);

	RUN_GTP_ACTIONS(m_friendGenGeneralPoints, runObjectsHpActions, object, lastHp, curHp);
	RUN_GTP_ACTIONS(m_enemyGenGeneralPoints, runObjectsHpActions, object, lastHp, curHp);

	RUN_GUIDE_ACTIONS(runObjectsHpActions, object, lastHp, curHp);
}
void BattleScene::runMoveObjectDeadActions()
{
	RUN_GTP_ACTIONS(m_friendGenGeneralPoints, runDeadActions);
	RUN_GTP_ACTIONS(m_enemyGenGeneralPoints, runDeadActions);
}

void BattleScene::onFriendPartyInBattle()
{
	if(!m_isEnterBattle)
	{
		m_startBattleTime = m_battleTime;
		m_isEnterBattle = true;

		RUN_ACTIONS(runBattleStartActions);
	}
}

void BattleScene::handleStarInfoRefresh()
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBattleStarInfoRefresh();
	}
}

void BattleScene::handleFriendSoldierNumChange(int tid)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onFriendSoldierNumChanged(tid);
	}
}

void BattleScene::handleFriendSoldierUpperLimitChange()
{
    for (size_t i = 0; i < m_views.size(); ++i)
    {
        m_views[i]->onFriendSoldierUpperLimitChanged();
    }
}

void BattleScene::onMoveObjAttack(BattleMoveObject *attacker, uint16_t targetId)
{
	assert(targetId > 0);
	/*if(attacker->getType() == BattleMoveObject::kSoldier)
	{
		int soldierBattleSoundId = attacker->getSoldierBattleSoundId();
		if(soldierBattleSoundId > 0)
		{
			m_moveObjInAtkCnt.updateSoldierNumInAttack(soldierBattleSoundId, 1);
			for (size_t i = 0; i < m_views.size(); ++i)
			{
				m_views[i]->onSoldierAttackNumChanged(soldierBattleSoundId);
			}
		}
	}*/

	if(getObjectType(targetId) == kMoveObj)
	{
		m_moveObjInAtkCnt.moveObjNumInAttackMoveObj++;
		for (size_t i = 0; i < m_views.size(); ++i)
		{
			m_views[i]->onMoveObjAttackMoveObjNumChanged();
		}
	}
}

int BattleScene::getCityDoorHp()
{
	vector<BattleBuilding *> buildings;
	getBuildings(&buildings, kEnemyParty, TargetSelect::kBuilding);
	int retHp = 0;
	for (auto iter = buildings.begin(); iter != buildings.end(); ++iter)
	{
		BattleBuilding * building = *iter;

		if (building->getBuildingType() == BattleBuilding::kDoor)
		{
			retHp = retHp + building->getHp();
		}
	}
	return retHp;
}

void BattleScene::onMoveObjUnAttack(BattleMoveObject *attacker, uint16_t targetId)
{
	assert(targetId > 0);
	/*if(attacker->getType() == BattleMoveObject::kSoldier)
	{
		int soldierBattleSoundId = attacker->getSoldierBattleSoundId();
		if(soldierBattleSoundId > 0)
		{
			m_moveObjInAtkCnt.updateSoldierNumInAttack(soldierBattleSoundId, -1);
			for (size_t i = 0; i < m_views.size(); ++i)
			{
				m_views[i]->onSoldierAttackNumChanged(soldierBattleSoundId);
			}
		}
	}*/

	if(getObjectType(targetId) == kMoveObj)
	{
		m_moveObjInAtkCnt.moveObjNumInAttackMoveObj--;
		for (size_t i = 0; i < m_views.size(); ++i)
		{
			m_views[i]->onMoveObjAttackMoveObjNumChanged();
		}
	}
}

void BattleScene::visitEveryEnemyMoveObject(std::function<void (BattleMoveObject *)> func)
{
	IDMoveObject::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::visitEveryFriendMoveObject(std::function<void (BattleMoveObject *)> func)
{
	IDMoveObject::iterator iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::visitEveryEnemyBuilding(std::function<void (BattleBuilding *)> func)
{
	IDBuilding::iterator iter = m_enemyBuildings.begin();
	for (; iter != m_enemyBuildings.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::visitEveryFriendBuilding(std::function<void (BattleBuilding *)> func)
{
	IDBuilding::iterator iter = m_friendBuildings.begin();
	for (; iter != m_friendBuildings.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::visitEveryEnemyTower(std::function<void (BattleTower *)> func)
{
	IDTower::iterator iter = m_enemyTowers.begin();
	for (; iter != m_enemyTowers.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::visitEveryFriendTower(std::function<void (BattleTower *)> func)
{
	IDTower::iterator iter = m_friendTowers.begin();
	for (; iter != m_friendTowers.end(); ++iter)
	{
		func(iter->second);
	}
}

void BattleScene::setCurrentScene(BattleScene *scene)
{
	s_currentScene = scene;
}

BattleMoveObject *BattleScene::getGeneral(int tid)
{
	BattleMoveObject *general = getFriendGeneral(tid);
	if(general)
	{
		return general;
	}

	return getEnemyGeneral(tid);
}

static BattleMoveObject *getGeneral_(const vector<BattleMoveObject *> &generals, int tid)
{
	for(auto iter = generals.cbegin(); iter != generals.cend(); ++iter)
	{
		BattleMoveObject *general = *iter;
		if(general->getTid() == tid)
		{
			return general;
		}
	}

	return nullptr;
}

BattleMoveObject *BattleScene::getFriendGeneral(int tid)
{
	return getGeneral_(m_battleRecord->getFriendGenerals(), tid);
}

BattleMoveObject *BattleScene::getEnemyGeneral(int tid)
{
	return getGeneral_(m_battleRecord->getEnemyGenerals(), tid);
}

BattleObject *BattleScene::getObject(uint16_t objectId)
{
	switch(getObjectType(objectId))
	{
	case kMoveObj:
		return getMoveObject(objectId);
	case kBuilding:
		return getBuilding(objectId);
	case kTower:
		return getTower(objectId);
	default:
		assert(false);
		return nullptr;
	}
}

BattleMoveObject *BattleScene::getMoveObject(uint16_t objectId)
{
	BattleMoveObject *mo = getObject_(m_enemyMoveObjects, objectId);
	if(mo)
	{
		return mo;
	}

	mo = getObject_(m_friendMoveObjects, objectId);
	if(mo)
	{
		return mo;
	}

	return nullptr;
}

BattleBuilding *BattleScene::getBuilding(uint16_t objectId)
{
	BattleBuilding *building = getObject_(m_enemyBuildings, objectId);
	if(building)
	{
		return building;
	}

	return getObject_(m_friendBuildings, objectId);
}

BattleTower *BattleScene::getTower(uint16_t objectId)
{
	BattleTower *tower = getObject_(m_enemyTowers, objectId);
	if(tower)
	{
		return tower;
	}

	return getObject_(m_friendTowers, objectId);
}

BattleTroop *BattleScene::getTroop(unsigned char troopId)
{
	BattleTroop *troop = m_enemyTroops->getTroop(troopId);
	if(troop)
	{
		return troop;
	}

	return m_friendTroops->getTroop(troopId);
}

void BattleScene::attackBegin(const AttackTargetInfo &targetInfo)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onAttackBegin(targetInfo);
	}
}

void BattleScene::initTroopSet()
{
	m_friendTroops->init(kFriendParty);
	m_enemyTroops->init(kEnemyParty);

	if (isInThisBattleMode(MainScene::kBattleDungeonTraining))	//练兵副本初始化牢笼部队
	{
		for (int i = 1; i <= m_nodeNum; i++)
		{
			BattleTroop *bt = m_friendTroops->getTroopByNodeIndex(i+m_nodeNum);
			if (bt)
			{
				bt->retain();
				m_battleStatistics.addCageTroop(bt);
				CageSoldier cs;
				cs.soldierId = bt->getSoldierTid();
				cs.num = bt->getSoldierNum();
				m_battleStatistics.addCageSoldier(cs);
			}
			
		}
	}
	
}

void BattleScene::recruitSoldiers(char party, int soldierTid, int soldierCount)
{
	m_battleRecord->recruitSoldiers(party, soldierTid, soldierCount);
	if(party == kFriendParty)
	{
		handleFriendSoldierNumChange(soldierTid);
	}
}

void BattleScene::recruitSoldiers(char party, uint16_t generalId, int soldierTid, int soldierCount)
{
	m_battleRecord->recruitSoldiers(party, generalId, soldierTid, soldierCount);
	if(party == kFriendParty && !getMoveObject(generalId)->isMonster())
	{
		handleFriendSoldierNumChange(soldierTid);
	}
}

void BattleScene::recruitFullSoldiers(char party, uint16_t generalId, int soldierTid)
{
	m_battleRecord->recruitFullSoldiers(party, generalId, soldierTid);
	if(party == kFriendParty && !getMoveObject(generalId)->isMonster())
	{
		handleFriendSoldierNumChange(soldierTid);
	}
}

void BattleScene::createAmbushTroop(char party, int soldierTid, int soldierNum, const GridPosition &troopPos, const ObjectBarrackInfo &info)
{
	vector<WayPoint> routePoints;
	getRoutePoints(&routePoints, party, troopPos, BattleMoveObject::kSoldier);
	BattleTroopSet *troops = (party == kFriendParty) ? m_friendTroops : m_enemyTroops;
	troops->createTroop(m_currentNodeIndex, 0, troopPos, party, soldierTid, soldierNum, routePoints, info.barrackIndex);
}

unsigned char BattleScene::createTroop(char party, int nodeIndex, int direction, int soldierTid, int soldierNum, bool isMonster, const GridPosition &troopPos, bool isForcePlaceInTerrain, int troopIndex, int match)
{
	BattleTroopSet *troops = (party == kFriendParty) ? m_friendTroops : m_enemyTroops;
	return troops->createTroop(party, nodeIndex, direction, soldierTid, soldierNum, isMonster, troopPos, isForcePlaceInTerrain, troopIndex, match);
}

void  BattleScene::createArmyTroop(char party, int nodeIndex, int direction)
{
	BattleTroopSet *troops = (party == kFriendParty) ? m_friendTroops : m_enemyTroops;

	if (party == kFriendParty)
	{
		std::map<int, std::vector<GameSoldier *>> *friendSoldiers = GameSoldierManager::theMgr()->getGameSoldiers(kFriendParty);
		int match = 1;
		for (auto it1 = friendSoldiers->begin(); it1 != friendSoldiers->end(); ++it1)
		{
			bool isAttackCity = it1->first == 9;
			troops->createArmyTroop(party, nodeIndex, it1->first, direction, isAttackCity, match);
			match++;
		}
	}
	else
	{
		std::map<int, std::vector<GameSoldier *>> *enemySoldiers = GameSoldierManager::theMgr()->getGameSoldiers(kEnemyParty);
		int match = 1;
		for (auto it2 = enemySoldiers->begin(); it2 != enemySoldiers->end(); ++it2)
		{
			bool isAttackCity = (it2->first == 9);
			troops->createArmyTroop(party, nodeIndex, it2->first, direction, isAttackCity, match);
			match++;
		}
	}
}

void BattleScene::initStaticBuilding(const vector<AiObjectInfo> &objects, bool isFriendParty)
{
	for (size_t i = 0; i < objects.size(); ++i)
	{
		const AiObjectInfo &info = objects[i];
		GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(info.obj.position.x, info.obj.position.y);
		int tid = info.obj.tid;

		tid = LuaLogicUtil::initStaticObjectByLua(tid);
		BattleBuilding *bb = nullptr;
		BuildingType type = (BuildingType)LuaLogicUtil::getBuildingTypeByLua(tid);
		if (type == kNormalBuilding)
		{
			bb = BattleBuilding::create(tid, grid, info.obj.nodeIndex);
		}
		else
		{
			/*tid = LuaLogicUtil::getTrapTidFromLuaWithPosTid(tid);
			if (tid == 0)
			{
				continue;
			}
			int code = LuaLogicUtil::canTrapTrigger(tid);
			if (code != 0)
			{
				continue;
			}*/
			bb = BattleTrap::create(tid, grid, info.obj.nodeIndex,true);
		}		

		bb->initAI(info.ais);
		bb->setPixelPosition(pointToPix(info.obj.position));
		bb->setIndex(i);
		if (isFriendParty)
		{
			addFriendBuilding(bb, false);
		}
		else
		{
			addEnemyBuilding(bb, false);
			
			if(isInThisBattleMode(MainScene::kBattleDungeonRes))
			{
				getLowestTarget().addLowestObject(kEnemyParty, bb->getId());
			}
		}
	}
}

void BattleScene::initStaticTower(const vector<AiObjectInfo> &objects, bool isFriendParty)
{
	for (size_t i = 0; i < objects.size(); ++i)
	{
		const AiObjectInfo &info = objects[i];
		GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(info.obj.position.x, info.obj.position.y);

		int tid = info.obj.tid;

		tid = LuaLogicUtil::initStaticObjectByLua(tid);

		bool isPvp = false;
		if(isInThisBattleMode(MainScene::kBattlePVP))
		{
			//tid = getPvpTowerTid(isFriendParty);
			isPvp = true;
		}
		BattleTower *bt = BattleTower::create(tid, grid, info.obj.nodeIndex);
		bt->setPvp(isPvp);
		bt->initProps(tid);
		bt->initAI(info.ais);
		bt->setPixelPosition(pointToPix(info.obj.position));
		bt->setIndex(i);
		if (isFriendParty)
		{
			addFriendTower(bt);
		}
		else
		{
			addEnemyTower(bt);
		}	
	}
}

vector<int> BattleScene::getEnemyGeneralIdsByNode(int nodeIndex)
{
	vector<int> ids;
	const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);

	
	for (auto iter = scenePty.enemy_gen_troop_points.begin(); iter != scenePty.enemy_gen_troop_points.end(); ++iter)
	{
		if (iter->obj.nodeIndex == nodeIndex)
		{
			vector<const char*> tIds = GENGENERALPOINTACTION_GENERAL_ID(GENGENERALPOINT_ACTION(iter->obj.tid)[0]);

			for (auto iter1 = tIds.begin(); iter1 != tIds.end(); ++iter1)
			{
				string s(*iter1);
				trimStr(&s, ' ');
				vector<string> strIds = split(s, ",");
				for(auto iter2 = strIds.begin(); iter2 != strIds.end(); ++iter2)
				{
					ids.push_back( atoi((*iter2).c_str()) );
				}
			}
		}
	}
	return ids;
}

void BattleScene::initStaticObject()
{
	if (!isInThisBattleMode(MainScene::kBattleArena))
	{
		const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);
		
		if (isInThisBattleMode(MainScene::kBattlePass))
		{
			initStaticBuilding(scenePty.friend_buildings, true);
		}
		if (isInThisBattleMode(MainScene::kBattlePass) || (LuaLogicUtil::getWallDefence() > 0 && isInThisBattleMode(MainScene::kBattlePVP)))		//城防值为0则不创建敌方城墙
		{
			initStaticBuilding(scenePty.enemy_buildings, false);
		}
		
		
		initStaticTower(scenePty.friend_towers, true);

		if (isInThisBattleMode(MainScene::kBattlePass) || (LuaLogicUtil::getTowerDefence() > 0 && isInThisBattleMode(MainScene::kBattlePVP)))		//城防值为0则不创建敌方箭塔
		{
			initStaticTower(scenePty.enemy_towers, false);
		}

		if (isInThisBattleMode(MainScene::kBattlePass))
		{
			initStaticBuilding(scenePty.enemy_traps, false);
		}

		if (isInThisBattleMode(MainScene::kBattlePass))
		{
			initGenGeneralPoint(scenePty.friend_gen_troop_points, kFriendParty);
			initGenGeneralPoint(scenePty.enemy_gen_troop_points, kEnemyParty);
		}
		vector<BattleBuilding *> buildings;
		BattleScene::getCurrentScene()->getBuildings(&buildings, kEnemyParty, TargetSelect::kSlgTrap);
		for (auto iter = buildings.begin(); iter != buildings.end(); ++iter)
		{
			BattleTrap * trap = dynamic_cast<BattleTrap*>(*iter);
			if (trap == NULL)
			{
				assert(false);
			}
			else
			{
				trap->checkMyHangOnObj();
			}
		}
	}
}

void BattleScene::initPVPGeneral(const GeneralBase &info, int party)
{
}

void BattleScene::initPVPSoldier(const DefendSoldierInfo &info, int party)
{
	int soldierNum = 1;// SOLDIER_TROOP_NUMBER(info.soldier_id);
	int consume = 1;// SOLDIER_CONSUME_FOOD(info.soldier_id);
	if (party == kFriendParty)
	{
		costBattleResource((float)(consume + getFriendResourcesConsume()));
	}
	else
	{
		BattlePvp::thePvp()->costBattleRes(consume + getEnemyResourcesConsume());
	}

	recruitSoldiers(party, info.soldier_id, soldierNum);
}

void BattleScene::initMoveObject()
{
	const BattleSceneProperty &scenePty = getBattleScene(m_sceneId);

	initGenerals(scenePty.friend_generals, kFriendParty);
	initGenerals(scenePty.enemy_generals, kEnemyParty);
}

void BattleScene::initGuideAi(const vector<int> &aiIds)
{
	if(aiIds.empty()) return;
	m_guideAi = MonsterAI::create(kFriendParty, aiIds);
}

void BattleScene::initGenerals(const std::vector<AiObjectInfo> &objects, char party)
{
	
}

BattleMoveObject *BattleScene::createGeneral(char party, int tid, int nodeIndex, const GridPosition &position, const ObjectBarrackInfo &info, bool isGather)
{
    
	return nullptr;
}

void BattleScene::initGenGeneralPoint(const vector<GenGeneralPointInfo> &objects, char party)
{
	for(auto iter = objects.cbegin(); iter != objects.cend(); ++iter)
	{
		const GenGeneralPointInfo &info = *iter;
		GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(info.obj.position.x, info.obj.position.y);
		int tid = info.obj.tid;
		GenGeneralPoint *gtp = GenGeneralPoint::create(party, tid, grid, info.obj.nodeIndex, info.toward);
		gtp->retain();
		if(party == kFriendParty)
		{
			m_friendGenGeneralPoints.push_back(gtp);
		}
		else
		{
			m_enemyGenGeneralPoints.push_back(gtp);
		}
	}
}

bool BattleScene::isStaicBarrier(int x, int y)
{
	return m_terrain->isStaicBarrier(x, y);
}

const list<uint16_t> &BattleScene::getGridObjects(int x, int y)
{
	return m_terrain->getGridObjects(x, y);
}

void BattleScene::setMaxFindPathNodeNum(int num)
{
	m_terrain->setMaxNodeNum(num);
}

static std::vector<BattleMoveObject *> pickUpGenerals(const BattleScene::IDMoveObject &soldiers)
{
	std::vector<BattleMoveObject *> generals;
	BattleScene::IDMoveObject::const_iterator iter = soldiers.begin();
	for (; iter != soldiers.end(); ++iter)
	{
		if (iter->second->getType() == BattleMoveObject::kGeneral)
		{
			generals.push_back(iter->second);
		}
	}

	return generals;
}

std::vector<BattleMoveObject *> BattleScene::getEnemyGenerals()
{
	return pickUpGenerals(m_enemyMoveObjects);
}

std::vector<BattleMoveObject *> BattleScene::getGenerals()
{
    return pickUpGenerals(m_friendMoveObjects);
}

static bool runToRegionNearestEnemy(BattleScene *scene, BattleMoveObject *object, int regionX, int regionY)
{
	BattleTerrain *terrain = scene->getTerrain();
	if(!terrain->isValidRegion(regionX, regionY)) return false;

	static FloatRect s_rect;
	static Nearest s_nearest;
	BattleRegion &region = const_cast<BattleRegion &>(terrain->getRegion(regionX, regionY));
	region.setIsMargin(false);
	region.getNearestEnemy(&s_nearest, object->isAntiCloak(), object->getNodeIndex(), object->getParty(), object->getFloatGridPosition(), s_rect);
	if(s_nearest.enemyId > 0)
	{
		object->runToGrid(scene->getObject(s_nearest.enemyId)->getGridPosition());
		return true;
	}

	return false;
}
// 相对最近，不保证绝对最近
bool BattleScene::runToNearOppoObject(BattleMoveObject *object)
{
	const RegionPosition &position = object->getRegionPosition();
	if(runToRegionNearestEnemy(this, object, position.x, position.y)) return true;

	int x = 0, y = 0;
	int maxNum = max(m_terrain->getWidthInRegion(), m_terrain->getHeightInRegion());
	for(int j = 1; j <= maxNum; j++)
	{
		x = position.x + j;
		y = position.y;
		if(runToRegionNearestEnemy(this, object, x, y)) return true;
		x = position.x - j;
		if(runToRegionNearestEnemy(this, object, x, y)) return true;

		x = position.x;
		y = position.y + j;
		if(runToRegionNearestEnemy(this, object, x, y)) return true;
		y = position.y - j;
		if(runToRegionNearestEnemy(this, object, x, y)) return true;

		for(int i = 1; i <= j; i++)
		{
			x = position.x + j;
			y = position.y + i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;
			y = position.y - i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;

			x = position.x - j;
			y = position.y + i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;
			y = position.y - i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;

			if(i == j) continue;

			x = position.x + i;
			y = position.y + j;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;
			x = position.x - i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;

			x = position.x + i;
			y = position.y - j;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;
			x = position.x - i;
			if(runToRegionNearestEnemy(this, object, x, y)) return true;
		}
	}

	assert(false);
	return false;
}

int BattleScene::getNearestOppoSoldierPos(GridPosition *targetPos, char party, const GridPosition &position, PriorTarget *priorTarget, bool isAntiCloak, int nodeIndex)
{
	IDMoveObject &soldiers = (party == kFriendParty) ? m_enemyMoveObjects : m_friendMoveObjects;
	BattleTroopSet *troops = (party == kFriendParty) ? m_enemyTroops : m_friendTroops;
	int minSquare = (numeric_limits<int>::max)();
	for(IDMoveObject::iterator iter = soldiers.begin(); iter != soldiers.end(); ++iter)
	{
		BattleMoveObject *soldier = iter->second;
		if(soldier->getTroopId() > 0)
		{
			if(priorTarget && !troops->isCandidate(soldier->getTroopId(), priorTarget)) continue;
		}
		else
		{
			if(priorTarget && !priorTarget->isCandidate(soldier)) continue;
		}
		if(!soldier->canBeFound(isAntiCloak, nodeIndex)) continue;

		int square = squareOf(position, soldier->getGridPosition());
		if(square < minSquare)
		{
			minSquare = square;
			*targetPos = soldier->getGridPosition();
		}
	}

	return minSquare;
}

int BattleScene::getNearestOppoStaticObjPos(GridPosition *targetPos, char party, const GridPosition &position, PriorTarget *priorTarget, bool isAntiCloak, int nodeIndex)
{
	IDBuilding &buildings = (party == kFriendParty) ? m_enemyBuildings : m_friendBuildings;
	int minSquare = (numeric_limits<int>::max)();
	char oppoParty = getOppoParty(party);
	for(IDBuilding::iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
	{
		BattleBuilding *building = iter->second;
		if(priorTarget && !priorTarget->isCandidate(building)) continue;
		if(!building->canBeFound(isAntiCloak, nodeIndex)) continue;
		if(getLowestTarget().isLowestObject(oppoParty, building->getId()) && !getLowestTarget().isOnlyLeftLowestObject(oppoParty, isAntiCloak, nodeIndex)) continue;
		int square = squareOf(position, building->getGridPosition());
		if(square < minSquare)
		{
			minSquare = square;
			*targetPos = building->getGridPosition();
		}
	}

	IDTower &towers = (party == kFriendParty) ? m_enemyTowers : m_friendTowers;
	for(IDTower::iterator iter = towers.begin(); iter != towers.end(); ++iter)
	{
		BattleTower *tower = iter->second;
		if(priorTarget && !priorTarget->isCandidate(tower)) continue;
		if(!tower->canBeFound(isAntiCloak, nodeIndex)) continue;
		if(getLowestTarget().isLowestObject(oppoParty, tower->getId()) && !getLowestTarget().isOnlyLeftLowestObject(oppoParty, isAntiCloak, nodeIndex)) continue;
		int square = squareOf(position, tower->getGridPosition());
		if(square < minSquare)
		{
			minSquare = square;
			*targetPos = tower->getGridPosition();
		}
	}

	return minSquare;
}

bool BattleScene::isStaticObjHaveCandidate(PriorTarget *priorTarget, char party)
{
	assert(priorTarget);
	IDTower &towers = (party == kFriendParty) ? m_enemyTowers : m_friendTowers;
	for(IDTower::iterator iter = towers.begin(); iter != towers.end(); ++iter)
	{
		BattleTower *tower = iter->second;
		if(!priorTarget->isCandidate(tower)) continue;
		return true;
	}

	IDBuilding &buildings = (party == kFriendParty) ? m_enemyBuildings : m_friendBuildings;
	for(IDBuilding::iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
	{
		BattleBuilding *building = iter->second;
		if(!priorTarget->isCandidate(building)) continue;
		return true;
	}

	return false;
}

bool BattleScene::isHaveCandidate(PriorTarget *priorTarget, char party)
{
	if(priorTarget == nullptr) return false;

	BattleTroopSet *troops = (party == kFriendParty) ? m_enemyTroops : m_friendTroops;
	if(troops->isHaveCandidate(priorTarget)) return true;

	if(m_battleRecord->isHaveCandidate(priorTarget, party)) return true;

	IDMoveObject &soldiers = (party == kFriendParty) ? m_enemyMoveObjects : m_friendMoveObjects;
	for(auto it = soldiers.begin(); it != soldiers.end(); ++it)
	{
		BattleMoveObject *object = it->second;
		if(object->getType() == BattleMoveObject::kSoldier && object->getTroopId() == 0)
		{
			if(priorTarget->isCandidate(object))
			{
				return true;
			}
		}
	}

	if(isStaticObjHaveCandidate(priorTarget, party)) return true;

	return false;
}

bool BattleScene::getTargetPos(GridPosition *targetPos, char party, const GridPosition &position, PriorTarget *priorTarget, bool isAntiCloak, int nodeIndex)
{
	if(priorTarget && !isHaveCandidate(priorTarget, party)) priorTarget = nullptr; // 若无优先目标，则不执行优先目标选择的AI
	
	GridPosition targetSoldierPos(-1,-1), targetGeneralPos(-1,-1), targetStaticPos(-1,-1);
	int targetSoldierDis = getNearestOppoSoldierPos(&targetSoldierPos, party, position, priorTarget, isAntiCloak, nodeIndex);
	int targetGeneralDis = m_battleRecord->getNearestOppoGeneralPos(&targetGeneralPos, party, position, priorTarget, isAntiCloak, nodeIndex);
	int targetStaticDis = getNearestOppoStaticObjPos(&targetStaticPos, party, position, priorTarget, isAntiCloak, nodeIndex);

	if(targetSoldierDis == (numeric_limits<int>::max)() && targetGeneralDis == (numeric_limits<int>::max)() && targetStaticDis == (numeric_limits<int>::max)())
	{
		return false;
	}

	if(targetSoldierDis < targetGeneralDis)
	{
		if(targetStaticDis < targetSoldierDis)
		{
			*targetPos = targetStaticPos;
		}
		else
		{
			*targetPos = targetSoldierPos;
		}
	}
	else
	{
		if(targetStaticDis < targetGeneralDis)
		{
			*targetPos = targetStaticPos;
		}
		else
		{
			*targetPos = targetGeneralPos;
		}
	}
	assert(targetPos->x >= 0 && targetPos->y >= 0);
	return true;
}

void BattleScene::lookOver(const cocos2d::CCPoint &pt)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onLookOver(pt);
	}
}

void BattleScene::callGeneral()
{
	std::vector<BattleMoveObject *> generals = getGenerals();
	for (size_t i = 0; i < generals.size(); ++i)
	{
		generals[i]->callGeneral();
	}
}

GridPosition BattleScene::getFriendBornPosition()
{
	if(m_passType == kTowerDefensePass)
	{
		return m_friendBornPoint;
	}
	if(isInThisBattleMode(MainScene::kBattleArena))
	{
		if(isPvpInitState(kFriendParty))
		{
			return m_friendBornPoint;
		}
		else
		{
			return m_friendWayPoint;
		}
	}
	else if(isInThisBattleMode(MainScene::kBattleCrusade))
	{
		if(isPvpInitState(kFriendParty) || m_friendBuildings.size() == 1)
		{
			return m_barrackBornInfo->getBornPosition();
		}
		else
		{
			for(auto it = m_friendBuildings.begin(); it != m_friendBuildings.end(); ++it)
			{
				if(it->first != m_friendBossBarrack)
				{
					const GridRect &rect = it->second->getIntRect();
					return GridPosition(rect.rb.x + 2, it->second->getGridPosition().y);
				}
			}
		}
	}

	return m_barrackBornInfo->getBornPosition();
}

GridPosition BattleScene::getEnemyBornPosition()
{
	if(isInThisBattleMode(MainScene::kBattlePVP))
	{
		if(isPvpInitState(kEnemyParty))
		{
			BattleBuilding *bossBarrack = getBuilding(m_enemyBossBarrack);
			const GridRect &rect = bossBarrack->getIntRect();
			return GridPosition(bossBarrack->getGridPosition().x, rect.rb.y - 2);
			
		}
		else
		{
			return m_barrackBornInfo->getNextBornPosition();
		}
	}
	else if(isInThisBattleMode(MainScene::kBattleCrusade))
	{
		if(isPvpInitState(kEnemyParty) || m_enemyBuildings.size() == 1)
		{
			BattleBuilding *bossBarrack = getBuilding(m_enemyBossBarrack);
			const GridRect &rect = bossBarrack->getIntRect();
			return GridPosition(bossBarrack->getGridPosition().x, rect.rb.y - 2);
		}
		else
		{
			for(auto it = m_enemyBuildings.begin(); it != m_enemyBuildings.end(); ++it)
			{
				if(it->first != m_enemyBossBarrack)
				{
					const GridRect &rect = it->second->getIntRect();
					return GridPosition(rect.rb.x + 2, it->second->getGridPosition().y);
				}
			}
		}
	}
	else if(isInThisBattleMode(MainScene::kBattleArena))
	{
		if(isPvpInitState(kEnemyParty))
		{
			return m_enemyBornPoint;
		}
		else
		{
			return m_enemyWayPoint;
		}
	}

	else if (isInThisBattleMode(MainScene::kBattleDungeonReward))
	{
		return m_enemyWayPoint;
	}

	assert(false);
	return GridPosition();
}

uint16_t BattleScene::createGeneral(int64_t id, int tid, bool isHide)
{
	return 1;
}

uint16_t BattleScene::createSupportGeneral(const SupportGeneralData &data)
{
    float scaleFactor = cocos2d::Director::sharedDirector()->getContentScaleFactor();
	float offsetX = GridUtil::sharedGridUtil().getHalfTileWidth() / scaleFactor;
    PixelPoint pixel(static_cast<int16_t>(data.position.x / scaleFactor +  + offsetX), static_cast<int16_t>(data.position.y / scaleFactor)); // 武将体积是2*2，所以要加offsetX
    const GridPosition &bornPos =  GridUtil::sharedGridUtil().pixToGrid(pixel.x, pixel.y);
    int battleProp[BattleProp::kBattlePropCount];
    
    BattleMoveObject *general = BattleMoveObject::create(data.tid, bornPos, BattleMoveObject::kGeneral, m_currentNodeIndex);
	general->setPixelPosition(pixel);
    general->setGeneralId(-data.tid);
    general->setParty(kFriendParty);

    initBattleProp(battleProp, data);
    general->initProps(battleProp, data.tid);
    general->setLv(data.level);
    general->setStarLv(data.star);
    general->setGeneralOfficial(data.officialLevel);
    
    general->initSkillInfo(data.skill);
    addFriendMoveObject(general);
    
    vector<WayPoint> routePoints;
    getRoutePoints(&routePoints, kFriendParty, bornPos, BattleMoveObject::kGeneral);
    general->setRoute(routePoints);
    
    vector<BattleHalo *> halos;
    getAllInfluenceHalos(&halos, general->getId());
    general->setHalos(halos);
    
    return general->getId();
}

void BattleScene::addSupportGeneral(const SupportGeneralData &supportGeneralData)
{
    int moveObjectId = createSupportGeneral(supportGeneralData);
    
    for (auto it = m_views.begin(); it != m_views.end(); ++it)
    {
        (*it)->onAddSupportGeneral(supportGeneralData, moveObjectId);
    }
}

void BattleScene::removeSupportGeneral(int64_t generalId)
{
    for (auto it = m_views.begin(); it != m_views.end(); ++it)
    {
        (*it)->onRemoveSupportGeneral(generalId);
    }
}

void BattleScene::setFirstCreateGeneralInitMp(BattleMoveObject *general)
{
   /* float mp = getNotCallGeneralMp(general->getTid(), general->getParty());
    if ( !general->isMonster() && general->getType() != BattleMoveObject::kSoldier)
    {
        float power = SCENE_INITIAL_POWER(getId());
        mp += power * general->getMpMax();
    }

    general->changeGeneralMp(general->getInitMp() + mp);*/
}

void BattleScene::pause()
{
	if(m_isExit)
	{
		return;
	}

	allStopRunning();
	stopAllEffects();

	IDMoveObject::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
		iter->second->pause();

	iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
		iter->second->pause();

	IDTower::iterator iter1 = m_enemyTowers.begin();
	for (; iter1 != m_enemyTowers.end(); ++iter1)
	{
		iter1->second->pause();
	}

	iter1 = m_friendTowers.begin();
	for (; iter1 != m_friendTowers.end(); ++iter1)
	{
		iter1->second->pause();
	}

	IDBuilding::iterator iter2 = m_enemyBuildings.begin();
	for (; iter2 != m_enemyBuildings.end(); ++iter2)
	{
		iter2->second->pause();
	}
	
	iter2 = m_friendBuildings.begin();
	for (; iter2 != m_friendBuildings.end(); ++iter2)
	{
		iter2->second->pause();
	}

	m_friendTroops->pause();
	m_enemyTroops->pause();
	m_isPause = true;

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onPause();
	}
	MainScene::theScene()->getRunner()->pause();
}

void BattleScene::resume()
{
	if(m_isExit)
	{
		return;
	}

	IDMoveObject::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
		iter->second->resume();

	iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
		iter->second->resume();

	IDTower::iterator iter1 = m_enemyTowers.begin();
	for (; iter1 != m_enemyTowers.end(); ++iter1)
	{
		iter1->second->resume();
	}

	iter1 = m_friendTowers.begin();
	for (; iter1 != m_friendTowers.end(); ++iter1)
	{
		iter1->second->resume();
	}

	IDBuilding::iterator iter2 = m_enemyBuildings.begin();
	for (; iter2 != m_enemyBuildings.end(); ++iter2)
	{
		iter2->second->resume();
	}

	iter2 = m_friendBuildings.begin();
	for (; iter2 != m_friendBuildings.end(); ++iter2)
	{
		iter2->second->resume();
	}

	m_friendTroops->resume();
	m_enemyTroops->resume();
	m_isPause = false;

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onResume();
	}
	MainScene::theScene()->getRunner()->resume();
}

void BattleScene::allStopRunning()
{
	IDMoveObject::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
	{
		if(iter->second->getLogicState() != BattleObject::kLogicContinueMag)
		{
			iter->second->stopRunning();
		}
	}

	iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		if(iter->second->getLogicState() != BattleObject::kLogicContinueMag)
		{
			iter->second->stopRunning();
		}
	}
}

bool BattleScene::isInScene(const PixelPoint &position)
{
	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	return (position.x >= 0 && position.x < m_width / scaleFactor) && (position.y >= 0 && position.y < m_height / scaleFactor);
}

int BattleScene::getTroopMemberNum(int troopTid)
{
	assert(false);
	return TROOP_SOLDIER_NUM(troopTid);
}

int BattleScene::getFriendSoldierNum(int soldierTid)
{
	return m_friendTroops->getTroopSoldierNum(soldierTid);
}

int BattleScene::getEnemySoldierNum(int soldierTid)
{
	return m_enemyTroops->getTroopSoldierNum(soldierTid);
}

BattleScene *BattleScene::create(int id)
{
	BattleScene *bs = new BattleScene(id);
	bs->autorelease();

	return bs;
}

template <typename T>
static void pickUpObjects(std::vector<BattleObject *> *vec, int tid, const std::map<uint16_t, T *> &objects)
{
    typename std::map<uint16_t, T *>::const_iterator iter = objects.begin();
    for (; iter != objects.end(); ++iter)
    {
        if (iter->second->getTid() == tid)
            vec->push_back(iter->second);
    }
}

void BattleScene::getObjects(std::vector<BattleObject *> *objects, int tid, int type)
{
    switch (type)
    {
        case kMoveObj:
        {
            pickUpObjects(objects, tid, m_friendMoveObjects);
            pickUpObjects(objects, tid, m_enemyMoveObjects);
            break;
        }
            
        case kTower:
        {
            pickUpObjects(objects, tid, m_friendTowers);
            pickUpObjects(objects, tid, m_enemyTowers);
            break;
        }
            
        case kBuilding:
        {
            pickUpObjects(objects, tid, m_friendBuildings);
            pickUpObjects(objects, tid, m_enemyBuildings);
            break;
        }
            
        default:
            break;
    }
}

void BattleScene::shareCureGenerals(char party, int maxHp)
{
    std::vector<BattleMoveObject *> generals = (party == kFriendParty) ? getGenerals() : getEnemyGenerals();
    if (generals.empty()) return;
    
    int size = static_cast<int>(generals.size());
    int hp = maxHp/size;
    for (auto it = generals.begin(); it != generals.end(); ++it)
    {
        (*it)->setHp(hp + (*it)->getHp());
    }
}

void BattleScene::partakeDamage(std::set<uint16_t> &partakeIds, int totalDamage)
{
    if (partakeIds.empty()) return;
    
    int damage = totalDamage/partakeIds.size();
    for(auto it = partakeIds.begin(); it != partakeIds.end(); ++it)
    {
        switch (getObjectType(*it))
        {
            case kMoveObj:
            {
                BattleMoveObject *bmo = getMoveObject(*it);
                if (bmo)
                {
                    bmo->setHp(bmo->getHp() - damage);
                }
                break;
            }
            case kTower:
            {
                BattleTower *bt = getTower(*it);
                if (bt)
                {
                    bt ->setHp(bt->getHp() - damage);
                }
                break;
            }
            case kBuilding:
            {
                BattleBuilding *bb = getBuilding(*it);
                if (bb)
                {
                    bb->setHp(bb->getHp() - damage);
                }
                break;
            }
            default:
                break;
        }
    }
}

void BattleScene::getMoveObjects(std::vector<BattleMoveObject *> *objects, char party, TargetSelect::UnitType type)
{
	switch(party)
	{
	case TargetSelect::kAll:
		getMoveObjects_(objects, m_friendMoveObjects, type);
		getMoveObjects_(objects, m_enemyMoveObjects, type);
		break;
	case kFriendParty:
		getMoveObjects_(objects, m_friendMoveObjects, type);
		break;
	case kEnemyParty:
		getMoveObjects_(objects, m_enemyMoveObjects, type);
		break;
	default:
		assert(false);
		break;
	}
}
void BattleScene::getBuildings(std::vector<BattleBuilding *> *objects, char party, TargetSelect::UnitType type)
{
	switch(party)
	{
	case TargetSelect::kAll:
		getBuildings_(objects, m_friendBuildings, type);
		getBuildings_(objects, m_enemyBuildings, type);
		break;
	case kFriendParty:
		getBuildings_(objects, m_friendBuildings, type);
		break;
	case kEnemyParty:
		getBuildings_(objects, m_enemyBuildings, type);
		break;
	default:
		assert(false);
		break;
	}
}
void BattleScene::getTowers(std::vector<BattleTower *> *objects, char party, TargetSelect::UnitType type)
{
	switch(party)
	{
	case TargetSelect::kAll:
		getTowers_(objects, m_friendTowers, type);
		getTowers_(objects, m_enemyTowers, type);
		break;
	case kFriendParty:
		getTowers_(objects, m_friendTowers, type);
		break;
	case kEnemyParty:
		getTowers_(objects, m_enemyTowers, type);
		break;
	default:
		assert(false);
		break;
	}
}

void BattleScene::getMoveObjects_(std::vector<BattleMoveObject *> *objects, const IDMoveObject & moveObjs, TargetSelect::UnitType type)
{
	switch(type)
	{
	case TargetSelect::kAll:
	case TargetSelect::kMoveObj:
		{
			objects->reserve(moveObjs.size());
			for(IDMoveObject::const_iterator iter = moveObjs.begin(); iter != moveObjs.end(); ++iter)
			{
				objects->push_back(iter->second);
			}
			break;
		}
	case TargetSelect::kGeneral:
		{
			for(IDMoveObject::const_iterator iter = moveObjs.begin(); iter != moveObjs.end(); ++iter)
			{
				if(iter->second->getType() == BattleMoveObject::kGeneral)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kSoldier:
		{
			for(IDMoveObject::const_iterator iter = moveObjs.begin(); iter != moveObjs.end(); ++iter)
			{
				if(iter->second->getType() == BattleMoveObject::kSoldier)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	default:
		break;
	}
}

void BattleScene::getBuildings_(std::vector<BattleBuilding *> *objects, const IDBuilding &buildings, TargetSelect::UnitType type)
{
	switch(type)
	{
	case TargetSelect::kAll:
		{
			for(IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
			{
				objects->push_back(iter->second);
			}
			break;
		}
	case TargetSelect::kBuilding:
		{
			for(IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kShelter)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kTrigger:
		{
			for(IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kAttribTrigger:
		{
			for(IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger && iter->second->getDamageType() > 0)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kPhysicTrigger:
		{
			for(IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger && iter->second->getDamageType() == 0)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kSlgTrap:
	{
		for (IDBuilding::const_iterator iter = buildings.begin(); iter != buildings.end(); ++iter)
		{
			if (iter->second->getSubType() > BattleStaticObject::kSlgTrapStart)
			{
				objects->push_back(iter->second);
			}
		}
		break;
	}
	default:
		assert(false);
	}
}

void BattleScene::getTowers_(std::vector<BattleTower *> *objects, const IDTower &towers, TargetSelect::UnitType type)
{
	switch(type)
	{
	case TargetSelect::kAll:
		{
			for(IDTower::const_iterator iter = towers.begin(); iter != towers.end(); ++iter)
			{
				objects->push_back(iter->second);
			}
			break;
		}
	case TargetSelect::kTower:
		{
			for(IDTower::const_iterator iter = towers.begin(); iter != towers.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kShelter)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kTrigger:
		{
			for(IDTower::const_iterator iter = towers.begin(); iter != towers.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kAttribTrigger:
		{
			for(IDTower::const_iterator iter = towers.begin(); iter != towers.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger && iter->second->getDamageType() > 0)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	case TargetSelect::kPhysicTrigger:
		{
			for(IDTower::const_iterator iter = towers.begin(); iter != towers.end(); ++iter)
			{
				if(iter->second->getSubType() == BattleStaticObject::kTrigger && iter->second->getDamageType() == 0)
				{
					objects->push_back(iter->second);
				}
			}
			break;
		}
	default:
		break;
	}
}

int BattleScene::getSoldiersNum(char party) const
{
	int num = 0;
	const IDMoveObject &soldiers = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
	for(auto it = soldiers.cbegin(); it != soldiers.cend(); ++it)
	{
		if(it->second->getType() == BattleMoveObject::kSoldier)
		{
			num++;
		}
	}

	return num;
}
int BattleScene::getSoldiersNumByProfessionId(char party, int professionId) const
{
    int num = 0;
    const IDMoveObject &soldiers = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
    for(auto it = soldiers.cbegin(); it != soldiers.cend(); ++it)
    {
        BattleMoveObject *object = it->second;
		int id = object->getTid();
		int pro = 0;
		if (object->isMonster())
		{
			pro = MONSTERSOLDIER_PROFESSION(id);
		}
		else
		{
			pro = SOLDIER_PROFESSION(id);
		}
		if (object->getType() == BattleMoveObject::kSoldier && pro == professionId)
        {
            num++;
        }
    }
    
    return num;
}

int BattleScene::getMoveObjectsNum(char party) const
{
	if(party == kFriendParty)
	{
		return static_cast<int>(m_friendMoveObjects.size());
	}
	else
	{
		return static_cast<int>(m_enemyMoveObjects.size());
	}
}

int BattleScene::getWallSoldiersNum(char party) const
{
	int num = 0;
	const IDMoveObject &soldiers = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
	for(auto it = soldiers.cbegin(); it != soldiers.cend(); ++it)
	{
		BattleMoveObject *object = it->second;
		if(object->isMonster() && object->getBaseSpeed() == 0)
		{
			num++;
		}
	}

	return num;
}

int BattleScene::getCanAttackObjectsNum(char party, bool isAntiCloak, int nodeIndex) const
{
	int buildingNum = 0;
	int towerNum = 0;
	int MoveObjNum = 0;
	const IDBuilding &buildings = (party == kFriendParty) ? m_friendBuildings : m_enemyBuildings;
	const IDTower &towers = (party == kFriendParty) ? m_friendTowers : m_enemyTowers;
	const IDMoveObject &soldiers = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;

	for(auto it = buildings.cbegin(); it != buildings.cend(); ++it)
	{
		if(it->second->canBeFound(isAntiCloak, nodeIndex) && it->second->getSubType() == BattleStaticObject::kShelter)
		{
			buildingNum++;
		}
	}

	for(auto it = towers.cbegin(); it != towers.cend(); ++it)
	{
		if(it->second->canBeFound(isAntiCloak, nodeIndex))
		{
			towerNum++;
		}
	}

	for(auto it = soldiers.cbegin(); it != soldiers.cend(); ++it)
	{
		if(it->second->canBeFound(isAntiCloak, nodeIndex))
		{
			MoveObjNum++;
		}
	}

	return buildingNum + towerNum + MoveObjNum;
}

void BattleScene::touchOnObjects(std::vector<BattleMoveObject *> *objects, const std::vector<GridPosition> &pts)
{
	IDMoveObject::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
	{
		if (std::find(pts.begin(), pts.end(), iter->second->getGridPosition()) != pts.end())
			objects->push_back(iter->second);
	}
}

const GridPosition &BattleScene::getTroopDataByIndex(unsigned char *troopId, char party, int troopIndex) const
{
	if(party == kFriendParty)
	{
		return m_friendTroops->getTroopDataByIndex(troopId, troopIndex);
	}
	else
	{
		return m_enemyTroops->getTroopDataByIndex(troopId, troopIndex);
	}
}

template <typename T>
static const GridPosition &getPosByIndex(const map<uint16_t, T> &objects, int index)
{
	typename map<uint16_t, T>::const_iterator iter = objects.begin();

	T object = nullptr;
	for(; iter != objects.end(); ++iter)
	{
		object = iter->second;
		if(object->getIndex() == index)
		{
			return object->getGridPosition();
		}
	}

	assert(false);
	static GridPosition s_default;
	return s_default;
}
const GridPosition &BattleScene::getBuildingPosByIndex(char party, int index) const
{
	if(party == kFriendParty)
	{
		return getPosByIndex(m_friendBuildings, index);
	}
	else
	{
		return getPosByIndex(m_enemyBuildings, index);
	}
}

const GridPosition &BattleScene::getTowerPosByIndex(char party, int index) const
{
	if(party == kFriendParty)
	{
		return getPosByIndex(m_friendTowers, index);
	}
	else
	{
		return getPosByIndex(m_enemyTowers, index);
	}
}

void BattleScene::checkJumpOverTriggerArea(const vector<GridPosition> &grids, BattleMoveObject *object)
{
	if(object->getParty() == kFriendParty)
	{
		for(auto it = m_enemyGenGeneralPointTriggerAreas.begin(); it != m_enemyGenGeneralPointTriggerAreas.end(); )
		{
			(*it)->checkLineTrigger(this, grids, object);
		}
	}
}

void BattleScene::genBattleReport(BattleReport *br, uint16_t attackerId, uint16_t defenderId, int skillId)
{
    genBattleReport(br, getObject(attackerId), defenderId, skillId);
}

void BattleScene::genBattleReport(BattleReport *br, BattleObject *attackerObject, uint16_t defenderId, int skillId)
{
	ObjectType attackerType = getObjectType(attackerObject->getId());
	switch(attackerType)
	{
	case BattleScene::kMoveObj:
		{
			BattleMoveObject *attacker = dynamic_cast<BattleMoveObject *>(attackerObject);
			genBattleReport(br, attacker, defenderId, skillId);
			break;
		}
	case BattleScene::kTower:
		{
            BattleTower *attacker = dynamic_cast<BattleTower *>(attackerObject);
			genBattleReport(br, attacker, defenderId, skillId);
			break;
		}
	default:
		assert(false);
	}
}

char BattleScene::getTroopPartyById(unsigned char troopId)
{
	if(m_friendTroops->isTroopExist(troopId)) return kFriendParty;

	return kEnemyParty;
}

bool BattleScene::isTroopMemberCollide(char party, unsigned char troopId) const
{
	if(party == kFriendParty)
	{
		if(m_friendFormation)
		{
			return false;
		}
	}
	else
	{
		if(m_enemyFormation)
		{
			return false;
		}
	}

	RETURN_TROOP_F(isTroopMemberCollide, troopId);
}

bool BattleScene::calcTroopDest(char party, unsigned char troopId)
{
	if(party == kFriendParty)
	{
		if(m_friendFormation)
		{
			return false;
		}
	}
	else
	{
		if(m_enemyFormation)
		{
			return false;
		}
	}

	RETURN_TROOP_F(calcTroopDest, troopId);
}

void BattleScene::disbandTroop(char party, unsigned char troopId)
{
	if(party == kFriendParty)
	{
		m_friendTroops->removeTroop(troopId);
	}
	else
	{
		m_enemyTroops->removeTroop(troopId);
	}
}

void BattleScene::dropResourceFromObject(uint16_t objectId, float count)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onDropResourceFromObject(objectId, count);
	}
}

float BattleScene::addBattleResource(float count, bool isDelay, bool isAddByTime)
{
	//if (isInThisBattleMode(MainScene::kBattleArena)) return 0.0f;
	float battleResources = getBattleResources();
	if(static_cast<int>(battleResources) >= getMaxBattleResource()) return 0.0f;
	float newbattleResources = battleResources + count;
	if(static_cast<int>(newbattleResources) >= getMaxBattleResource())
	{
		newbattleResources = static_cast<float>(getMaxBattleResource());
	}
	setBattleResources(newbattleResources);
	float diff = getBattleResources() - battleResources;
	if (!isAddByTime) m_totalAddedResources += diff;
	MonsterAI::getFood(diff);
	RUN_ACTIONS(runFoodNumAddActions);
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBattleResourcesChanged(diff, isDelay);
	}

	return diff;
}

void BattleScene::costBattleResource(float count)
{
	float battleResources = getBattleResources();
	setBattleResources(battleResources - count);
	float diff = getBattleResources() - battleResources;
	m_totalCostedResources += -diff;
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBattleResourcesChanged(diff, false);
	}
}

void BattleScene::updateBattleResource()
{
    int consume = getFriendResourcesConsume();
    if ( m_oldFriendResourcesConsume == consume ) {
        return;
    }
    m_oldFriendResourcesConsume = consume;
    
    for (size_t i = 0; i < m_views.size(); ++i)
    {
        m_views[i]->onBattleResourcesChanged(0, false);
    }
}

int BattleScene::getEnemyResourcesConsume(char party) const
{
    int cousume = 0;
    const vector<BattleMoveObject *> &generals = getGenerals(party);
    for ( auto it = generals.begin(); it != generals.end(); ++it )
    {
        cousume += (*it)->getBattleEffect()->enemyResourcesConsume;
    }
    
    return cousume;
}

bool BattleScene::isFreeRecruit()
{
    int probability = 0;
    const vector<BattleMoveObject *> &generals = getGenerals(kFriendParty);
    for ( auto it = generals.begin(); it != generals.end(); ++it )
    {
        int num = (*it)->getBattleEffect()->freeRecruitProbability;
        if ( num > probability )
        {
            probability = num;
        }
    }
    if ( probability == 0) return false;
    
	int rnd = getRandNum_(1, CFGPROBABILITY);
    return rnd <= probability;
}

void BattleScene::updateBattleData(float delta)
{
	if (!m_shouldStartCountDown) return;

	m_battleDataCostTime += delta;
	if (m_battleDataCostTime >= 1.0f)
	{
		m_battleDataCostTime = 0.0f;
		updateBattleTime();
	}
}

void BattleScene::updateBattleTime()
{
	if (m_battleTime <= 0) return;
	if(m_antiHack->getValue(AntiHack::kBattleTime) == m_battleTime)
	{
		--m_battleTime;
	}
	else
	{
		assert(false);
		m_battleTime = 0;
	}
	m_antiHack->setValue(AntiHack::kBattleTime, m_battleTime);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBattleTimeChanged();
	}
	LuaLogicUtil::onBattleTimeChanged(m_battleTime);

	int battleType = MainScene::theScene()->getBattleType();
	if (battleType == MainScene::kBattleMagic || battleType == MainScene::kBattleElementStrom)
	{
		LoadingView *lv = MainScene::theScene()->getLoadingView();
		if (lv)
		{
			lv->loadingCallBack(100, true);
		}

	}	
}

void BattleScene::allFriendObjectsAddHp()
{
	/*if(!isInThisBattleMode(MainScene::kBattlePass)) return;

	float percent = SCENE_CURE_HP(m_sceneId);

	for(IDMoveObject::iterator iter = m_friendMoveObjects.begin(); iter != m_friendMoveObjects.end(); ++iter)
	{
		BattleMoveObject *object = iter->second;
		object->setHp(static_cast<int>(object->getHp() + object->getHpMax() * percent));
	}*/
}

void BattleScene::getAllInfluenceHalos(std::vector<BattleHalo *> *halos, uint16_t objectId)
{
	getInfluenceHalos(halos, objectId);

	const vector<BattleMoveObject *> &friendGenerals = m_battleRecord->getFriendGenerals();
	vector<BattleMoveObject *>::const_iterator iter = friendGenerals.begin();
	for(; iter != friendGenerals.end(); ++iter)
	{
		(*iter)->getInfluenceHalos(halos, objectId);
	}

	const vector<BattleMoveObject *> &enemyGenerals = m_battleRecord->getEnemyGenerals();
	iter = enemyGenerals.begin();
	for(; iter != enemyGenerals.end(); ++iter)
	{
		(*iter)->getInfluenceHalos(halos, objectId);
	}
}

void BattleScene::setShouldStartCountDown(bool b)
{ 
	m_shouldStartCountDown = b; 

	IDBuilding::iterator iter = m_friendBuildings.begin();
	if(isInThisBattleMode(MainScene::kBattlePVP))
	{
		for (; iter != m_friendBuildings.end(); ++iter)
		{
			if (iter->second->getTid() == 99999)//pvp战斗场景中约定的门禁tid;
			{
				disappearFriendBuilding(iter->first);
				return;
			}
		}
	}
	

	if (b)
	{
		m_isRealBegan = true;
		for (size_t i = 0; i < m_views.size(); ++i)
		{
			m_views[i]->onBattleRealBegin();
		}
	}
}

void BattleScene::setBattleResources(float battleResources)
{
	if (battleResources < FLT_EPSILON) battleResources = 0.0f;
	if(m_antiHack->getValue(AntiHack::kBattleResource) == static_cast<int>(m_battleResources))
	{
		m_battleResources = battleResources;
	}
	else
	{
		assert(false);
		m_battleResources = 0.0f;
	}

	m_antiHack->setValue(AntiHack::kBattleResource, static_cast<int>(m_battleResources));
}

void BattleScene::setBattleTime(int battleTime)
{
	m_battleTime = battleTime;
	m_antiHack->setValue(AntiHack::kBattleTime, m_battleTime);
}

void BattleScene::calcBattleResourcesSpeed()
{
	
}

//指定场景添加全体士兵buff
void BattleScene::addSceneSoldierBuff()
{
	/*for (auto it = m_sceneSoldierHaloIds.cbegin(); it != m_sceneSoldierHaloIds.cend(); ++it)
	{
		BuffMgr::theMgr().incCurSoldierId();
		uint16_t id = BuffMgr::theMgr().getCurSoldierId();
		BuffMgr::theMgr().setNotifyView(false);

		int skillGroupId;
		int skillLevel;
		skill::splitSkillLvId(&skillGroupId, &skillLevel, *it);
		BATTLEHALO_BUFF(*it, id, 1);
		BuffMgr::theMgr().setNotifyView(true);
		m_sceneSoldierBuffs.push_back(id);
	}*/
}
void BattleScene::removeAllSceneSoldierBuff()
{
	BuffMgr::theMgr().setNotifyView(false);
	BuffMgr &mgr = BuffMgr::theMgr();
	for (auto iter = m_sceneSoldierBuffs.begin(); iter != m_sceneSoldierBuffs.end(); ++iter)
	{
		mgr.removeObjectBuffs(*iter);
	}

	m_sceneSoldierBuffs.clear();
	BuffMgr::theMgr().setNotifyView(true);
}
bool BattleScene::applySceneSoldierBuff(BattleMoveObject *soldier, float dt)
{
	int passId = MainScene::theScene()->getCurPassId();
	int influnceParty = PASS_HALO_PARTY(passId);
	if (influnceParty != 0)
	{
		if (soldier->getParty() == kFriendParty && influnceParty == 2)
		{
			return false;
		}
		if (soldier->getParty() == kEnemyParty && influnceParty == 1)
		{
			return false;
		}
	}
	if (m_sceneSoldierHaloIds.empty())
	{
		return false;
	}
	/*for (auto it = m_sceneSoldierBuffs.begin(); it != m_sceneSoldierBuffs.end(); ++it)
	{
		BuffMgr::theMgr().applyObjectBuffs(*it, soldier, dt);
	}*/
	for (auto it = m_sceneSoldierHaloIds.cbegin(); it != m_sceneSoldierHaloIds.cend(); ++it)
	{
		BuffMgr::theMgr().setNotifyView(true);
		BATTLEHALO_BUFF(*it, soldier->getId(), 1);
	}
	return true;
}


//老项目士兵buf的添加
void BattleScene::addSoldierBuff(char party, int soldierCommonId)
{
	/*map<int, uint16_t> &soldierBuffs = (party == kFriendParty) ? m_friendSoldierBuffs : m_enemySoldierBuffs;
	map<int, uint16_t>::iterator iter = soldierBuffs.find(soldierCommonId);
	if(iter == soldierBuffs.end())
	{
		const vector<int> &haloIds = PASSIVESKILL_HALO_IDS(SOLDIERCOMMON_PASSIVE_SKILL_ID(soldierCommonId), 1);
		for(auto it = haloIds.cbegin(); it != haloIds.cend(); ++it)
		{
			BuffMgr::theMgr().incCurSoldierId();
			uint16_t id = BuffMgr::theMgr().getCurSoldierId();
			BuffMgr::theMgr().setNotifyView(false);
            
            int skillGroupId;
            int skillLevel;
            skill::splitSkillLvId(&skillGroupId, &skillLevel, *it);
			BATTLEHALO_BUFF(skillGroupId, id, skillLevel);
			BuffMgr::theMgr().setNotifyView(true);
			soldierBuffs.insert(make_pair(soldierCommonId, id));
		}
	}*/
}

static void removeSoldierBuffs_(map<int, uint16_t> &soldierBuffs)
{
	BuffMgr &mgr = BuffMgr::theMgr();
	for(map<int, uint16_t>::const_iterator iter = soldierBuffs.begin(); iter != soldierBuffs.end(); ++iter)
	{
		mgr.removeObjectBuffs(iter->second);
	}

	soldierBuffs.clear();
}
void BattleScene::removeAllSoldierBuffs()
{
	BuffMgr::theMgr().setNotifyView(false);
	removeSoldierBuffs_(m_friendSoldierBuffs);
	removeSoldierBuffs_(m_enemySoldierBuffs);
	BuffMgr::theMgr().setNotifyView(true);
}

bool BattleScene::applySoldierBuff(BattleMoveObject *soldier, float dt)
{
	const map<int, uint16_t> &soldierBuffs = (soldier->getParty() == kFriendParty) ? m_friendSoldierBuffs : m_enemySoldierBuffs;
	map<int, uint16_t>::const_iterator iter = soldierBuffs.find(soldier->getSoldierCommonId());
	if(iter != soldierBuffs.end())
	{
		BuffMgr::theMgr().applyObjectBuffs(iter->second, soldier, dt);
		return true;
	}

	return false;
}

int BattleScene::getTotalUnit()
{
	int total = 0;
	IDMoveObject::iterator iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		if (iter->second->getType() == BattleMoveObject::kGeneral) continue;

		int id = iter->second->getSoldierCommonId();
		total += 1;// SOLDIERCOMMON_UNIT(id);
	}

	return total;
}

bool BattleScene::hasFriendSoldier(int tid)
{
	IDMoveObject::iterator iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		if (iter->second->getType() == BattleMoveObject::kSoldier && iter->second->getTid() == tid)
		{
			return true;
		}
	}

	return false;
}

std::vector<int> BattleScene::generalsHpLessThanPercent(float percent)
{
	std::vector<int> ids;
	IDMoveObject::iterator iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		if (iter->second->getType() == BattleMoveObject::kGeneral)
		{
			int curHp = iter->second->getHp();
			int hpMax = iter->second->getHpMax();
			float p = static_cast<float>(curHp) / hpMax;
			if (p < percent) ids.push_back(iter->first);
		}
	}

	return ids;
}

bool BattleScene::isBossBarrack(char party, uint16_t objectId) const
{
	if(party == kFriendParty)
	{
		return (objectId == m_friendBossBarrack);
	}
	else
	{
		return (objectId == m_enemyBossBarrack);
	}
}

uint16_t BattleScene::getBossBarrackId(char party) const
{
	if(party == kFriendParty)
	{
		return m_friendBossBarrack;
	}
	else
	{
		return m_enemyBossBarrack;
	}
}

bool BattleScene::isBarrack(uint16_t objectId) const
{
	if(getObjectType(objectId) != kBuilding) return false;

	for(auto it = m_enemyBarracks.begin(); it != m_enemyBarracks.end(); ++it)
	{
		if(it->second.building->getId() == objectId)
		{
			return true;
		}
	}

	if (m_friendBarrack.building)
	{
		if (m_friendBarrack.building->getId() == objectId)
		{
			return true;
		}
	}	

	return false;
}

void BattleScene::updateBarrack(int index, BattleBuilding *barrack)
{
	/*assert(index > kFriendBarrackIndex);
	map<int, BattleBarrack>::iterator iter = m_enemyBarracks.find(index);
	if(iter != m_enemyBarracks.end())
	{
		if(!iter->second.isOccupied)
		{
			setMaxBattleResource(getMaxBattleResource() + PASSBUILDING_ADD_MAX_FOOD(barrack->getTid()));
		}

		iter->second.building = barrack;
		iter->second.position = barrack->getGridPosition();
		iter->second.isOccupied = true;
	}
	else
	{
		assert(false);
	}*/
}

BattleBarrack &BattleScene::getBarrack(int index)
{
	if(index == kFriendBarrackIndex)
	{
		return m_friendBarrack;
	}
	else
	{
		auto iter = m_enemyBarracks.find(index);
		if(iter != m_enemyBarracks.end())
		{
			return iter->second;
		}
		else
		{
			assert(false);
			static BattleBarrack s_default;
			return s_default;
		}
	}
}

int BattleScene::getBarrackIndex(uint16_t objectId) const
{
	for(auto iter = m_enemyBarracks.begin(); iter != m_enemyBarracks.end(); ++iter)
	{
		if(iter->second.building->getId() == objectId)
		{
			return iter->first;
		}
	}
	if (m_friendBarrack.building)
	{
		if (m_friendBarrack.building->getId() == objectId)
		{
			return kFriendBarrackIndex;
		}
	}

	return -1;
}

void BattleScene::handleBarrackOccupy(int barrackIndex)
{
	BattleBuilding *building = getBarrack(barrackIndex).building;
	const GridRect &rect = building->getIntRect();
	for(int16_t y = rect.rb.y; y <= rect.lt.y; ++y)
	{
		for(int16_t x = rect.lt.x; x <= rect.rb.x; ++x)
		{
			m_terrain->removeDynamicBarrier(x, y);
		}
	}

	char occupyParty = getOppoParty(building->getParty());
	if(occupyParty == kFriendParty)
	{
		MonsterAI::currentMonsterBarrackIndex(barrackIndex);
		RUN_ACTIONS(runOccupyMonsterBarrackActions);

		for (size_t i = 0; i < m_views.size(); ++i)
		{
			m_views[i]->onEnemyBarrackOccupied(building->getTid(), barrackIndex);
		}
		

		friendFormationStart();
	}

	if(isInThisBattleMode(MainScene::kBattleDungeonTraining))
	{
		return; // 练兵副本不需要创建我方兵营
	}

	BattleBuilding *bb = BattleBuilding::create(building->getTid(), building->getGridPosition(), building->getNodeIndex());
	bb->setPixelPosition(building->getPixelPosition());
	bb->setLogicData(building->getMonsterAI(), building->getGenGeneralPoint(), building->getBarrackResourceNum());
	bb->setIndex(building->getIndex());

	if (occupyParty == kFriendParty)
	{
		addFriendBuilding(bb, true);
		getLowestTarget().addLowestObject(occupyParty, bb->getId());
		if(bb->getGenGeneralPoint())
		{
			bb->getGenGeneralPoint()->stop();
		}
		MonsterAI *ai = bb->getMonsterAI();
		if(ai)
		{
			ai->stop();
		}
		assert(barrackIndex == m_barrackBornInfo->getBarrackIndex() + 1);
		m_barrackBornInfo->setBarrackIndex(barrackIndex);
	}
	else
	{
		m_battleStatistics.isEnemyBarrackRecaptured = true;

		addEnemyBuilding(bb, true);
		getLowestTarget().addLowestObject(occupyParty, bb->getId());
		if(bb->getGenGeneralPoint())
		{
			bb->getGenGeneralPoint()->resume();
		}
		MonsterAI *ai = bb->getMonsterAI();
		if(ai)
		{
			ai->resume();
		}
		assert(barrackIndex == m_barrackBornInfo->getBarrackIndex());
		m_barrackBornInfo->setBarrackIndex(barrackIndex - 1);
	}
	if(bb->getGenGeneralPoint())
	{
		bb->getGenGeneralPoint()->setOwnerId(bb->getId());
	}

	updateBarrack(barrackIndex, bb);
}

void BattleScene::onGenGeneralPointTriggerBigWave(uint16_t barrackId)
{
	for(auto iter = m_enemyBarracks.begin(); iter != m_enemyBarracks.end(); ++iter)
	{
		BattleBuilding *barrack = iter->second.building;
		if(!barrack) continue;
		if(barrack->getId() == barrackId)
		{
			MonsterAI::currentMonsterBarrackIndex(iter->first);
			RUN_ACTIONS(runMonsterBarrackTriggeredBigWaveActions);
			for (size_t i = 0; i < m_views.size(); ++i)
			{
				m_views[i]->onGenGeneralPointTriggerBigWave(barrack->getTid(), getBarrackIndex(barrackId));
			}
			break;
		}
	}
}

void BattleScene::onBigWaveDead(int barrackIndex)
{
	MonsterAI::currentMonsterBarrackIndex(barrackIndex);
	RUN_ACTIONS(runBigWaveDeadActions);

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onBigWaveDead(barrackIndex);
	}
}

bool BattleScene::isHaveBarrackBigWaveUnit(int barrackIndex) const
{
	for(auto iter = m_enemyMoveObjects.cbegin(); iter != m_enemyMoveObjects.cend(); ++iter)
	{
		if(iter->second->getBarrackIndex() == barrackIndex)
		{
			return true;
		}
	}

	return false;
}

void BattleScene::addBattleResSpeedAdd(float value, float time)
{
	m_battleResSpeedAdds.push_back(BattleResSpeedAdd(value, time));
	calcBattleResourcesSpeed();
}

void BattleScene::updateBattleResSpeedAdds(float dt)
{
	bool isChange = false;
	for(auto it = m_battleResSpeedAdds.begin(); it != m_battleResSpeedAdds.end(); )
	{
		BattleResSpeedAdd &data = *it;
		data.time -= dt;
		if(data.time < FLT_EPSILON)
		{
			it = m_battleResSpeedAdds.erase(it);
			isChange = true;
		}
		else
		{
			++it;
		}
	}

	if(isChange)
	{
		calcBattleResourcesSpeed();
	}
}

void BattleScene::onSceneGenGeneralPointTriggeredWave(char party, int index)
{
	if(party == kEnemyParty)
	{
		m_enemySceneGenGeneralPointTotalWaveNum--;
	}
	
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onTriggeredWave(party, index);
	}
}

void BattleScene::launchTroop(int memberCount)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onLaunchTroop(memberCount);
	}
}

void BattleScene::bounceDamageToObject(uint16_t objectId, int32_t damage)
{
	assert(damage > 0);
	BattleObject *object = getObject(objectId);
	if(object == nullptr) return;

	object->setHp(object->getHp() - damage);
}

bool BattleScene::objectUseSkill(uint16_t objectId, const SkillGroupInfo &skillGroupInfo, bool isNormalAttackSkill)
{
	bool result = true;
    if( getObjectType(objectId) == kMoveObj )
    {
        BattleMoveObject *attacker = getMoveObject(objectId);
        if ( !attacker || !attacker->canUseSkill(skillGroupInfo.skill_group_id)) {
            return false;
        }
    }
    
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		if(!m_views[i]->onObjectUseSkill(objectId, skillGroupInfo, isNormalAttackSkill))
		{
			result = false;
		}
	}

	return result;
}

int BattleScene::getCostFoodSkill() const
{
    return 0;
}

float BattleScene::getFoodSkillMaxCdTime() const
{
    int foodSkillId = 1;
    return SKILL_CD(foodSkillId);
}

void BattleScene::afterUseFoodSkill()
{
    m_isFoodSkillCd = true;
    m_currFoodSkillCdTime = getFoodSkillMaxCdTime();
    
    for (auto it = m_views.begin(); it != m_views.end(); ++it)
    {
        (*it)->onAfterUseBattleSkill();
    }
}

void BattleScene::updateFoodSkillCDTime(float dt)
{
    if (m_isFoodSkillCd == false) return;
    
    m_currFoodSkillCdTime -= dt;
    if (m_currFoodSkillCdTime < FLT_EPSILON)
    {
        m_isFoodSkillCd = false;
        m_currFoodSkillCdTime = 0.0f;
        for (auto it = m_views.begin(); it != m_views.end(); ++it)
        {
            (*it)->onBattleSkillCdTimeEnd();
        }
    }
}

bool BattleScene::useFoodSkill()
{
    if(m_isFoodSkillCd) return false;
    
    int costFoodSKill  = getCostFoodSkill();
    int foodSkillId    = 1;
    int foodSkillLevel = 1;

    if (getBattleResources() < costFoodSKill) return false;
    auto generals = getGenerals();
    if (generals.empty()) return false;
    BattleMoveObject *general = *(generals.begin());
    TargetSelectMgr::theMgr().setMoveObject(general);
    
    skill::handleFoodSkillFxBuff(skill::getSkillLvId(foodSkillId, foodSkillLevel));
    
    costBattleResource(static_cast<float>(costFoodSKill));
    afterUseFoodSkill();
    return true;
}

bool BattleScene::objectShapeChangeUseSkill(uint16_t objectId, const SkillGroupInfo &skillGroupInfo, SpeakType speakType, int speakTextId, float speakLastTime)
{
	bool result = true;
	if( getObjectType(objectId) == kMoveObj )
	{
		BattleMoveObject *attacker = getMoveObject(objectId);
		if ( !attacker || !attacker->canUseSkill(skillGroupInfo.skill_group_id)) {
			return false;
		}
	}

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		if(!m_views[i]->onObjectShapeChangeUseSkill(objectId, skillGroupInfo, speakType, speakTextId, speakLastTime))
		{
			result = false;
		}
	}

	return result;
}

bool BattleScene::isInOppoArea(char objectParty, uint16_t objectId)
{
	BattleMoveObject *object = getMoveObject(objectId);
	if(!object) return false;
	return m_terrain->isAreaGrid(getOppoParty(objectParty), object->getGridPosition());
}

bool BattleScene::isAllMoveObjsStopped(char party) const
{
	const IDMoveObject &moveObjs = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
	for(auto it = moveObjs.cbegin(); it != moveObjs.cend(); ++it)
	{
		if(!it->second->isPathEmpty())
		{
			return false;
		}
	}

	return true;
}

void BattleScene::replaceGeneral(BattleObject *obj, float resCount)
{
	removeEnemyMoveObject(obj->getId(), resCount);
}


//static bool isMissing(bool isLeftToRight, int16_t objectY, int16_t barrackY, int16_t y)
//{
//	if(isLeftToRight)
//	{
//		return (objectY > barrackY && y > objectY);
//	}
//	else
//	{
//		return (objectY < barrackY && y < objectY);
//	}
//}
uint16_t BattleScene::getMissingObjectId(char party, bool isLeftToRight, int16_t objectY, int16_t barrackY, PriorTarget *priorTarget, bool isAntiCloak, int nodeIndex)
{
	//if(priorTarget && !isHaveCandidate(priorTarget, party)) priorTarget = nullptr; // 若无优先目标，则不执行优先目标选择的AI

	//auto &moveObjs = (party == kFriendParty) ? m_enemyMoveObjects : m_friendMoveObjects;
	//for(auto it = moveObjs.begin(); it != moveObjs.end(); ++it)
	//{
	//	if(priorTarget && !priorTarget->isCandidate(it->second)) continue;
	//	if(it->second->canBeFound(isAntiCloak, nodeIndex) && isMissing(isLeftToRight, objectY, barrackY, it->second->getGridPosition().y))
	//	{
	//		return it->first;
	//	}
	//}

	//auto &towers = (party == kFriendParty) ? m_enemyTowers : m_friendTowers;
	//for(auto it = towers.begin(); it != towers.end(); ++it)
	//{
	//	if(it->second->getSubType() == BattleStaticObject::kTrigger) continue;
	//	if(priorTarget && !priorTarget->isCandidate(it->second)) continue;
	//	if(it->second->canBeFound(isAntiCloak, nodeIndex) && isMissing(isLeftToRight, objectY, barrackY, it->second->getGridPosition().y))
	//	{
	//		return it->first;
	//	}
	//}

	//auto &buildings = (party == kFriendParty) ? m_enemyBuildings : m_friendBuildings;
	//for(auto it = buildings.begin(); it != buildings.end(); ++it)
	//{
	//	if(it->second->getSubType() == BattleStaticObject::kTrigger) continue;
	//	if(priorTarget && !priorTarget->isCandidate(it->second)) continue;
	//	if(it->second->canBeFound(isAntiCloak, nodeIndex) && isMissing(isLeftToRight, objectY, barrackY, it->second->getGridPosition().y))
	//	{
	//		return it->first;
	//	}
	//}

	return 0;
}

void BattleScene::setMaxBattleResource(int count)
{
	m_maxBattleResources = 9999999;
	for_each(m_views.begin(), m_views.end(), std::bind(&IBattleSceneView::onBattleMaxResourcesChanged, _1));
}

void BattleScene::initEnemyFormation(int toward, const GridPosition &position, const std::vector<int> &generals)
{
	enemyFormationStart(toward, position, generals);
}

void BattleScene::triggerSceneGenGeneralPoints( char party )
{
	if(getPassType() == kBossPass)
	{
		const vector<GenGeneralPoint *> &gtps = (party == kFriendParty) ? m_friendGenGeneralPoints : m_enemyGenGeneralPoints;
		for(auto iter = gtps.cbegin(); iter != gtps.cend(); ++iter)
		{
			GenGeneralPoint *gtp = *iter;
			if(gtp->getMonsterAIs().empty())
			{
				gtp->start();
			}
		}
	}
	else
	{
		std::vector<GenGeneralPoint *> gtps = getSceneGenGeneralPoints(party);
		for (auto iter = gtps.begin(); iter != gtps.end(); ++iter)
		{
			GenGeneralPoint *gtp = *iter;
			gtp->start();
		}
	}
}

// 获取BOSS武将，如果武将非BOSS武将返回nullptr;
BattleMoveObject * BattleScene::getBossGeneral()
{
	
		return nullptr;
}

int BattleScene::getPvpTowerTid(bool isFriendParty)
{
	if(isFriendParty)
	{
		return 1;
	}
	else
	{
		return 1;
	}
}
int BattleScene::getPvpMonsterSoldierTid(char party, int topThreeDigit)
{
	int playerLv = (party == kFriendParty) ? GamePlayer::thePlayer()->getLv() : GamePvp::thePvp()->getTarget().level;
	return topThreeDigit * 1000 + playerLv;
}

void BattleScene::addEnemyPvpGeneralProp(int tid, const GeneralBase &base)
{
	assert(m_enemyPvpGeneralProps.find(tid) == m_enemyPvpGeneralProps.end());
	m_enemyPvpGeneralProps.insert(make_pair(tid, base));
}

const GeneralBase &BattleScene::getEnemyPvpGeneralProp(int tid) const
{
	auto iter = m_enemyPvpGeneralProps.find(tid);
	assert(iter != m_enemyPvpGeneralProps.end());
	return iter->second;
}

bool BattleScene::isPvpInitState(char party) const
{
	return true;
}

bool BattleScene::isFirstCreateGeneral(const std::vector<int> &generals, int tid) const
{
    for (auto it = generals.begin(); it != generals.end(); ++it )
    {
        if ( *it == tid ) return false;
    }
    
    return true;
}

void BattleScene::addFirstCreateGeneral(std::vector<int> &generals, int tid)
{
    if (isFirstCreateGeneral(generals, tid))
    {
        generals.push_back(tid);
    }
}

bool BattleScene::isFirstCreateFriendGeneral(int tid) const
{
    return isFirstCreateGeneral(m_firstCreateFriendGeneral, tid);
}

bool BattleScene::isFirstCreateEnemyGeneral(int tid) const
{
    return isFirstCreateGeneral(m_firstCreateEnemyGeneral, tid);
}

void BattleScene::addFirstCreateFriendGeneral(int tid)
{
    addFirstCreateGeneral(m_firstCreateFriendGeneral, tid);
}

void BattleScene::addFirstCreateEnemyGeneral(int tid)
{
    addFirstCreateGeneral(m_firstCreateEnemyGeneral, tid);
}

int BattleScene::getCallGeneralNum(char party)
{
    return kFriendParty == party ? m_friendCallGeneralNum : m_enemyCallGeneralNum;
}

void BattleScene::setCallGeneralNum(char party, int num)
{
    int &callNum = kFriendParty == party ? m_friendCallGeneralNum : m_enemyCallGeneralNum;
    callNum = num;
}

int BattleScene::getCallGeneralFood(char party)
{
    int callNum = kFriendParty == party ? m_friendCallGeneralNum : m_enemyCallGeneralNum;
    return RECRUITGENERAL_CONSUME_FOOD(callNum);
}

BattleScene::IDMoveObject::iterator BattleScene::removeMoveObject_(uint16_t id, char party)
{
	IDMoveObject &moveObjects = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
	IDMoveObject::iterator iter = moveObjects.find(id);
	if (iter != moveObjects.end())
	{
		BattleMoveObject *mo = iter->second;
		mo->cleanUp();
		mo->release();

		iter = moveObjects.erase(iter);
		if(mo->getType() == BattleMoveObject::kGeneral)
		{
			if (party == kFriendParty)
			{
				m_battleRecord->removeFriendGeneral(mo);
				calcBattleResourcesSpeed();
				addGeneralDeadTimes();
                handleFriendSoldierUpperLimitChange();
                
                for (auto it = m_views.begin(); it != m_views.end(); ++it)
                {
                    (*it)->onFriendGeneralNumChanged();
                }
			}
			else
			{
				m_battleRecord->removeEnemyGeneral(mo);
			}
		}
		else
		{
			if(party == kFriendParty)
			{
				handleFriendSoldierNumChange(mo->getTid());
			}
		}

		return iter;
	}
	else
	{
		assert(false);
		return iter;
	}
}

void BattleScene::moveObjectDead(uint16_t id, char party)
{
    bool isSolider = false;
	BattleMoveObject *object = getMoveObject(id);		
	if (!object)
	{
		return;		//obj不存在不处理
	}
	if(party == kFriendParty)
	{
		if (object->getType() == BattleMoveObject::kSoldier)
		{
            isSolider = true;
		}
	}
	else
	{
		if(getPassType() == kBossPass)
		{
			/*if(object->getType() == BattleMoveObject::kGeneral && MONSTERGENERAL_BOSS_TYPE(object->getTid()) != 0)
			{
				m_isBossDead = true;
			}*/
		}
        if (object->getType() == BattleMoveObject::kSoldier)
        {
            isSolider = true;
        }
	}

	removeMoveObject_(id, party);
	runMoveObjectDeadActions();
    if (isSolider)
    {
        calcPassiveSkillOpen(party, false);
    }
}

void BattleScene::calcPassiveSkillOpen(char party, bool isAddObject)
{
    const std::vector<BattleMoveObject *> &generals = getGenerals(party);
    for (auto it = generals.begin(); it != generals.end(); ++it)
    {
        BattleMoveObject *object = *it;
        object->calcPassiveSkillOpen(isAddObject);
    }
}

void BattleScene::towerDead(uint16_t id, char party)
{
	IDTower &towers = (party == kFriendParty) ? m_friendTowers : m_enemyTowers;
	IDTower::iterator iter = towers.find(id);
	if (iter != towers.end())
	{
		BattleTower *tower = iter->second;
		//箭塔摧毁的时候，移除关联的陷阱
		for (auto it = m_enemyBuildings.begin(); it != m_enemyBuildings.end(); it++)
		{
			BattleBuilding *building = it->second;
			if (building->getBuildingType() == BattleBuilding::kSlgTrap)
			{
				BattleTrap *trap = dynamic_cast<BattleTrap *>(building);
				int depends = 0;
				if (trap->getIsMonsterTrap())
				{
					depends = MONSTERPASSTRAP_DEPENDBUILD(trap->getTid());
				}
				else
				{
					depends = PASSTRAP_DEPENDBUILD(trap->getTid());
				}
				if (depends == 2 && tower->isHangOnObjs(building->getId()))
				{
					trap->setTrapState(BattleTrap::kTrapStop);
					trap->setIsTrapToRemove(true);
				}
			}
		}
		tower->cleanUp();
		tower->release();
		towers.erase(iter);
	}
	else
	{
		assert(false);
	}
}

void BattleScene::buildingDead(uint16_t id, char party)
{
	IDBuilding &buildings = (party == kFriendParty) ? m_friendBuildings : m_enemyBuildings;
	IDBuilding::iterator iter = buildings.find(id);
	if (iter != buildings.end())
	{
		BattleBuilding *building = iter->second;
		//城墙摧毁的时候，移除关联的陷阱
		if (building->getBuildingType() == BattleBuilding::kDoor)
		{
			for (auto iter = m_enemyBuildings.begin(); iter != m_enemyBuildings.end(); iter++)
			{
				BattleBuilding *building = iter->second;
				if (building->getBuildingType() == BattleBuilding::kSlgTrap)
				{
					BattleTrap *trap = dynamic_cast<BattleTrap *>(building);
					int depends = PASSTRAP_DEPENDBUILD(trap->getTid());
					if (depends == 1)
					{
						trap->setTrapState(BattleTrap::kTrapStop);
						trap->setIsTrapToRemove(true);
					}
				}
			}
		}
		int barrackIndex = getBarrackIndex(id);
		bool isNotBossBarrack = (!isBossBarrack(party, id) && (barrackIndex >= 0));
		building->cleanUp(!isNotBossBarrack);
		building->release();
		buildings.erase(iter);

		if(isNotBossBarrack)
		{
			// 先占位，因为等下要创建相反方的兵营（占领的实现方法），防止其他人进入
			const GridRect &rect = building->getIntRect();
			for(int16_t y = rect.rb.y; y <= rect.lt.y; ++y)
			{
				for(int16_t x = rect.lt.x; x <= rect.rb.x; ++x)
				{
					m_terrain->addDynamicBarrier(x, y);
				}
			}
		}
	}
	else
	{
		assert(false);
	}
}

bool BattleScene::isBossDead()
{
	assert(getPassType() == BattleScene::kBossPass);
	return m_isBossDead;
}

void BattleScene::initDropOut(const std::vector<ItemInfo> &items)
{
	m_dropOut = new BattleDropOut();
	m_dropOut->init(items);
}

std::vector<ItemInfo> *BattleScene::getBarrackDropOut(int barrackId, bool isBoss)
{
	if (!m_dropOut) return nullptr;
	return m_dropOut->getBarrackDropOut(barrackId, isBoss);
}

std::vector<ItemInfo> *BattleScene::getGeneralDropOut(int generalTid, bool isLastGeneral)
{
	if (!m_dropOut) return nullptr;
	return m_dropOut->getGeneralDropOut(generalTid, isLastGeneral);
}

void BattleScene::addSoldierClassHaloInfluence(int soldierClassId, int haloType)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onAddSoldierClassHaloInfluence(soldierClassId, haloType);
	}
}

void BattleScene::removeSoldierClassHaloInfluence(int soldierClassId, int haloType)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onRemoveSoldierClassHaloInfluence(soldierClassId, haloType);
	}
}

void BattleScene::GenGeneralPointAreaTrigger(GenGeneralPointTriggerArea *area)
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onGenGeneralPointAreaTriggered(area);
	}
}

void BattleScene::addNewOpenSolider(int soliderTid)
{
    for (size_t i = 0; i < m_views.size(); ++i)
    {
        m_views[i]->onAddNewOpenSolider(soliderTid);
    }
}

bool BattleScene::isPvp()
{
    MainScene::BattleMode mode = static_cast<MainScene::BattleMode>( MainScene::theScene()->getBattleMode() );
    switch (mode) {
        case MainScene::kBattlePVP:
        case MainScene::kBattleArena:
        case MainScene::kBattleCrusade:
            return false;
        default:
            return false;
    }
}

int BattleScene::getSoldierMaxPopulation(char party, int soldierCommonId)
{
    const std::vector<BattleMoveObject *> &generals = party == kFriendParty ? getGenerals() : getEnemyGenerals();
	int soldierProfession = 1;// SOLDIERCOMMON_PROFESSION(soldierCommonId);
    
    int maxPopulation = 0;
    for (auto it = generals.begin(); it != generals.end(); ++it)
    {
        BattleMoveObject *object = *it;
        if (object->isMonster()) continue;
        
        int generalCommonTid = object->getGeneralCommonId();
        if (object->getProfession() == soldierProfession)
        {
            maxPopulation += GeneralUtil::getMaxCallSoldierPopulation(generalCommonTid, object->getStarLv());
        }
    }
    
    return maxPopulation;
}

bool BattleScene::isCallSoldierNumEnough(char party, int soldierTid, int num)
{
    int soldierCommonId = soldierTid;
    return isCallMonsterSoldierNumEnough(party, soldierTid, soldierCommonId, num);
}

bool BattleScene::isCallMonsterSoldierNumEnough(char party, int soldierTid, int soldierCommonId, int num)
{
    int maxPopulation = getSoldierMaxPopulation(party, soldierCommonId);
    int curNum = getSoldierNumBySoldierTid(party, soldierTid);
    
    return curNum + num <= GeneralUtil::getCallSoldierNumByMaxPopulatuon(maxPopulation, soldierCommonId);
}

bool BattleScene::isCallEnemySoldierNumEnough(int soldierTid, int num)
{
    return isCallSoldierNumEnough(kEnemyParty, soldierTid, num);
}

bool BattleScene::isCallFriendSoldierNumEnough(int soldierTid, int num)
{
    return isCallSoldierNumEnough(kFriendParty, soldierTid, num);
}

int BattleScene::getSoldierNumBySoldierTid(char party, int soldierTid) const
{
    int num = 0;
    
    const IDMoveObject &soldiers = (party == kFriendParty) ? m_friendMoveObjects : m_enemyMoveObjects;
    for(auto it = soldiers.cbegin(); it != soldiers.cend(); ++it)
    {
        BattleMoveObject *moveObject = it->second;
        if(moveObject->getType() == BattleMoveObject::kSoldier &&
           moveObject->getTid() == soldierTid)
        {
            num++;
        }
    }
    
    return num;
}

int BattleScene::getSoldierPopulation(int soldierTid) const
{
    int soldierCommonId = soldierTid;
    int soldierNum = getSoldierNumBySoldierTid(kFriendParty, soldierTid);
	return soldierNum * 1;// SOLDIERCOMMON_POPULATION(soldierCommonId);
}

void BattleScene::friendFormationStart()
{
	assert(!m_friendFormation);
	if(isCurrentLastNode())
	{
		return;
	}
	//std::vector<int64_t > tmp = GameArmyManager::theMgr()->getLastDeploy().general_ids;
	std::vector<int64_t > tmp;
	tmp.push_back(1);
	m_friendFormation = new BattleFormation(kFriendParty, tmp);
	m_friendFormation->setToward(BattleObject::kRightUp);
	std::vector<WayPoint> routePoints;
	if(isInThisBattleMode(MainScene::kBattleArena))
	{
		WayPoint wp;
		wp.position = m_friendWayPoint;
		routePoints.push_back(wp);
		wp.position = m_enemyWayPoint;
		routePoints.push_back(wp);
		wp.position = m_enemyBornPoint;
		routePoints.push_back(wp);
	}
	else
	{
		getFriendFormationRoutePoints(&routePoints);
	}
	
	m_friendFormation->init(routePoints);
}

void BattleScene::friendFormationEnd()
{
	if (m_friendFormation)
	{
		m_friendFormation->startOff();
	}
	CC_SAFE_DELETE(m_friendFormation);
	m_currentNodeIndex++;
	for(auto it = m_friendMoveObjects.begin(); it != m_friendMoveObjects.end(); ++it)
	{
		BattleMoveObject *object = it->second;
		if(object->getTroopId() == 0 && object->getNodeIndex() < m_currentNodeIndex)
		{
			object->setNodeIndex(m_currentNodeIndex);
		}
	}

	for(auto it = m_friendBuildings.begin(); it != m_friendBuildings.end(); ++it)
	{
		if(it->second->getNodeIndex() < m_currentNodeIndex)
		{
			it->second->setNodeIndex(m_currentNodeIndex);
		}
	}

	m_friendTroops->updateNodeIndex(m_currentNodeIndex);
	m_friendTroops->clearTroopsDest();

	if(m_enemyFormation)
	{
		enemyFormationEnd();
	}
}

void BattleScene::enemyFormationStart(const std::vector<GeneralBase> &generals)
{
	assert(!m_enemyFormation);
	m_enemyFormation = new BattleFormation(kEnemyParty, generals);
	m_enemyFormation->setToward(BattleObject::kLeftDown);
	std::vector<WayPoint> routePoints;
	WayPoint wp;
	wp.position = m_enemyWayPoint;
	routePoints.push_back(wp);
	wp.position = m_friendWayPoint;
	routePoints.push_back(wp);
	wp.position = m_friendBornPoint;
	routePoints.push_back(wp);
	m_enemyFormation->init(routePoints);
}

void BattleScene::enemyFormationStart(int toward, const GridPosition &position, const std::vector<int> &generals)
{
	assert(!m_enemyFormation);
	m_enemyFormation = new BattleFormation(kEnemyParty, generals);
	m_enemyFormation->setToward(toward);
	std::vector<WayPoint> routePoints;
	int height = m_enemyFormation->getHeight();
	getEnemyFormationRoutePoints(&routePoints, toward, position, height);
	m_enemyFormation->init(routePoints);
}
void BattleScene::enemyFormationEnd()
{
	CC_SAFE_DELETE(m_enemyFormation);
}

bool BattleScene::canOpenCurrentNodeGate() const
{
	//return m_friendFormation && !m_friendFormation->isStartedOff() && m_friendFormation->hasMember();
	return true;
}

void BattleScene::openCurrentNodeGate()
{
	assert(canOpenCurrentNodeGate());
	if (m_friendFormation)
	{
		m_friendFormation->enableStartOff();
	}
	
	
// 	for (size_t i = 0; i < m_views.size(); ++i)
// 	{
// 		m_views[i]->onOpenCurrentNodeGate();
// 	}
}

void BattleScene::arenaStartOff()
{
	assert(isInThisBattleMode(MainScene::kBattleArena));
	m_friendFormation->enableStartOff();
	m_enemyFormation->enableStartOff();

	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onRemoveAllNodeGates();
	}
}

BattleFormation *BattleScene::getFormation(char party) const
{
	if(party == kFriendParty)
	{
		return m_friendFormation;
	}
	else
	{
		return m_enemyFormation;
	}
}

bool BattleScene::isObjectInFormation(char party, uint16_t objectId) const
{
	BattleFormation *formation = getFormation(party);
	if(!formation) return false;
	return formation->isMember(objectId);
}

void BattleScene::getFriendFormationRoutePoints(std::vector<WayPoint> *routePoints)
{
	WayPoint wp;
	std::vector<ObjectInfo> pointInfos;
	const BattleSceneProperty &pty = getBattleScene(m_sceneId);
	pointInfos.insert(pointInfos.end(), pty.point_infos.begin(), pty.point_infos.end());

	for(auto it = pointInfos.begin(); it != pointInfos.end(); ++it)
	{
		const ObjectInfo &info = *it;
		if(info.tid == scenecfg::kFriendWayPoint)
		{
			if(info.nodeIndex == m_currentNodeIndex + 1)
			{
				wp.position = GridUtil::sharedGridUtil().pixToGrid(info.position.x, info.position.y);
				routePoints->push_back(wp);
			}
		}
	}

	for(auto it = m_enemyBarracks.begin(); it != m_enemyBarracks.end(); ++it)
	{
		BattleBuilding *building = it->second.building;
		if(building->getParty() == kEnemyParty && building->getNodeIndex() == m_currentNodeIndex + 1)
		{
			wp.reset();
			wp.index = it->first;
			routePoints->push_back(wp);
			break;
		}
	}
}

void BattleScene::getEnemyFormationRoutePoints(std::vector<WayPoint> *routePoints, int toward, const GridPosition &position, int height)
{
	WayPoint wp;
	height = height - 1;
	switch(toward)
	{
		case BattleObject::kRightDown:
		{
			wp.position.x = position.x + height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kLeftDown:
		{
			wp.position.x = position.x;
			wp.position.y = position.y - height;
			break;
		}
		case BattleObject::kLeftUp:
		{
			wp.position.x = position.x - height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kRightUp:
		{
			wp.position.x = position.x;
			wp.position.y = position.y + height;
			break;
		}
		case BattleObject::kRightDownDown:
		{
			wp.position.x = position.x + height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kLeftDownDown:
		{
			wp.position.x = position.x;
			wp.position.y = position.y - height;
			break;
		}
		case BattleObject::kLeftUpUP:
		{
			wp.position.x = position.x - height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kRightUpUp:
		{
			wp.position.x = position.x;
			wp.position.y = position.y + height;
			break;
		}
		case BattleObject::kRightDownRight:
		{
			wp.position.x = position.x + height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kLeftDownLeft:
		{
			wp.position.x = position.x;
			wp.position.y = position.y - height;
			break;
		}
		case BattleObject::kLeftUpLeft:
		{
			wp.position.x = position.x - height;
			wp.position.y = position.y;
			break;
		}
		case BattleObject::kRightUpRight:
		{
			wp.position.x = position.x;
			wp.position.y = position.y + height;
			break;
		}
		default:
			assert(false);
	}
	
	routePoints->push_back(wp);
}

void BattleScene::changeCageTroopNodeIndex()
{
	BattleTroop *saveCageTroop = m_battleStatistics.getCurCageTroop();
	saveCageTroop->setNodeIndex(m_currentNodeIndex);
}

void BattleScene::updateCageSoldierView()
{
	for (size_t i = 0; i < m_views.size(); ++i)
	{
		m_views[i]->onUpdateCageSoldierView();
	}
}


//处理过警戒线之后第一次敌将反应
void BattleScene::dealFirstEnemyTroopRunAway()
{
	std::vector<BattleMoveObject *> fobjs = getGenerals();
	dealEnemyTroopRunAway(fobjs);
}

//处理过警戒线后再招将
void BattleScene::dealPassEnemyTroopRunAway(BattleMoveObject *mo)
{
	if (isInThisBattleMode(MainScene::kBattleDungeonReward) && m_isPassWarnPoint)
	{
		std::vector<BattleMoveObject *> fobjs;
		fobjs.push_back(mo);
		dealEnemyTroopRunAway(fobjs);
	}
}

void BattleScene::dealEnemyTroopRunAway(vector<BattleMoveObject *>& fobjs)
{
	
}

bool BattleScene::isLastNodeGenGeneralPointOver()
{
	bool isGenGeneralPointOver = true;
	bool isBarrackGenGeneralPointOver = true;

	for (auto iter = m_enemyGenGeneralPoints.begin(); iter != m_enemyGenGeneralPoints.end(); ++iter)
	{
		if (isLastNode((*iter)->getNodeIndex()) && (!(*iter)->isFinish()))
		{
			isGenGeneralPointOver = false;
			break;
		}
	}
	for(IDBuilding::iterator iter = m_enemyBuildings.begin(); iter != m_enemyBuildings.end(); ++iter)
	{
		GenGeneralPoint *gpt = iter->second->getGenGeneralPoint();
		if (isLastNode(gpt->getNodeIndex()) && (!gpt->isFinish()))
		{
			isBarrackGenGeneralPointOver = false;
			break;
		}
	}
	return isGenGeneralPointOver && isBarrackGenGeneralPointOver;
}

bool BattleScene::isTroopInGroup(char party, unsigned char troopId) const
{
	return m_battleRecord->isTroopInGroup(party, troopId);
}

template<typename T>
void BattleScene::genBattleReport(BattleReport *br, T attacker, BattleMoveObject *defender, int skillId)
{
	static const int kVeryLargeHatred = 1000;
	assert(!defender->isDead());

	SkillGroupInfo group;
	skill::splitSkillLvId(&group.skill_group_id, &group.level, skillId);

	if (attacker->getBattleEffect()->isViolent)		//攻击者是狂暴状态
	{
		attacker->getBattleEffect()->isViolent = false;
		 			BuffMgr::theMgr().removeObjectBuff(attacker->getId(), 500);	//移除狂暴
		 			BuffMgr::theMgr().setAttackObject(defender);
		 			BuffMgr::theMgr().sleep(1,defender->getId(),2);
					//SKILLLOGIC_SPECIAL_BUFF(group.skill_group_id, defender->getId(), group.level);
		 			BuffMgr::theMgr().clearAttackObject();
	}
	if (SKILLLOGIC_HAS_FX(group.skill_group_id))
	{
		FxMgr::theMgr().setSkillLvId(skillId);
		FxMgr::theMgr().setMoveObject(defender);
		SKILLLOGIC_FX(group.skill_group_id, group.level);
		FxMgr::theMgr().setSkillLvId(0);
	}
	if (defender->getType() == BattleMoveObject::kGeneral)
	{
		attacker->runPassiveFxs(PassiveFx::kAttackTargetsEnemyGeneral);
	}
	genBattleReport_(br, attacker, defender, skillId);
	if (attacker->isThug() && !attacker->isDead() && !defender->isDead())
	{
		if (!defender->isNearAttack())
		{
			defender->addHatred(kVeryLargeHatred, attacker->getId());
		}
	}
}