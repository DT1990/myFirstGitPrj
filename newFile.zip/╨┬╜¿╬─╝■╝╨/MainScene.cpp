﻿#include "MainScene.h"
#include "SimpleAudioEngine.h"
#include "audio/AudioMgr.h"
#include "base/ZOrder.h"
#include "base/logger.h"
#include "base/TouchPriority.h"
#include "base/EventDispatcher.h"
#include "base/UIConst.h"
#include "base/UIColor.h"
#include "base/InternalEvent.h"
#include "base/TouchPriority.h"
#include "battle/BattleScene.h"

#include "CommonUI/Layout.h"
#include "CommonUI/Label.h"
#include "CommonUI/Bar.h"
#include "CommonUI/Button.h"
#include "widget/CCBullet.h"
#include "widget/CCImageBtn.h"
#include "widget/CCNumTimer.h"
#include "widget/CCActionPanel.h"
#include "IAudio.h"
#include "2d/CCTransition.h"

#include "recycle/RecycleMgr.h"
#include "util/ActionRunner.h"
#include "util/str_util.h"
#include "util/view_util.h"
#include "util/PanelUtil.h"
#include "util/EquipmentUtil.h"
#include "util/AntiSpeedAbnormal.h"
#include "util/GeneralCfgUtil.h"
#include "util/LuaLogicUtil.h"
#include "util/BattleSceneTemplateUtil.h"
#include "configure/TextConfigure.h"
#include "configure/PassConfigure.h"
#include "configure/StringConfigure.h"

#include "configure/SoldierConfigure.h"
#include "configure/MonsterSoldierConfigure.h"

#include "configure/SystemConfigure.h"
#include "configure/SkillConfigure.h"
#include "configure/GenGeneralPointConfigure.h"
#include "configure/GenGeneralPointActionConfigure.h"
#include "configure/EffectRotateConfigure.h"
#include "configure/SoldierCommonConfigure.h"

#include "xmlconfig/TerrainConfigure.h"
#include "xmlconfig/IntervalConfigure.h"
#include "xmlconfig/CustomEffectConfigure.h"

#include "view/BattleSceneView.h"
#include "view/UILayer.h"
#include "view/SceneView.h"


#include "model/GameGeneralManager.h"
#include "model/ResourceModel.h"
#include "model/GameFunctionManager.h"
#include "model/GamePvp.h"


#include "replay/ReplayRecorder.h"
#include "replay/ReplayPlayer.h"
#include "replay/ReplayUtil.h"
#include "base/InternalEvent.h"

#ifdef _WINDOWS
#include <crtdbg.h>
#endif

#include "view/SceneLayer.h"
#include "view/LoadingView.h"
#include "util/AsyncTextureMgr.h"
#include "CCLuaEngine.h"

#include "view/BattleDropOutLayer.h"
#include "util/IntervalAnimationDisplayNode.h"

#include "util/SystemCfgUtil.h"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
#include "Classes/android/JniUtil.h"
#include "platform/android/jni/JniHelper.h"
#endif


using namespace cocos2d;
using namespace std::placeholders;

MainScene *MainScene::s_theScene = NULL;
const int MainScene::kTagBattleClosePanel = -999;

static void releaseUnusedResources()
{
	CCSpriteFrameCache::sharedSpriteFrameCache()->removeUnusedSpriteFrames();
	CCTextureCache::sharedTextureCache()->removeUnusedTextures();
	RecycleMgr::theMgr().clear();
}

MainScene::MainScene()
: m_uiLayer(NULL)
, m_notifyLayer(NULL)
, m_sceneView(NULL)
, m_sceneDistant(NULL)
, m_runner(NULL)
, m_currentSceneType(kMainScene)
, m_battleMode(kBattlePass)
, m_battleType(kBattleNormal)
, m_isGm(false)
, m_isReplay(false)
, m_memoryWarningId(-1)
, m_isShowPass(false)
, m_isPreCalReady(false)
{
}

MainScene::~MainScene()
{
	m_runner->clear();
	m_runner->release();
	resetScene();
}

void MainScene::onExit()
{
	Node::onExit();
	IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
	if (audioEx)
	{
		audioEx->stopMusic(true);
	}
}

static void mainSceneCreated()
{
}

bool MainScene::init()
{
	INFO_MSG("enter game =====================");
	m_runner = ActionRunner::create();
	m_runner->retain();
	releaseUnusedResources();
	return true;
}

void MainScene::battleBegin(int battleMode, int battleType)
{
	m_battleMode = battleMode;
	m_battleType = battleType;

	AsyncTextureMgr::theMgr()->reset();

	int sceneId = PASS_SCENE_ID(m_curPassId);

	const CCSize &size = CCDirector::sharedDirector()->getWinSize();
	LoadingView *lv = LoadingView::create(kTouchPriorityHighest, LoadingView::kBattleBegin);
	lv->setAnchorPoint(ccp(0.5f, 0.5f));
	lv->setPosition(ccp(size.width * 0.5f, size.height * 0.5f));
	lv->setHandler(std::bind(&MainScene::createBattleView, this));
	m_loadingView = lv;
	addChild(lv, kZOrderLoadingLayer);

	m_runner->queueAction(DelayNFrames::delay(1));
	m_runner->queueAction(CallFuncAction::withFunctor(std::bind(&releaseUnusedResources)));
	m_runner->queueAction(CallFuncAction::withFunctor(std::bind(&LoadingView::loadBattleRes, lv, sceneId)));
		
}


void MainScene::createBattleView()
{
	int sceneId = PASS_SCENE_ID(m_curPassId);

	BattleScene *bs = BattleScene::create(sceneId);
	bs->initScenePoint(sceneId);
	BattleSceneView *sceneView = BattleSceneView::withModel(bs);


	addChild(sceneView, kZOrderSceneView);
	m_sceneView = sceneView;

	m_currentSceneType = kBattleScene;

	sceneView->battleStart();
}

void MainScene::reEnterBattle()
{
	m_isPreCalReady = true;

	//AsyncTextureMgr::theMgr()->reset();

	if (m_sceneView)
	{
		removeChild(m_sceneView, true);
		m_sceneView = NULL;
	}

	//AsyncTextureMgr::theMgr()->reset();
	//releaseUnusedResources();

	LuaLogicVariable::theMgr()->clearSoldierIds();
	GameSoldierManager::theMgr()->clearSoldiers();

	LuaLogicUtil::reInitBattleData();

	m_runner->queueAction(DelayNFrames::delay(1));
	m_runner->queueAction(CallFuncAction::withFunctor([=](){createBattleView(); }));
	//m_runner->queueAction(DelayNFrames::delay(1));
	//m_runner->queueAction(CallFuncAction::withFunctor([=](){BattleScene::getCurrentScene()->setIsRealStart(true); }));
}

void MainScene::battleEnd()
{

	AsyncTextureMgr::theMgr()->reset();

	if (m_sceneView)
	{
		removeChild(m_sceneView, true);
		m_sceneView = NULL;
	}

	stopAllEffects();

	setIsGm(false);

	AntiSpeedAbnormal::theASA()->sendReport();

	AsyncTextureMgr::theMgr()->reset();
	releaseUnusedResources();
	if (!Director::getInstance()->getIsRender())  //战斗计算器保留原来的场景切换
	{
		CCDirector::getInstance()->popScene();
	}
	LuaLogicVariable::theMgr()->clearSoldierIds();
	GameSoldierManager::theMgr()->clearSoldiers();
	LuaLogicUtil::onBattleSceneExit();
	
}

void MainScene::resetScene()
{
	s_theScene = NULL;
}

MainScene *MainScene::create()
{
	assert(s_theScene == NULL);
	s_theScene = new MainScene();
	s_theScene->init();
	s_theScene->autorelease();
	return s_theScene;
}

static void closeWindow()
{
}

void MainScene::update(float dt)
{
}

static void onRequestFailed(int code, const std::string &reason) {}

/*BattleSceneLuaHelper*/
BattleSceneLuaHelper::BattleSceneLuaHelper()
{
}

BattleSceneLuaHelper::~BattleSceneLuaHelper()
{
}

void BattleSceneLuaHelper::battleBegin(int battleType, int passId)
{
}

void BattleSceneLuaHelper::setLogLvl(int level)
{
	setLogLevel(level);
}

//可删除，删除后需改lua导出

int MainScene::getCurPanelId()
{
	return -1;
}

void MainScene::addUIWidget(cocos2d::Node *node, int zOrder, bool closeBehind)
{
}


bool MainScene::removeUIWidget(CCActionPanel *panel)
{
	return false;
}

void MainScene::backUIWidget(int layer, bool showEachUi)
{
}

void MainScene::backOrCloseUIWidget()
{
}

bool MainScene::isPanelSame(int panelId, int usage)
{
	return false;
}

void MainScene::updatePanelRecord(const PanelRecord &record, int index)
{
}

void MainScene::removePanelRecord(const PanelRecord &record)
{
}

void MainScene::changeScene(int sceneType, Node *node)
{
	/*if (sceneType == m_currentSceneType) return;
	if (m_sceneView)
	{
		INFO_MSG("before change scene count = %d", m_sceneView->retainCount());
		removeChild(m_sceneView);
		m_sceneView = NULL;
	}

	m_currentSceneType = sceneType;
	const CCSize &size = CCDirector::sharedDirector()->getWinSize();
	m_sceneView = node;
	m_sceneView->setAnchorPoint(ccp(0.5f, 0.5f));
	m_sceneView->setPosition(ccp(size.width * 0.5f, size.height * 0.5f));
	addChild(m_sceneView, kZOrderSceneView);*/
}

void MainScene::addAnnouncement(cocos2d::Node *node)
{
}

void MainScene::setTip(cocos2d::Node *node, int tipType)
{
}

void MainScene::addNoTouchLayer()
{

}

void MainScene::removeNoTouchLayer()
{

}

void MainScene::addUiBg(const cocos2d::Size &size)
{
}

void MainScene::removeUiBg()
{

}

static const float kDistantSceneMoveSpeedFactor = 0.2f;
void MainScene::updateDistantScenePosition(const CCPoint &offset)
{
// 	if (!m_sceneDistant) return;
// 	BattleScene *scene = BattleScene::getCurrentScene();
// 
// 	float x = m_sceneDistant->getPositionX() + offset.x * kDistantSceneMoveSpeedFactor;
// 	float y = m_sceneDistant->getPositionY() + offset.y * kDistantSceneMoveSpeedFactor;
// 
// 	const CCSize &winSize = CCDirector::sharedDirector()->getWinSize();
// 	const CCSize &distantSize = m_sceneDistant->getContentSize();
// 	float halfW = distantSize.width * 0.5f;
// 	float halfH = distantSize.height * 0.5f;
// 	float l = x - halfW;
// 	float r = x + halfW;
// 	float b = y - halfH;
// 	float t = y + halfH;
// 	if (l > 0.0f)
// 	{
// 		x = halfW;
// 	}
// 	else if (r < winSize.width)
// 	{
// 		x = winSize.width - halfW;
// 	}
// 	if (b > 0.0f)
// 	{
// 		y = halfH;
// 	}
// 	else if (t < winSize.height)
// 	{
// 		y = winSize.height - halfH;
// 	}
// 
// 	m_sceneDistant->setPosition(CCPoint(x, y));
}

void MainScene::challengeDungeonReward()
{
	m_isGm = false;
	//battleBegin(kBattleDungeonReward);
}
