require("gamecom/commonUtil")
require("gamecom/util")
require("res/config/DemoBattle")

BattleLuaScene = {}
BATTLE_LOG = function(...)
    local str = ""
    local arg = {...}
    for i,v in ipairs(arg) do
        str = str .. v
    end
    print(...)
    --LuaCHelper:theHelper():runLog(str)
end
local SCENEVIEW_OFFSET = 128  --地图场景的Y轴偏移量
local BattleRealData = {}
local BattleLocalRetData = {}
local soliderIndex = 1
local enemySoliderIndex = 1
local trueStart = false

local battleEnd = false
local inBattle = false

local m_allMoveObjData = {}

local friendTroopIdToInfo = {}
local enemyTroopIdToInfo = {}
local battleIsWin = false
local battleIsInDebug = false

local towerAllHP = 0
local nowAllTowerHP = 0

local doorAllHP = 0
local doorNowAllHP = 0

local BattleType = {
    kBattleNormal = 1,      --正常的PVE和PVP
    kBattleAttackCity = 2,  --攻城战
    kBattleMagic = 3,        --魔法门关卡战
    kBattleElementStrom = 4,  --元素风暴副本
    kDemoBattle = 5            --演示关卡
}

--攻城战数据
local BattleResultData = {}
local isPVPAttackCity = false
local PVPAttackData = nil
local attackTimes = 0
local curAttackTimes = 0


local battleLuaValue = {}

local testTime = 0
local testStartTime = 0
local totalFrames = 0

--local battlePassEnemyTroops = nil  --pass模式下敌方部队的记录，用于取敌方血量
isShowBattleHp = false --是否显示血条

--魔法门dungeonId
local magicDungeonId = 0
local timeLast = 0      --剩余时间

local BattleTrapData = nil
local BattleReplyData = nil

local battleResultUi = nil

local BattleArmyCal = require("battle_scene.BattleArmyCal")

local initBattleLuaValue = function()
    battleLuaValue = {
        isFirstUpdate = true,
        isAutoBattle = nil,
        isTrueStartBattle = nil,
        hadMakeTroopFriend = nil,
        hadMakeTroopEnemy = nil,
        cntTime = 0,
        battleMode = BattleMode.kBattlePass,
        battleType = BattleType.kBattleNormal,
        mainSceneObj = nil,
        battleFriendTroopData = {},
        friendTroopAdd = 0,
        friendTroopAddTime = 0,
        oneInit = true,
        startToScaleScene = false,
        startToFollow = false,
        troopIndex = -1,  --10001 表示友方部队的1号match， 20001表示敌方部队的1号match
        soliderUiMap = {},
        battleLineData = {},
        isTimeUp = false,
        friendsHp = 0,      --部队血量统计
        friendsCurHp = 0,
        enemysHp = 0,
        enemyCurHp = 0,
        enemyPoint = {x=0,y=0},
        friendPoint = {x=0,y=0},
        matchIndex = 1,
        armyType = 0,       --是否为军团类型,1为是
        playerDataIsArmy = false,
        enemyDataIsArmy = false,
        playerArmyTroopData = nil,  --军团重新计算布阵后的数据
        enemyArmyTroopData = nil,
        playerArmyTroopInfo = {},--playerId:{heroId,heroTId,heroLv,heroPower,matchData = {oldNum,curNum,soldierId}}
        enemyArmyTroopInfo = {}
    }
end
initBattleLuaValue()

function BattleLuaScene:getArmyTroopInfo(party)
    if party == BattleParty.kFriendParty then
        return battleLuaValue.playerArmyTroopInfo
    else
        return battleLuaValue.enemyArmyTroopInfo
    end
end

function BattleLuaScene:getArmyTroopInfoByPlayerId(playerId)
    if battleLuaValue.playerArmyTroopInfo[playerId] then
        return battleLuaValue.playerArmyTroopInfo[playerId] 
    else
        return battleLuaValue.enemyArmyTroopInfo[playerId]
    end
end

function BattleLuaScene:getTotalFrames()
    return totalFrames
end

function BattleLuaScene:getBattleReplyData()
    return BattleReplyData
end

function BattleLuaScene:getBattleMode()
    return battleLuaValue.battleMode
end

function BattleLuaScene:isPVPAttackCity()
    return isPVPAttackCity
end

function BattleLuaScene:setPVPAttackCity(value)
    isPVPAttackCity = value
end

function BattleLuaScene:setIsInBattle(value)
    inBattle = value
end

function BattleLuaScene:getIsInBattle()
    return inBattle
end

function BattleLuaScene:getBattleTrapData()
    return BattleTrapData
end

function BattleLuaScene:setBattleTrapData(data)
    BattleTrapData = data
end

function BattleLuaScene:clearValue()
    initBattleLuaValue()
    soliderIndex = 1
    enemySoliderIndex = 1
    trueStart = false
    battleEnd = false
    m_allMoveObjData = {}
    friendTroopIdToInfo = {}
    enemyTroopIdToInfo = {}
    battleIsWin = false
    battleIsInDebug = false
    towerAllHP = 0
    testTime = 0
    testStartTime = 0
    totalFrames = 0
    --battlePassEnemyTroops = nil

    towerAllHP = 0
    nowAllTowerHP = 0
    doorAllHP = 0
    doorNowAllHP = 0

    self.battleInfoMenu = nil
end

function BattleLuaScene:onMoveObjUpdateByLua(objId, dt)
    if m_allMoveObjData[objId] == nil then
        local data = {Id = objId, startTime = dt}
        local obj = require("battle_scene.MoveObjLuaLogic").new():initWithData(data)
        obj:update(dt)
        m_allMoveObjData[objId] = obj
    else
        local obj = m_allMoveObjData[objId]
        obj:update(dt)
    end
    return 0
end

function BattleLuaScene:isBattleVictory()
    --print("isBattleVictory")
    local retResult = false
    local scene = BattleScene:getCurrentScene()
    local sceneView = BattleSceneView:getCurrentSceneView()
    if battleLuaValue.battleMode == BattleMode.kBattlePass then
        local enemys = scene:getSceneMoveObj(BattleParty.kEnemyParty)
        local towers = scene:getSceneTowersManual(BattleParty.kEnemyParty)
        local doors = scene:getSceneEnemyDoorManual()
        local nums = table.nums(enemys)
        local enemyViews = sceneView:getMoveObjectViewCount(BattleParty.kEnemyParty)
        local numTower = table.nums(towers)
        local numDoors = table.nums(doors)
        if (nums == 0 or enemyViews == 0) and numTower == 0 and numDoors == 0 then
            retResult = true
        end
    elseif battleLuaValue.battleMode == BattleMode.kBattlePVP then
        if battleLuaValue.isTimeUp then --时间到
            --分别计算双方所有战斗单位的剩余血量总和与战斗初始时的血量总和比例，剩余比例高的一方判定为胜利，若双方剩余比例一致，判定总输出伤害更高的一方胜利
            local friendsCurHp = BattleLuaScene:getTroopTotalHp(BattleParty.kFriendParty)
            local enemysCurHp = BattleLuaScene:getTroopTotalHp(BattleParty.kEnemyParty)
            local friendsMaxHp = BattleLuaScene:getTroopMaxHp(BattleParty.kFriendParty)
            local enemysMaxHp = BattleLuaScene:getTroopMaxHp(BattleParty.kEnemyParty)
            local myHpRate = friendsCurHp / friendsMaxHp
            local enemyHpRate = enemysCurHp / enemysMaxHp
            if myHpRate ~= enemyHpRate then
                if myHpRate > enemyHpRate then
                    retResult = true
                else
                    retResult = false
                end
            else
                local myHurt = friendsMaxHp - friendsCurHp
                local enemyHurt = enemysMaxHp - enemysCurHp
                if myHurt >= enemyHurt then
                    retResult = true
                else
                    retResult = false
                end
            end
        else
            local enemys = scene:getSceneMoveObj(BattleParty.kEnemyParty)
            local towers = scene:getSceneTowersManual(BattleParty.kEnemyParty)
            local doors = scene:getSceneEnemyDoorManual()
            local nums = table.nums(enemys)
            local enemyViews = sceneView:getMoveObjectViewCount(BattleParty.kEnemyParty)
            local numTower = table.nums(towers)
            local numDoors = table.nums(doors)
            if (nums == 0 or enemyViews == 0) and numTower == 0 and numDoors == 0 then
                retResult = true
            end
        end

    end
    return retResult
end

function BattleLuaScene:isBattleFail()
    local retResult = true
    local scene = BattleScene:getCurrentScene()
    local sceneView = BattleSceneView:getCurrentSceneView()
    if battleLuaValue.battleMode == BattleMode.kBattlePass then
        if battleLuaValue.isTimeUp then --时间到
            return retResult
        end
        local friends = scene:getSceneMoveObj(BattleParty.kFriendParty)
        local friendViews = sceneView:getMoveObjectViewCount(BattleParty.kFriendParty)
        if nums ~= 0 and friendViews~=0 then
            retResult = false
        end
    elseif battleLuaValue.battleMode == BattleMode.kBattlePVP then
        if battleLuaValue.isTimeUp then --时间到
            log4battle:info("失败")
        else
            local friends = scene:getSceneMoveObj(BattleParty.kFriendParty)
            local friendViews = sceneView:getMoveObjectViewCount(BattleParty.kFriendParty)
            local nums = table.nums(friends)
            --print(nums)
            if nums ~= 0 and friendViews~=0 then
                retResult = false
            end
        end
    end
    return retResult
end

--军团部队计算受伤情况数据
function BattleLuaScene:calArmyHurtData(party,battleNum)
    -- [playerId] : {heroId,heroTId,heroLv,heroPower,matchData = {oldNum,curNum,soldierId}}
    local armyData = BattleLuaScene:getArmyTroopInfo(party)
    for playerId,playerData in pairs(armyData) do
        local heroId = playerData.heroId
        local heroTid = playerData.heroTId
        local heroLv = playerData.heroLv
        local heroPower = playerData.playerPower
        for match,v in pairs(playerData.matchData) do
            local oldNum = v.oldNum
            local curNum = math.max(v.curNum,0)
            local tid = v.soldierId
            local hurtRate = SoldierConfig[tid].injury / 10000             --受伤率

            local loseSoldier = oldNum  --损耗士兵
            if battleLuaValue.battleMode == BattleMode.kBattlePass then  -- PVE则需要乘上损耗因子
                loseSoldier = math.ceil((oldNum - curNum) * SystemConfig["loss_rate"].value)
            else
                loseSoldier = math.ceil(oldNum - curNum)
            end
            local surSoldier = curNum                                       --存活士兵
            local hurtSoldier = math.ceil(loseSoldier * hurtRate)           --受伤士兵
            local deadSoldier = loseSoldier - hurtSoldier                   --死亡士兵

            local outputData = {}

            table.insert(outputData, battleNum)    --场次
            table.insert(outputData, playerId)    --玩家id
            table.insert(outputData, heroId)    --英雄ID
            table.insert(outputData, heroTid)   --英雄tid
            table.insert(outputData, heroLv)    --英雄等级
            table.insert(outputData, match)    --位置
            table.insert(outputData, tid)    --士兵id
            table.insert(outputData, surSoldier)   --存活的士兵
            table.insert(outputData, hurtSoldier)   --受伤士兵
            table.insert(outputData, deadSoldier)   --死亡的士兵

            if party == BattleParty.kFriendParty then
                BattleResultData:pushPlayerSurData(outputData)
            else
                BattleResultData:pushEnemySurData(outputData)
            end

        end
    end
end

--计算受伤情况数据
function BattleLuaScene:calHurtData(party,troopInfo,battleNum)
    --table.print(troopInfo)
    local tid = troopInfo.tid
    local troopId = troopInfo.troopId
    local match = troopInfo.match
    local oldNum = troopInfo.oldNum  --总兵力
    local newNum = troopInfo.newNum  --剩余兵力
    local isMonster = troopInfo.isMonster
    local maxHp = BattleLuaScene:getTroopMaxHpById(party,troopId)
    local nowHp = math.max(0,BattleLuaScene:getTroopTotalHpById(party,troopId))
    local hurtRate = 0
    if not isMonster then
        hurtRate = SoldierConfig[tid].injury / 10000             --受伤率
    end

    local loseSoldier = oldNum  --损耗士兵
    if battleLuaValue.battleMode == BattleMode.kBattlePass and not isMonster then  -- PVE则需要乘上损耗因子
        loseSoldier = math.ceil((maxHp-nowHp)/maxHp * oldNum * SystemConfig["loss_rate"].value)
    else
        loseSoldier = math.ceil((maxHp-nowHp)/maxHp * oldNum)
    end
    local surSoldier = oldNum - loseSoldier                         --存活士兵
    local hurtSoldier = math.ceil(loseSoldier * hurtRate)           --受伤士兵
    local deadSoldier = loseSoldier - hurtSoldier                   --死亡士兵

    --保存计算后的数据
    if party == BattleParty.kFriendParty then
        friendTroopIdToInfo[troopId].loseSoldier = loseSoldier
        friendTroopIdToInfo[troopId].surSoldier = surSoldier
        friendTroopIdToInfo[troopId].hurtSoldier = hurtSoldier
        friendTroopIdToInfo[troopId].deadSoldier = deadSoldier
    else
        enemyTroopIdToInfo[troopId].loseSoldier = loseSoldier
        enemyTroopIdToInfo[troopId].surSoldier = surSoldier
        enemyTroopIdToInfo[troopId].hurtSoldier = hurtSoldier
        enemyTroopIdToInfo[troopId].deadSoldier = deadSoldier
    end
    local outputData = {}
    if not battleNum then
        battleNum = 1
    end
    table.insert(outputData, battleNum)    --场次

    local playerId = 1
    if party == BattleParty.kFriendParty and friendTroopIdToInfo[troopId].player_id then
        playerId = friendTroopIdToInfo[troopId].player_id
    end
    local heroId = BattleRealData.hero_id
    local heroTid = BattleRealData.hero_tid
    local heroLv = BattleRealData.hero_lv
    local enemyPlayerId = 1
    if battleLuaValue.battleMode == BattleMode.kBattlePVP then
        if party == BattleParty.kEnemyParty and enemyTroopIdToInfo[troopId].player_id then
            enemyPlayerId = enemyTroopIdToInfo[troopId].player_id
        end
    end
    local enemyHeroId = BattleRealData.enenmy_hero_id
    local enemyHeroTid = BattleRealData.enenmy_hero_tid
    local enemyHeroLv = BattleRealData.enenmy_hero_lv

    if party == BattleParty.kFriendParty then
        table.insert(outputData, playerId)    --玩家id
        table.insert(outputData, heroId)    --英雄ID
        table.insert(outputData, heroTid)   --英雄tid
        table.insert(outputData, heroLv)    --英雄等级
    elseif battleLuaValue.battleMode == BattleMode.kBattlePVP and party == BattleParty.kEnemyParty then
        table.insert(outputData, enemyPlayerId)    --玩家id
        table.insert(outputData, enemyHeroId)    --英雄ID
        table.insert(outputData, enemyHeroTid)    --英雄tid
        table.insert(outputData, enemyHeroLv)    --英雄等级
    else   --PVE的敌方伤兵信息
        table.insert(outputData, 1)
        table.insert(outputData, 1)    --英雄ID
        table.insert(outputData, 1)    --英雄tid
        table.insert(outputData, 1)    --英雄等级
    end

    table.insert(outputData, match)    --位置
    table.insert(outputData, tid)    --士兵id
    table.insert(outputData, surSoldier)   --存活的士兵
    table.insert(outputData, hurtSoldier)   --受伤士兵
    table.insert(outputData, deadSoldier)   --死亡的士兵

    --print("计算受伤情况数据:",party)
    --table.print(outputData)

    return outputData

end


function BattleLuaScene:onBattleSceneExit()
    if Game then
        Singleton(UIMgr):getRootWindow():exitBattle()
        BattleLuaScene:resetSpeed()
    end
    --BattleLuaScene:sendBattleResult()
    inBattle = false

    collectgarbage("collect")

    BattleLuaScene:clearValue()

    self:destroy()
    battleResultUi = nil
end

function BattleLuaScene:destroy()
    BATTLE_LOG("资源释放")
    Audioex.playBackGoundMusic(playMusicScene.exploreSceneBGM)
end

--攻城，车轮战开启，重进战斗
function BattleLuaScene:reEnterBattle()
    if inBattle then
        return
    end
    inBattle = true
    BattleLuaScene:clearValue()
    BattleRealData = {}
    curAttackTimes = curAttackTimes + 1
    BattleResultData:setBattleNum(curAttackTimes)
    log4battle:info("curAttackTimes:"..curAttackTimes)
    log4battle:info("转换兵力")
    local battleData = PVPAttackData[curAttackTimes]
    if battleData.playerdata_isarmy == 1 then  --我方是军团部队
        for k,v in pairs(battleData.playerData) do
            v.num = BattleResultData:getArmySoldierNum(v.player_id,v.battleMatch)
            log4battle:info("player_id:"..v.player_id)
            log4battle:info("match:"..v.battleMatch)
            log4battle:info("soldierNum:"..v.num)
        end
    else
        for k,v in pairs(battleData.playerData) do
            v.num = BattleResultData:getTroopSoldierNum(v.battleMatch)
            log4battle:info("match:"..v.battleMatch)
            log4battle:info("soldierNum:"..v.num)
        end
    end
    
    battleData.tower_defense = BattleResultData:getTowerDefence()
    battleData.wall_defense = BattleResultData:getWallDefence()
    battleData.trap = BattleTrapData:getServerTrapData()
    BattleLuaScene:preStartBattle(battleData)
end

--统计当场战斗剩余兵力信息
function BattleLuaScene:getSoldierCond(party)
    local data = {}
    data.totalSoldier = BattleLuaScene:getTotalSoldierNum(party)
    data.lastSoldier = BattleLuaScene:getLastSoldierNum(party)
    if party == BattleParty.kFriendParty then
        data.fightNum = BattleRealData.playerPower
    else
        data.fightNum = BattleRealData.enemyPower
    end

    data.hurtNum = BattleLuaScene:getHurtSoldierNum(party)
    return data
end


--每场战斗结束后统计数据
function BattleLuaScene:calOneRoundData(isWin)
    if cc.Director:getInstance():getIsReply() then
        log4reply:info("calOneRoundData")
    else
        log4battle:info("calOneRoundData")
    end
    --保存当场的战况,计算伤兵情况
    local win = 0
    if isWin then
        win = 1
    end
    BattleResultData:setResult(win)


    if battleLuaValue.playerDataIsArmy then  --军团伤兵计算
        BattleLuaScene:calArmyHurtData(BattleParty.kFriendParty,curAttackTimes)
    else
        for k,v in pairs(friendTroopIdToInfo) do
            local node = BattleLuaScene:calHurtData(BattleParty.kFriendParty,v,curAttackTimes)
            BattleResultData:pushPlayerSurData(node)
        end
    end
    
    if battleLuaValue.enemyDataIsArmy then   --军团伤兵计算
        BattleLuaScene:calArmyHurtData(BattleParty.kEnemyParty,curAttackTimes)
    else
        for k,v in pairs(enemyTroopIdToInfo) do
            local node = BattleLuaScene:calHurtData(BattleParty.kEnemyParty,v,curAttackTimes)
            BattleResultData:pushEnemySurData(node)
        end
    end

    --print(towerAllHP,nowAllTowerHP)
    local towerDecHp = towerAllHP - nowAllTowerHP
    local doorDecHp = doorAllHP- doorNowAllHP

    BattleResultData:addWallDec(doorDecHp)
    BattleResultData:addTowerDec(towerDecHp)

    --战斗中箭塔每损失100点生命值降低一点城防值，不足100不计算
    local loseTowerDef = math.floor(towerDecHp/100)
    local lastDef = BattleLuaScene:getTowerDefence()
    local curDef = lastDef - loseTowerDef
    if curDef < 0 then curDef = 0 end
    BattleResultData:setTowerDefence(curDef)

    --城墙城防值
    local loseWallDef = math.floor(doorDecHp/100)
    local lastDef = BattleLuaScene:getWallDefence()
    local curDef = lastDef - loseWallDef
    if curDef < 0 then curDef = 0 end
    BattleResultData:setWallDefence(curDef)

    if battleLuaValue.playerDataIsArmy then  --军团保存我方兵力
        BattleResultData:reInitArmyPlayerData()
        for playerId,playerData in pairs(battleLuaValue.playerArmyTroopInfo) do
            for match,v in pairs(playerData.matchData) do
                BattleResultData:pushArmyPlayerData(playerId,match,v.curNum)
            end
        end
    else
        BattleResultData:reInitPlayerData()
        --保存我方兵力(key-match,value-num)
        for k,v in pairs(friendTroopIdToInfo) do
            BattleResultData:pushPlayerData(v.match,v.nowNum)
        end
    end

    if cc.Director:getInstance():getIsReply() then
        log4reply:info("箭塔失去血量："..towerDecHp)
        log4reply:info("城门失去血量："..doorDecHp)
        log4reply:info("剩余陷阱：")
        log4reply:info(BattleTrapData:getServerTrapData())
        log4reply:info("保存的我方兵力")
        log4reply:info(BattleResultData.playerData)
    else
        log4battle:info("箭塔失去血量："..towerDecHp)
        log4battle:info("城门失去血量："..doorDecHp)
        log4battle:info("剩余陷阱：")
        log4battle:info(BattleTrapData:getServerTrapData())
        log4battle:info("保存的我方兵力")
        log4battle:info(BattleResultData.playerData)
    end
    

    --剩余兵力信息，结算界面
    if isWin then   --我方是胜利方
        local tSoldierData = BattleLuaScene:getSoldierCond(BattleParty.kFriendParty)
        BattleResultData:setSoldierData(true,tSoldierData)
        tSoldierData = BattleLuaScene:getSoldierCond(BattleParty.kEnemyParty)
        BattleResultData:setSoldierData(false,tSoldierData)
    else
        local tSoldierData = BattleLuaScene:getSoldierCond(BattleParty.kEnemyParty)
        BattleResultData:setSoldierData(true,tSoldierData)
        tSoldierData = BattleLuaScene:getSoldierCond(BattleParty.kFriendParty)
        BattleResultData:setSoldierData(false,tSoldierData)
    end


end

--处理攻城战
function BattleLuaScene:dealAttackCityBattle()
    log4battle:info("dealAttackCityBattle")
    BattleLuaScene:endBattleAction()
    BattleSceneView:getCurrentSceneView():battleResult(isWin)
    local callBack = function()
        MainScene:theScene():battleEnd()
	   local callBack1 = function()
       		log4battle:info("callBack = function()")
        	BattleLuaScene:reEnterBattle()
    	end
    	local tScene = nil
        if Game then
            tScene = Singleton(UIMgr):getRootWindow():getBaseScene()
        end
        if BattleCalculator then
            tScene = BattleCalculator.mainScene
        end
        assert(tScene)
    	tScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callBack1)))
        --director:endToLua()
    end
    local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
    mainScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callBack)))
end

--处理战斗计算器结果
function BattleLuaScene:dealCalculatorFinished(isWin)
    --TODO:
    local sendData = nil
    if isPVPAttackCity then
        log4battle:info("攻城模式下的处理")
        battleLuaValue.battleType = BattleType.kBattleAttackCity
        BattleLuaScene:calOneRoundData(isWin)
            --print(isWin,curAttackTimes,attackTimes)
        if isWin and curAttackTimes~=attackTimes then --还没打完继续打
            BattleResultData:genRecordFile()        --每场战斗都生成回放文件
            BattleLuaScene:dealAttackCityBattle()
            return
        end
        curAttackTimes = 0
        attackTimes = 0
        isPVPAttackCity = false
        PVPAttackData = nil

        sendData = BattleResultData:sendBattleResult()
    else
        log4battle:info("普通模式下的处理")
        BattleLuaScene:calOneRoundData(isWin)
        sendData = BattleResultData:sendBattleResult()
    end
    BattleLuaScene:endBattleAction()
    BattleSceneView:getCurrentSceneView():battleResult(isWin)


    --退出战斗并且发送战斗数据
    local callBack = function()
        MainScene:theScene():battleEnd()
        BattleCalculator:sendBattleResult(sendData)
	   local callBack1 = function()
        	local director = cc.Director:getInstance()
        	director:setIsStartCal(false)
    	end
    	local tScene = BattleCalculator.mainScene

    	tScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callBack1)))
        --director:endToLua()
    end
    local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
    mainScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callBack)))
end

function BattleLuaScene:getResultPanel()
    return battleResultUi
end

--胜利界面
function BattleLuaScene:showSuccessPanel(info,isDefender)
    log4reply:info("结算数据：")
    log4reply:info(info)
    --结算数据
    local data = {}
    data.isDefender = isDefender
    if info and info[1] then
        info = info[1]
        data.lingZhuExp = info.self_exp
        data.heroExp = info.hero_exp
        if isDefender then
            data.resources = {}
            data.goods = {}
        else
            data.resources = info.resources
            data.goods = info.goods
        end
    else
        data.lingZhuExp = 0
        data.heroExp = 0
        data.resources = {}
        data.goods = {}
    end
    if cc.Director:getInstance():getIsReply() then
        local isSuccess = true
        if BattleReplyData then
            isSuccess = BattleReplyData:getIsSuccess()
        end
        local tdata = BattleResultData:getSoldierData(isSuccess)
        data.totalSoldier = tdata.totalSoldier
        data.lastSoldier = tdata.lastSoldier
        data.fightNum = tdata.fightNum
        data.hurtNum = tdata.hurtNum
    else
        data.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
        data.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
        data.fightNum = BattleRealData.playerPower
        data.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
    end
    log4reply:info("最终处理的结算数据：")
    log4reply:info(data)

    --结算界面处理
    local layer = nil
    if battleLuaValue.battleMode == BattleMode.kBattlePVP then
        layer = require("ui.battle.BattlePVPSuccessPanel").new(data)
    else
        layer = require("ui.battle.BattlePVESuccessPanel").new(data)
    end
    layer:setVisible(false)
    self.battleInfoMenu:addChild(layer,99999)
    layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))
    battleResultUi = layer
end


function BattleLuaScene:showPVPFailPanel(info,isDefender)
    for k,v in pairs(friendTroopIdToInfo) do
        BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
    end
    local data = {}
    data.isDefender = isDefender
    if info and info[1] then
        info = info[1]
        data.lingZhuExp = info.self_exp
        data.heroExp = info.hero_exp
        if isDefender then
            data.resources = info.resources
            data.goods = info.goods
        else
            data.resources = {}
            data.goods = {}
        end
    else
        data.lingZhuExp = 0
        data.heroExp = 0
        data.resources = {}
        data.goods = {}
    end
    if cc.Director:getInstance():getIsReply() then
        local isSuccess = true
        if BattleReplyData then
            isSuccess = BattleReplyData:getIsSuccess()
        end
        local tdata = BattleResultData:getSoldierData(isSuccess)
        data.totalSoldier = tdata.totalSoldier
        data.lastSoldier = tdata.lastSoldier
        data.fightNum = tdata.fightNum
        data.hurtNum = tdata.hurtNum
    else
        data.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
        data.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
        data.fightNum = BattleRealData.playerPower
        data.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
    end
    local layer = require("ui.battle.BattlePVPFailPanel").new(data,isDefender)
    self.battleInfoMenu:addChild(layer,99999)
    layer:setVisible(false)
    layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))

    battleResultUi = layer
end


--显示失败界面
function BattleLuaScene:showFailPanel(isWin)
    --BATTLE_LOG("showFailPanel")
    if not isWin or BattleTestData then
        BATTLE_LOG("showFailPanel")
        for k,v in pairs(friendTroopIdToInfo) do
            BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
        end
        local data = {}
        if cc.Director:getInstance():getIsReply() then
            local isSuccess = true
            if BattleReplyData then
                isSuccess = BattleReplyData:getIsSuccess()
            end
            data = BattleResultData:getSoldierData(isSuccess)
        else
            data.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
            data.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
            data.fightNum = BattleRealData.playerPower
            data.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
        end
        local layer = require("ui.battle.BattleFailPanel").new(data)
        self.battleInfoMenu:addChild(layer,99999)
        layer:setVisible(false)
        layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))

        battleResultUi = layer

        if BattleTestData then
            BattleTestData = nil
        end
    end
end

--显示PVE失败界面
function BattleLuaScene:showPVEFailPanel(isWin)
    --BATTLE_LOG("showFailPanel")
    if not isWin or BattleTestData then
        BATTLE_LOG("showPVEFailPanel")
        for k,v in pairs(friendTroopIdToInfo) do
            BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
        end
        local data = {}
        if cc.Director:getInstance():getIsReply() then
            local isSuccess = true
            if BattleReplyData then
                isSuccess = BattleReplyData:getIsSuccess()
            end
            data = BattleResultData:getSoldierData(isSuccess)
        else
            data.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
            data.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
            data.fightNum = BattleRealData.playerPower
            data.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
        end
        local layer = require("ui.battle.BattlePVEFailPanel").new(data)
        self.battleInfoMenu:addChild(layer,99999)
        layer:setVisible(false)
        layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))

        battleResultUi = layer

        if BattleTestData then
            BattleTestData = nil
        end
    end
end


function BattleLuaScene:dealBattleFinished(isWin)
    if cc.Director:getInstance():getIsReply() then
        log4reply:info("dealBattleFinished")
    else
        log4battle:info("dealBattleFinished")
    end
    battleIsWin = isWin
    if battleIsWin == true then
        Audioex.playBackGoundMusic(playMusicScene.battleWinBGM)
    else
        Audioex.playBackGoundMusic(playMusicScene.battleFailBGM)
    end
    BattleSceneView:getCurrentSceneView():pauseAmbient()
    --计算箭塔和城墙血量
    local scene = BattleScene:getCurrentScene()
    nowAllTowerHP = 0
    local towers = scene:getSceneTowersManual(BattleParty.kEnemyParty)
    for k,v in pairs(towers) do
        local tower = v
        nowAllTowerHP = nowAllTowerHP + tower:getHp()
    end
    doorNowAllHP = scene:getCityDoorHp()
    if PRINT_TEST_TIME then
        local totalTimes = BattleScene:getCurrentScene():getCurrentTime()-testStartTime
        if cc.Director:getInstance():getIsReply() then
            log4reply:info("总帧数："..totalFrames)
            log4reply:info("总耗时：(ms)"..totalTimes)
            log4reply:info("平均每帧耗时：(ms)"..(totalTimes/totalFrames))
        else
            log4battle:info("总帧数："..totalFrames)
            log4battle:info("总耗时：(ms)"..totalTimes)
            log4battle:info("平均每帧耗时：(ms)"..(totalTimes/totalFrames))
        end
    end
    --战斗计算器直接退出场景
    if BattleCalculator then
        BattleLuaScene:dealCalculatorFinished(isWin)
    else
        --以下逻辑只会在客户端执行
        BattleSceneView:getCurrentSceneView():setIsBattleResult(true)
        BattleSceneView:getCurrentSceneView():setIsWin(isWin)

        self.battleInfoMenu:showDebugFrames()

        local isPVPAttackMode = isPVPAttackCity
        --客户端模拟攻城模式
        if isPVPAttackCity then
            log4battle:info("攻城模式下的处理")
            battleLuaValue.battleType = BattleType.kBattleAttackCity
            BattleLuaScene:calOneRoundData(isWin)
            --print(isWin,curAttackTimes,attackTimes)
            if isWin and curAttackTimes~=attackTimes then --还没打完继续打
                if BATTLE_CAL_MOD_DEBUG then
                    BattleResultData:genRecordFile()        --每场战斗都生成回放文件
                end
                BattleLuaScene:dealAttackCityBattle()
                return
            end

            curAttackTimes = 0
            attackTimes = 0
            isPVPAttackCity = false
            PVPAttackData = nil
        end

        BattleSceneView:getCurrentSceneView():battleResult(isWin)
        BattleLuaScene:endBattleAction()

        if isPVPAttackMode then  --攻城模式，客户端模拟下的胜负结算
            if isWin then
                BattleLuaScene:showSuccessPanel(BattleResultData:getWinReward())
            else
                BattleLuaScene:showFailPanel(isWin)
            end
            BattleResultData:sendBattleResult()
        elseif battleLuaValue.battleType == BattleType.kBattleMagic then  --魔法门的战斗结束请求
            log4magic:info("dealBattleFinished17002")
            if MainScene:theScene():getIsPreCalReady() then
                netCom.send(
                    {BattleLocalRetData.result,BattleLocalRetData.star,#BattleLocalRetData.troopData,BattleLocalRetData.troopData},
                    17002, 
                    function(pack) 
                        BattleLuaScene:magicBattleResultResp(pack,BattleLocalRetData.isWin,BattleLocalRetData.star) 
                    end
                )
                cc.Director:getInstance():setIsReply(false)
            else
                 local troopData = {}        --存活数据
                for k,v in pairs(friendTroopIdToInfo) do
                    local node = BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
                    table.insert(troopData, node)
                end
                log4magic:info("troopData")
                log4magic:info(troopData)
                local star = BattleLuaScene:getMagicBattleStar()
                if testMagicBattleStar then
                    star = testMagicBattleStar
                end
                -- @wt todo
                local result = isWin and 1 or 0
                local _type = DungeonConfig.type(magicDungeonId)
                if _type == 2 and isWin then
                    result = 2
                end
                log4magic:info("17002================ battle_scene result->"..result)

                BattleLocalRetData.result = result
                BattleLocalRetData.star = star
                BattleLocalRetData.troopData = troopData
                BattleLocalRetData.isWin = isWin
                BattleLocalRetData.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
                BattleLocalRetData.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
                BattleLocalRetData.fightNum = BattleRealData.playerPower
                BattleLocalRetData.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
                local callBack = function()
                    print("callBack")
                    MainScene:theScene():reEnterBattle()
                end
                local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
                mainScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.01),cc.CallFunc:create(callBack)))
            end
        elseif battleLuaValue.battleType == BattleType.kBattleElementStrom then  --元素风暴的战斗结束请求
            log4element:info("dealBattleFinished64002")
            if MainScene:theScene():getIsPreCalReady() then
                -- @wt todo
                netCom.send(
                    {BattleLocalRetData.isWin and 1 or 0,#BattleLocalRetData.troopData,BattleLocalRetData.troopData},
                    64002, 
                    function(pack) 
                        BattleLuaScene:elementStromBattleResultResp(pack,BattleLocalRetData.isWin) 
                    end
                )
                cc.Director:getInstance():setIsReply(false)
            else
                local troopData = {}        --存活数据
                for k,v in pairs(friendTroopIdToInfo) do
                    local node = BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
                    table.insert(troopData, node)
                end
                log4element:info("troopData")
                log4element:info(troopData)
                BattleLocalRetData.troopData = troopData
                BattleLocalRetData.isWin = isWin
                BattleLocalRetData.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
                BattleLocalRetData.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
                BattleLocalRetData.fightNum = BattleRealData.playerPower
                BattleLocalRetData.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
                local callBack = function()
                    MainScene:theScene():reEnterBattle()
                end
                local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
                mainScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callBack)))
            end
        elseif battleLuaValue.battleType == BattleType.kBattleNormal then --PVE和PVP以及所有回放模式下的处理
            BattleLuaScene:calOneRoundData(isWin)
            local isDefender = false
            local isSuccess = isWin
            if BattleReplyData then  --回放模式下的胜负控制
                local attackerWin = isWin
                local myWin = BattleReplyData:getIsSuccess()
                if attackerWin ~= myWin then
                    isDefender = true
                end
                isWin = myWin
            end
            if isWin then
                BattleLuaScene:showSuccessPanel(BattleResultData:getWinReward(),isDefender)
            else
                if battleLuaValue.battleMode == BattleMode.kBattlePVP then
                    BattleLuaScene:showPVPFailPanel(BattleResultData:getWinReward(),isDefender)
                else
                    BattleLuaScene:showPVEFailPanel(isWin)
                end
            end
            BattleResultData:sendBattleResult()
        elseif battleLuaValue.battleType == BattleType.kDemoBattle then 
            local troopData = {}        --存活数据
            for k,v in pairs(friendTroopIdToInfo) do
                local node = BattleLuaScene:calHurtData(BattleParty.kFriendParty,v)
                table.insert(troopData, node)
            end
            self:demoBattleResult(isWin)
            cc.Director:getInstance():setIsReply(false)
        end
    end
    
end

--获取魔法门星级
function BattleLuaScene:getMagicBattleStar()
    local star = 0
    local starTable = DungeonConfig[magicDungeonId].evaluate_value
    local timeLimit = starTable[2][1]              --通关时间少于timeLimit
    local soldierDeadLimit = starTable[3][1]       --兵力损耗低于soldierDeadLimit
    local deadRateLimit = soldierDeadLimit/10000
    local lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
    local totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
    local realDeadRate = (totalSoldier - lastSoldier) / totalSoldier

    log4magic:info("时间限制",timeLimit)
    log4magic:info("士兵损耗率",deadRateLimit)
    log4magic:info("实际士兵耗损",realDeadRate)
    if battleIsWin then
        star = star + 1
    end

    if timeLast > timeLimit then
        star = star + 1
    end

     if realDeadRate < deadRateLimit then
        star = star + 1
    end

    local _type = DungeonConfig.type(magicDungeonId)
    if _type == 2 then
        star = 0
    end

    log4magic:info("星级",star)
    return star
end


function BattleLuaScene:battlePreEffect()

end

function BattleLuaScene:doBuildingLuaAction(id, targetId)
    local retCode = -1
    if BattleTrapData then
        retCode = BattleTrapData:doBuildingLuaAction(id)
    end
    return retCode
end

function BattleLuaScene:addFriendGeneral(generalId, tid)
    local id = BattleScene:getCurrentScene():createGeneral(generalId, tid, false);
end

function BattleLuaScene:addTroop(party, nodeindex, soliderid, soliderToward, isMonster, num, pos,troopIndex,match)
    --local id = BattleScene:getCurrentScene():createGeneral(generalId, tid, false);
    --local commonId = SoldierConfig[soliderid].common_id
    if not troopIndex then troopIndex = -1 end 
    match = match or 1
    local scene = BattleScene:getCurrentScene()
    local troopId = scene:createTroop(party, nodeindex, soliderToward, soliderid, num, isMonster, pos, false,troopIndex,match)
    return troopId
end

function BattleLuaScene:getCrossMatchPos(party, matchType, centerPos) --十字阵型位置获取
    local retPos = centerPos
    if party == BattleParty.kFriendParty then
        if matchType == BattleMatch.kFront then
            retPos = cc.pAdd(centerPos, ccp(0, 7))
        elseif matchType == BattleMatch.kBack then
            retPos = cc.pAdd(centerPos, ccp(0, -7))
        elseif matchType == BattleMatch.kLeft then
            retPos = cc.pAdd(centerPos, ccp(-7, 0))
        elseif matchType == BattleMatch.kRight then
            retPos = cc.pAdd(centerPos, ccp(7, 0))
        elseif matchType == BattleMatch.kFriend then
            retPos = cc.pAdd(centerPos, ccp(7, -7))
        end
    else
        if matchType == BattleMatch.kFront then
            retPos = cc.pAdd(centerPos, ccp(0, -7))
        elseif matchType == BattleMatch.kBack then
            retPos = cc.pAdd(centerPos, ccp(0, 7))
        elseif matchType == BattleMatch.kLeft then
            retPos = cc.pAdd(centerPos, ccp(7, 0))
        elseif matchType == BattleMatch.kRight then
            retPos = cc.pAdd(centerPos, ccp(-7, 0))
        elseif matchType == BattleMatch.kFriend then
            retPos = cc.pAdd(centerPos, ccp(-7, 7))
        end
    end
    return retPos
end

function BattleLuaScene:initBattleCfg()
    local scene = BattleScene:getCurrentScene()
    --出生点信息
    local enemyPoint = BattleScene:getCurrentScene():getEnemyBornPoint()
    local friendPoint = BattleScene:getCurrentScene():getFriendBornPoint()

    --设置默认值
    if enemyPoint.x == 0 and enemyPoint.y == 0 then
        enemyPoint = BattlePosCfg["EnemyStartPos"]
    end

    if friendPoint.x == 0 and friendPoint.y == 0 then
        friendPoint = BattlePosCfg["FriendStartPos"]
    end

    battleLuaValue.enemyPoint = enemyPoint
    battleLuaValue.friendPoint = friendPoint

    scene:setTroopMemberBeginPos(BattleParty.kFriendParty, friendPoint);
    scene:setTroopMemberBeginPos(BattleParty.kEnemyParty, enemyPoint);
end

--将部队数据的key转化为match
function BattleLuaScene:adjustTroopData(troopData)
    if not troopData then return end

    local troopDataIdx = {}

    for k,v in pairs(troopData) do
        troopDataIdx[k] = v
    end

    for k,v in pairs(troopDataIdx) do
        if k < 100 then
            troopData[100 + v["battleMatch"]] = v
        end
    end

    for k,v in pairs(BattleMatch) do
        troopData[v] = nil
        if troopData[100 + v] ~= nil then
            troopData[v] = troopData[100 + v]
            troopData[100 + v] = nil
        end
    end
end

function BattleLuaScene:setScenceEvent(scence)
    -- body
    local eventDispatcher = scence:getEventDispatcher()
    local function onEnter()

    end

    local function onExit()
        BattleLuaScene:setIsInBattle(false)
        if Game then
            Game.heroCom:sysLeadSoliderInfo() --行军线消失时请求更新兵力数量
        end
    end

    local function onNodeEvent(event)
        if "enter" == event then
            onEnter()
        elseif "exit" == event then
            onExit()
        end
    end
    scence:registerScriptHandler(onNodeEvent)
end

function BattleLuaScene:getNeedCreateTroopSoldiers()
    local num = 0
    if BattleRealData.playerData then
        if battleLuaValue.playerDataIsArmy then  --军团情况
            for k,v in pairs(battleLuaValue.playerArmyTroopData) do
                num = num + 1
            end
        else
            for k,v in pairs(BattleRealData.playerData) do
                if v.num > 0 then
                    num = num + 1
                end
            end
        end
    end
    if BattleRealData.enemyData then
        if battleLuaValue.enemyDataIsArmy then
            for k,v in pairs(battleLuaValue.enemyArmyTroopData) do
                num = num + 1
            end
        else
            for k,v in pairs(BattleRealData.enemyData) do
                if v.num > 0 then
                    num = num + 1
                end
            end 
        end
    end
    return num
end

function BattleLuaScene:speedUp(rate)
    self.preFps = self.preFps or cc.Director:getInstance():getAnimationInterval()
    cc.Director:getInstance():setAnimationInterval(1/math.min(30*rate, 60))
    cc.Director:getInstance():getScheduler():setTimeScale(rate)
end

function BattleLuaScene:resetSpeed()
    if self.preFps then
        cc.Director:getInstance():setAnimationInterval(self.preFps)
    end
    cc.Director:getInstance():getScheduler():setTimeScale(1)
end

--军团兵力变化的统计
function BattleLuaScene:armySoldierHpChange(playerId,match,changeNum)
    playerId = tonumber(playerId)
    --print(playerId,match,changeNum)
    if battleLuaValue.playerArmyTroopInfo[playerId] then
        local oldNum = battleLuaValue.playerArmyTroopInfo[playerId].matchData[match].curNum
        battleLuaValue.playerArmyTroopInfo[playerId].matchData[match].curNum = math.max(0,oldNum + changeNum)
    elseif battleLuaValue.enemyArmyTroopInfo[playerId] then
        local oldNum = battleLuaValue.enemyArmyTroopInfo[playerId].matchData[match].curNum
        battleLuaValue.enemyArmyTroopInfo[playerId].matchData[match].curNum = math.max(0,oldNum + changeNum)
    else
        assert(false,"canot find playerId")
    end
    if self.battleInfoMenu then
        self.battleInfoMenu:updateArmySoldierPanel(playerId)
    end
end


--军团重组前的阵形兵力记录
function BattleLuaScene:initArmyTroopInfo(party,data)
    local targetArmyTroopInfo
    if party == BattleParty.kFriendParty then
        targetArmyTroopInfo = battleLuaValue.playerArmyTroopInfo
    else
        targetArmyTroopInfo = battleLuaValue.enemyArmyTroopInfo
    end
    log4battle:info(targetArmyTroopInfo)
    for k,v in pairs(data) do
        if not targetArmyTroopInfo[v.player_id] then
            targetArmyTroopInfo[v.player_id] = {}
            targetArmyTroopInfo[v.player_id].heroId = v.hero_id
            targetArmyTroopInfo[v.player_id].heroTId = v.hero_tid
            targetArmyTroopInfo[v.player_id].heroLv = v.hero_lv
            targetArmyTroopInfo[v.player_id].heroPower = v.hero_power
            targetArmyTroopInfo[v.player_id].matchData = {}
        end
        if not targetArmyTroopInfo[v.player_id].matchData[v.battleMatch] then
            targetArmyTroopInfo[v.player_id].matchData[v.battleMatch] = {
                oldNum = v.num,
                curNum = v.num,
                soldierId = v.soliderTid
            }
        end
    end
end

function BattleLuaScene:addSoldierData(party,data)
    BattleLuaScene:initArmyTroopInfo(party,data)
    local armyTroop = BattleArmyCal:calArmyTroop(data)
    if party == BattleParty.kFriendParty then
        battleLuaValue.playerArmyTroopData = armyTroop
    else
        battleLuaValue.enemyArmyTroopData = armyTroop
    end
    for troopIndex,troop in pairs(armyTroop) do
        for k,v in pairs(troop) do
            local curSoldier = GameSoldierManager:theMgr():addGameSoldier(party,troopIndex,v.player_id,v.battleMatch,v.soliderTid)
            local configValue = SoldierConfig[v.soliderTid]
            curSoldier:setSoldierNum(v["num"])
            curSoldier:setSoldierWallAttack(v["wallAttack"])
            curSoldier:setSoldierWallDefence(v["wallDefence"])
            curSoldier:setSoldierAtkHurtMul(v["atkHurtMul"])
            curSoldier:setSoldierDefenceMul(v["defenceMul"])
            curSoldier:setSoldierBreakDefence(configValue["breakDefence"])
            curSoldier:setSoldierPhysicHurtParame(kPhysicHurtParame)
            curSoldier:setSoldierMagicHurtParame(kMagicHurtParame)
            curSoldier:setSoldierWallAtkHurtParame(kWallAtkHurtParame)
            curSoldier:setSoldierMaxHp(v["hp"])
            curSoldier:setSoldierAttack(v["physicAttack"])
            curSoldier:setSoldierDefence(v["physicDefence"])
            curSoldier:setSoldierHit(v["hit"])
            curSoldier:setSoldierCrit(v["crit"])
            curSoldier:setSoldierDodge(v["dodge"])
            curSoldier:setSoldierMagicAttack(v["magicAttack"])
            curSoldier:setSoldierMagicDefence(v["magicDefence"])
            curSoldier:setSoldierMoveSpeed(v["speed"])
            curSoldier:setSoldierSkillDodge(v["skillDodge"])
            curSoldier:setSoldierInterArea(v["interArea"])
            curSoldier:setSoldierChaseDis(v["chaseDis"])
            curSoldier:setSoldierMaxAttDis(v["maxAttDis"])
            curSoldier:setSoldierAttackSpeed(v["attSpeed"])
        end
    end
end

function BattleLuaScene:start(battleMode, battleId)

    battleLuaValue.battleFriendTroopData = BattleRealData.playerData
    battleLuaValue.battleEnemyTroopData = BattleRealData.enemyData

    if BattleRealData.playerdata_isarmy == 1 then  --军团
        battleLuaValue.playerDataIsArmy = true
        BattleLuaScene:addSoldierData(BattleParty.kFriendParty,battleLuaValue.battleFriendTroopData)
    else
        BattleLuaScene:adjustTroopData(battleLuaValue.battleFriendTroopData)
    end

    if BattleRealData.enemydata_isarmy == 1 then  --军团
        battleLuaValue.enemyDataIsArmy = true
        BattleLuaScene:addSoldierData(BattleParty.kEnemyParty,battleLuaValue.battleEnemyTroopData)
    else
         BattleLuaScene:adjustTroopData(battleLuaValue.battleEnemyTroopData)
    end

    --print("battleLuaValue.playerArmyTroopInfo")
    --table.print(battleLuaValue.playerArmyTroopInfo)
    --print("battleLuaValue.enemyArmyTroopInfo")
    --table.print(battleLuaValue.enemyArmyTroopInfo)

    local troopData = battleLuaValue.battleFriendTroopData
    for k,v in pairs(battleLuaValue.battleFriendTroopData) do
        if v["num"] > 0 then
            LuaLogicVariable:theMgr():addFriendSoldierId(v["soliderTid"])
        end
    end

    if battleLuaValue.battleEnemyTroopData ~= nil then
        for k,v in pairs(battleLuaValue.battleEnemyTroopData) do
            if v["num"] > 0 then
                LuaLogicVariable:theMgr():addEnemySoldierId(v["soliderTid"])
            end
        end
    end

    local changeSceneFuncForCal = function()
        local nextScence = MainScene:create()
        nextScence:setCurPassId(battleId)
        
        cc.Director:getInstance():pushScene(tolua.cast(nextScence, "cc.Scene"));

        BattleLuaScene:setScenceEvent(tolua.cast(nextScence, "cc.Scene"))

        nextScence:battleBegin(battleMode,battleLuaValue.battleType)
        battleLuaValue.mainSceneObj = nextScence
    end
    local changeSceneFuncForGame = function()
        local data = {
            battleId        = battleId,
            battleMode      = battleMode,
            battleLuaValue  = battleLuaValue,
        }
        Singleton(UIMgr):getRootWindow():enterBattle(data)
    end
    if battleLuaValue.battleType == BattleType.kBattleMagic or battleLuaValue.battleType == BattleType.kBattleElementStrom then
        self:speedUp(3)
    else
        self:speedUp(1)
    end
    if Game then
        self:gotoBattleScene(changeSceneFuncForGame)
    else
        self:gotoBattleScene(changeSceneFuncForCal)
    end
    
    --cc.Director:getInstance():setIsRender(false)
end

function BattleLuaScene:gotoBattleScene(callback)
    if Game then
        local baseScene = Singleton(UIMgr):getRootWindow():getBaseScene()
        local animationInfo = EffectUiConfig[1]
        local skeletonNode = sp.SkeletonAnimation:create(animationInfo.json, animationInfo.atlas, 1.0)
        baseScene:addChild(skeletonNode, 100)
        local size = cc.Director:getInstance():getWinSize()
        skeletonNode:setPosition(size.width/2,size.height/2)
        skeletonNode:setAnimation(0, animationInfo.name, false)
        local callBackSeq = cc.Sequence:create(cc.CallFunc:create(callback),cc.CallFunc:create(function() skeletonNode:removeFromParent(true) end))
        baseScene:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),callBackSeq))
    else
        callback()
    end
end
function BattleLuaScene:initUi()
    if BATTLE_CAL_MOD then return end
    -- body
    self.battleInfoMenu = require("ui.battle.BattleInfoMenu").new(BattleRealData)
    self.battleInfoMenu:setTag(120)
    local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
    mainScene:addChild(self.battleInfoMenu, 9);
end

function BattleLuaScene:endBattleAction()
    battleEnd = true
    if self.battleInfoMenu then
        self.battleInfoMenu:enablePauseBtn(false)
    end
    -- if self.deadPanel then
    --     self.deadPanel = nil
    -- end
end

--战斗计时变化(秒)
function BattleLuaScene:onBattleTimeChanged(time)
    --print("time",time)
    if not BATTLE_CAL_MOD then
        --更新显示倒计时
        self.battleInfoMenu:updateLastTime(time)
    end
    timeLast = time
    local scene = BattleScene:getCurrentScene()
    if math.mod(time, 5) == 0 and battleLuaValue.startToFollow then
        scene:setAutoFocus(true)
    end
    if time <= 0 then
        battleLuaValue.isTimeUp = true
    end

    BattleSceneView:getCurrentSceneView():checkBattleResult()
end



function BattleLuaScene:onCreateTroop(party, troopId, isMonster, soldierTid, soldierCount)
    if cc.Director:getInstance():getIsReply() then
        log4reply:info("onCreateTroop: troopId="..troopId..",soldierTid="..soldierTid)
    else
        log4battle:info("onCreateTroop: troopId="..troopId..",soldierTid="..soldierTid)
    end
    if party == BattleParty.kEnemyParty then
        battleLuaValue.soliderUiMap[troopId] = enemySoliderIndex
        enemySoliderIndex = enemySoliderIndex + 1
        if battleLuaValue.battleMode == BattleMode.kBattlePass then
            --if not battlePassEnemyTroops then battlePassEnemyTroops = {} end
            --battlePassEnemyTroops[troopId] = troopId
            BattleLuaScene:initTroopInfo(BattleParty.kEnemyParty,battleLuaValue.matchIndex,soldierTid,soldierCount,troopId,isMonster)
            battleLuaValue.matchIndex = battleLuaValue.matchIndex + 1
        end
    else
        if not isMonster then       --只显示我方非怪物士兵的信息
            battleLuaValue.soliderUiMap[troopId] = soliderIndex
            soliderIndex = soliderIndex + 1
        end
    end
end

function BattleLuaScene:onTroopHpChange(party, troopId, num)
    local soliderIdx = battleLuaValue.soliderUiMap[troopId]
    if not soliderIdx then return end
    if soliderIdx > 6 then
        return
    end
    if battleEnd then
        return
    end
    

    if BattleParty.kFriendParty == party then
        if friendTroopIdToInfo[troopId] then
            friendTroopIdToInfo[troopId]["nowNum"] = num
            if not BATTLE_CAL_MOD then
                --更新menu士兵数目显示
                if self.battleInfoMenu then
                    self.battleInfoMenu:updateSoldierCount(party,soliderIdx,num)
                end
            end
        end
    elseif BattleParty.kEnemyParty == party then
        if enemyTroopIdToInfo and enemyTroopIdToInfo[troopId] then
            enemyTroopIdToInfo[troopId]["nowNum"] = num
            if not BATTLE_CAL_MOD then
                --更新menu士兵数目显示
                if self.battleInfoMenu then
                    self.battleInfoMenu:updateSoldierCount(party,soliderIdx,num)
                end
            end
        end
    end
end

function BattleLuaScene:onClickNodeGate(index)
    battleLuaValue.startToScaleScene = true
    BattleSceneView:getCurrentSceneView():onOpenCurrentNodeGate()
end

function BattleLuaScene:passMonsterSoliderPropInit()

end

function BattleLuaScene:initStaticObjectByLua(oldTid)
    local retTid = oldTid

    return retTid
end

function BattleLuaScene:getBuildingTypeByLua(tid)
    local buildingType = 1
    local commonId = nil
    if PassBuildingConfig[tid] then
        commonId = PassBuildingConfig[tid].common_id
    end
    if not commonId then
        commonId = MonsterPassTrapConfig[tid].common_id
    end
    if commonId >= 11 and commonId <= 14 then
        buildingType = 2
    end
    return buildingType
end

function BattleLuaScene:getTrapTidFromLuaWithPosTid(tid)
    local trapTid = 0
    local trapClass = trapDataList[tid]
    if trapClass ~= nil then
        for k,v in pairs(trapClass) do
            trapTid = k
        end
    end
    return trapTid
end
--初始化城墙血量（替换配置表属性-不需要）
function BattleLuaScene:initBattleBuildingPropByLua()
    return true
end

function BattleLuaScene:initBattleobjPropByLua()
    local luaVarMgr = LuaLogicVariable:theMgr()
    local initType = luaVarMgr:getInitPropType()
    local initTid = luaVarMgr:getInitPropTid()
    local troopIndex = luaVarMgr:getTroopIndex()
    local isMonster = luaVarMgr:getIsMonster()
    --加载手动创建部队的士兵属性（PVP和PVE中的我方部队和PVP中的敌方部队）
    --print("initTid",initTid)
    --print("troopIndex",troopIndex)
    --print("isMonster",isMonster)
    if isMonster == false then
        local configValue = SoldierConfig[initTid]
        local prop = LuaLogicVariable:theMgr():getInitProp()
        local matchIdx =  math.mod(troopIndex,10)
        local party =  math.modf(troopIndex/10000)

        local troopData = battleLuaValue.battleFriendTroopData[matchIdx]
        if party == BattleParty.kEnemyParty then
            troopData = battleLuaValue.battleEnemyTroopData[matchIdx]
        end

        prop[BattleProp.kWallAttack + 1] = troopData["wallAttack"]
        prop[BattleProp.kWallDefence + 1] = troopData["wallDefence"]
        prop[BattleProp.kAttckHurtMul + 1] = troopData["atkHurtMul"]  --后端获得
        prop[BattleProp.kDefenceIgnoreHurt + 1] = troopData["defenceMul"] --后端获得
        prop[BattleProp.kBreakDefence + 1] = configValue["breakDefence"]

        prop[BattleProp.kPhysicHurtParame + 1] = kPhysicHurtParame
        prop[BattleProp.kMagicHurtParame + 1] = kMagicHurtParame
        prop[BattleProp.kWallAtkHurtParame + 1] = kWallAtkHurtParame

        prop[BattleProp.kHpMax + 1] = troopData["hp"]
        prop[BattleProp.kPhysicAttack + 1] = troopData["physicAttack"]
        prop[BattleProp.kPhysicDefence + 1] = troopData["physicDefence"]
        prop[BattleProp.kHit + 1] = troopData["hit"]
        prop[BattleProp.kCrit + 1] = troopData["crit"]
        prop[BattleProp.kDodge + 1] = troopData["dodge"]
        prop[BattleProp.kMagicAttack + 1] = troopData["magicAttack"]
        prop[BattleProp.kMagicDefence + 1] = troopData["magicDefence"]
        prop[BattleProp.kSpeed + 1] = troopData["speed"]
        prop[BattleProp.kSkillDodge + 1] = troopData["skillDodge"]
        prop[BattleProp.kInterArea + 1] = troopData["interArea"]
        prop[BattleProp.kChaseDis + 1] = troopData["chaseDis"]
        prop[BattleProp.kMaxAttDis + 1] = troopData["maxAttDis"]
        prop[BattleProp.kAttSpeed + 1] = troopData["attSpeed"]

        LuaLogicVariable:theMgr():setInitProp(prop)
    --加载场景部队的士兵属性（怪物），PVE中的怪物部队
    else
        local prop = LuaLogicVariable:theMgr():getInitProp()
        local configValue = MonsterSoldierConfig[initTid]
        prop[BattleProp.kWallAttack + 1] = configValue["wallAttack"]
        prop[BattleProp.kWallDefence + 1] = configValue["wallDefence"]
        prop[BattleProp.kAttckHurtMul + 1] = 0  --PVE忽略
        prop[BattleProp.kDefenceIgnoreHurt + 1] = 0 --PVE忽略
        prop[BattleProp.kBreakDefence + 1] = configValue["breakDefence"]
        prop[BattleProp.kPhysicHurtParame + 1] = kPhysicHurtParame
        prop[BattleProp.kMagicHurtParame + 1] = kMagicHurtParame
        prop[BattleProp.kWallAtkHurtParame + 1] = kWallAtkHurtParame
        LuaLogicVariable:theMgr():setInitProp(prop)
    end
    return true
end

function BattleLuaScene:luaCalcHurt()
    --攻击方_破防系数,不同兵种配置不同
    --无BUFF
    -- local ret = LuaLogicVariable:theMgr():getHurtDamage()
    -- ret["totalDamage"] = ret["totalDamage"]*(2n/（n+1）)
    -- LuaLogicVariable:theMgr():setHurtDamage(ret);
end

--获取箭塔城防值，为0不生成箭塔
function BattleLuaScene:getTowerDefence()
    return BattleRealData.tower_defense
end

--获取城墙城防值，为0不生成城墙
function BattleLuaScene:getWallDefence()
    return BattleRealData.wall_defense
end

--获取城墙生命值，攻城战的时候替换城墙血量
function BattleLuaScene:getWallLife()
    return BattleRealData.wall_life
end

--获取城墙的护甲，攻城战的时候替换城墙护甲
function BattleLuaScene:getWallArmor()
    return BattleRealData.wall_armor
end

--获取箭塔的攻击，攻城替换
function BattleLuaScene:getTowerAtk()
    return BattleRealData.tower_atk
end

--获取箭塔的生命值，攻城替换
function BattleLuaScene:getTowerLife()
    return BattleRealData.tower_life
end

--获取箭塔的护甲，攻城替换
function BattleLuaScene:getTowerArmor()
    return BattleRealData.tower_armor
end

--获取关卡id
function BattleLuaScene:getBattleId(passId)
    if battleLuaValue.battleMode == BattleMode.kBattlePVP then
        if battleLuaValue.battleType == BattleType.kBattleNormal then
            return 101
        elseif battleLuaValue.battleType == BattleType.kBattleAttackCity then
            return 100
        end
    else
        return passId
    end
end

--准备进入战斗
function BattleLuaScene:preStartBattle(battleData)
    BattleRealData = battleData
    battleLuaValue.battleMode = BattleRealData.battleMode
   -- print("armyType",battleData.type)
    battleLuaValue.armyType = battleData.type
    local battleId = BattleRealData.passId
    -- if BattleTestData then
    --     battleId = BattleRealData.passId
    -- else
    --     battleId = self:getBattleId(BattleRealData.passId)
    -- end
    if cc.Director:getInstance():getIsReply() then
        log4reply:info("battleId:"..battleId)
    else
        log4battle:info("battleId:"..battleId)
    end
    BattleTroop:resetTroopInfo()

    BattleLuaScene:start(battleLuaValue.battleMode, battleId)
end

function BattleLuaScene:reInitBattleData()
    BattleLuaScene:clearValue()
    --BattleLuaScene:speedUp(1)

    battleLuaValue.battleMode = BattleRealData.battleMode
    battleLuaValue.battleType = MainScene:theScene():getBattleType()
    battleLuaValue.armyType = BattleRealData.type
    local battleId = BattleRealData.passId

    battleLuaValue.battleFriendTroopData = BattleRealData.playerData
    battleLuaValue.battleEnemyTroopData = BattleRealData.enemyData

    BattleLuaScene:adjustTroopData(battleLuaValue.battleFriendTroopData)
    BattleLuaScene:adjustTroopData(battleLuaValue.battleEnemyTroopData)

    local troopData = battleLuaValue.battleFriendTroopData
    for k,v in pairs(battleLuaValue.battleFriendTroopData) do
        if v["num"] > 0 then
            LuaLogicVariable:theMgr():addFriendSoldierId(v["soliderTid"])
        end
    end

    if battleLuaValue.battleEnemyTroopData ~= nil then
        for k,v in pairs(battleLuaValue.battleEnemyTroopData) do
            if v["num"] > 0 then
                LuaLogicVariable:theMgr():addEnemySoldierId(v["soliderTid"])
            end
        end
    end

    MainScene:theScene():setCurPassId(battleId)
    local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
    mainScene:removeChildByTag(120)
end

--开启正常战斗
function BattleLuaScene:enterNormalBattle(battleData)
    if inBattle then
        return
    end
    inBattle = true
    BattleLuaScene:clearValue()
    battleLuaValue.battleType = BattleType.kBattleNormal

    --设置初始的陷阱数据
    BattleTrapData:setServerTrapData(battleData.datas[1].trap)
    BattleLuaScene:preStartBattle(battleData.datas[1])
    
end

--进入攻城战副本
function BattleLuaScene:enterAttackCityBattle(battleData)
    --攻城
    log4battle:info("攻城")
    if inBattle then
        return
    end
    inBattle = true
    BattleLuaScene:clearValue()
    battleLuaValue.battleType = BattleType.kBattleAttackCity
    BattleRealData = {}

    log4battle:info("攻城数据")
    log4battle:info(battleData.datas)

    isPVPAttackCity = true
    attackTimes = #battleData.datas
    PVPAttackData = battleData.datas
    curAttackTimes = 1

    --设置初始的陷阱数据
    BattleTrapData:setServerTrapData(PVPAttackData[curAttackTimes].trap)
    BattleLuaScene:preStartBattle(PVPAttackData[curAttackTimes])
end

--请求服务器进入魔法之门战斗
function BattleLuaScene:reqServerStartMagicBattle(heroId, copyId, dungeonId)
    log4magic:info("reqServerStartMagicBattle")
    magicDungeonId = dungeonId
    local function callback(pack)
        if inBattle then
            return
        end
        inBattle = true
        BattleLuaScene:clearValue()
        battleLuaValue.battleType = BattleType.kBattleMagic
        BattleRealData = {}
        BattleLocalRetData = {}
        --battleLuaValue.battleLineData = lineData
        local info, cursor = netCom.parsePackByProtocol(pack, cursor, "enter_magic_dungeon_resp")
        local battleData = {}
        battleData.playerData = info.playerData
        battleData.hero_id = info.hero_id
        battleData.hero_tid = info.hero_tid
        battleData.hero_lv = 0
        battleData.playerPower = info.playerPower
        battleData.passId = DungeonConfig[dungeonId].pass_id
        battleData.battleMode = BattleMode.kBattlePass
        BattleLuaScene:preStartBattle(battleData)
        log4magic:info("魔法们副本数据：")
        log4magic:info(battleData)
    end
    netCom.send({heroId, copyId, dungeonId}, 17001, callback)
end

--进入魔法门副本
function BattleLuaScene:enterMagicBattle(heroId, copyId, dungeonId)
    log4magic:info("enterMagicBattle")
    cc.Director:getInstance():setIsReply(true)
    -- 统计副本信息
    sdk_android_util.startDCLevels(dungeonId)

    BattleLuaScene:reqServerStartMagicBattle(heroId,copyId, dungeonId)
end

--请求服务器进入元素风暴副本
function BattleLuaScene:reqServerStartStromBattle(heroId,storm_id)
    --magicDungeonId = dungeonId
    netCom.send({heroId, storm_id}, 64001,
            function(pack)
                if inBattle then
                    return
                end
                inBattle = true
                BattleLuaScene:clearValue()
                battleLuaValue.battleType = BattleType.kBattleElementStrom
                BattleRealData = {}
                BattleLocalRetData = {}
                --battleLuaValue.battleLineData = lineData
                local info, cursor = netCom.parsePackByProtocol(pack, cursor, "enter_storm_resp")
                local battleData = {}
                battleData.playerData = info.playerData
                battleData.hero_id = info.hero_id
                battleData.hero_tid = info.hero_tid
                battleData.hero_lv = 0
                battleData.playerPower = info.playerPower
                battleData.passId = ElementStormCheckpointConfig[storm_id].attrId
                battleData.battleMode = BattleMode.kBattlePass
                BattleLuaScene:preStartBattle(battleData)
                log4element:info("元素风暴副本:")
                log4element:info(battleData)
            end)
end

function BattleLuaScene:enterDemoBattle(data)
    if inBattle then
        return
    end

    cc.Director:getInstance():setIsReply(true)
    inBattle = true
    BattleLuaScene:clearValue()
    battleLuaValue.battleType = BattleType.kDemoBattle
    BattleRealData = {}
    BattleTrapData = require "battle_scene.BattleTrapData"
    --设置初始的陷阱数据
    BattleTrapData:setServerTrapData(data.datas[1].trap)
    BattleLuaScene:preStartBattle(data.datas[1])


end

--进入元素风暴副本
function BattleLuaScene:enterElementStromBattle(heroId,storm_id)
    cc.Director:getInstance():setIsReply(true)
    BattleLuaScene:reqServerStartStromBattle(heroId,storm_id)
end

--元素风暴副本战斗结束返回
function BattleLuaScene:elementStromBattleResultResp(pack,isWin)
    log4element:info("elementStromBattleResultResp")
    local info, cursor = netCom.parsePackByProtocol(pack, cursor, "storm_result_resp")
    --结算数据
    local data = {}
    data.totalSoldier = BattleLocalRetData.totalSoldier
    data.lastSoldier = BattleLocalRetData.lastSoldier
    data.fightNum = BattleLocalRetData.fightNum
    data.hurtNum = BattleLocalRetData.hurtNum
    data.resources = {}
    data.goods = info.goods
    log4element:info("元素风暴的结算数据")
    log4element:info(data)

    Game.dispatchCustomEvent(CustomEventName.ELEMENT_STROM_BATTLE_RET,{isWin})
    local layer = nil
    --结算界面处理
    if isWin then
        layer = require("ui.battle.BattleStromSuccessPanel").new(data)
    else
        layer = require("ui.battle.BattleFailPanel").new(data)
    end
    layer:setVisible(false)
    self.battleInfoMenu:addChild(layer,99999)
    layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))
    battleResultUi = layer  
end

function BattleLuaScene:demoBattleResult(isWin)
     --结算数据
    local data = {}
    data.totalSoldier = BattleLuaScene:getTotalSoldierNum(BattleParty.kFriendParty)
    data.lastSoldier = BattleLuaScene:getLastSoldierNum(BattleParty.kFriendParty)
    data.fightNum = BattleRealData.playerPower
    data.hurtNum = BattleLuaScene:getHurtSoldierNum(BattleParty.kFriendParty)
    data.resources = {}
    data.goods = {}

    local layer = nil
    --结算界面处理
    if isWin then
        layer = require("ui.battle.BattleDemoSuccessPanel").new(data)
    else
        layer = require("ui.battle.BattleFailPanel").new(data)
    end
    layer:setVisible(false)
    self.battleInfoMenu:addChild(layer,99999)
    layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))
    battleResultUi = layer
end


--魔法门副本战斗结束返回
function BattleLuaScene:magicBattleResultResp(pack,isWin,star)
    local info, cursor = netCom.parsePackByProtocol(pack, cursor, "magic_dungeon_result_resp")
    --结算数据
    local data = {}
    data.totalSoldier = BattleLocalRetData.totalSoldier
    data.lastSoldier = BattleLocalRetData.lastSoldier
    data.fightNum = BattleLocalRetData.fightNum
    data.hurtNum = BattleLocalRetData.hurtNum
    data.resources = {}
    data.goods = info.goods

    log4magic:info("魔法门结算数据:")
    log4magic:info(data)

    Game.dispatchCustomEvent(CustomEventName.MAGIC_BATTLE_RET,{isWin,star})
    local layer = nil
    --结算界面处理
    if isWin then
        layer = require("ui.battle.BattleMagicSuccessPanel").new(data)
        Game.dupCom:getDupDataReq()
    else
        layer = require("ui.battle.BattleFailPanel").new(data)
    end
    layer:setVisible(false)
    self.battleInfoMenu:addChild(layer,99999)
    layer:runAction(cc.Sequence:create(cc.DelayTime:create(BattleParaConfig.value("result_panel_delay")),cc.Show:create()))
    battleResultUi = layer

    -- 统计副本战斗接口
    local isSuccess = isWin and 1 or 0
    sdk_android_util.completeDcLevels(magicDungeonId or 0, isSuccess, "")
end

--进入回放战斗
function BattleLuaScene:enterReplyBattle(lineData,isSuccess)
    cc.Director:getInstance():setIsReply(true)
    --回放只播放一场战斗
    BattleResultData = require "battle_scene.BattleResultData"
    BattleResultData:setBattleData(lineData)
    --回放数据接口
    BattleReplyData = require "battle_scene.BattleReplyData"
    BattleReplyData:setBattleData(lineData)
    BattleReplyData:setIsSuccess(isSuccess)

    BattleTrapData = require "battle_scene.BattleTrapData"

    --初始化奖励信息
    log4reply:info("回放奖励信息")
    log4reply:info(lineData.win_rewards)
    BattleResultData:setWinReward(lineData.win_rewards)
    BattleResultData:setLoseReward(lineData.lose_rewards)

    BattleLuaScene:enterNormalBattle(lineData)
end
--校验后端数据是否合法
function BattleLuaScene:checkServerData(data)
    if not data then
        return false
    end
    if #data.datas == 0 then
        return false
    end
    for kd,data in pairs(data.datas) do
        for kt,troopData in pairs(data) do
            for km,soldierData in pairs(data.playerData) do  --校验我方的部队的属性数据
                for k,v in pairs(soldierData) do
                    if v < 0 then
                        return false
                    end
                end  
            end
            if data.enemyData then
                for km,soldierData in pairs(data.enemyData) do  --校验对方的部队的属性数据
                    for k,v in pairs(soldierData) do
                        if v < 0 then
                            return false
                        end
                    end  
                end
            end
        end
    end
    return true
end

--战斗计算器的战斗入口和GM进入战斗的接口
function BattleLuaScene:enterBattle(lineData)
    --容错处理，后端战斗数据不对的时候
    if not BattleLuaScene:checkServerData(lineData) then
        if BattleCalculator then
            BattleCalculator:sendBattleError()
            return
        end
        return
    end

    log4battle:info("战斗数据")
    log4battle:info(lineData)
    --print("enterBattle",inBattle)
    if inBattle then
        return
    end
    if BATTLE_CAL_MOD_DEBUG then
        cc.Director:getInstance():setIsReply(true)
    end
    BattleResultData = require "battle_scene.BattleResultData"
    BattleResultData:setBattleData(lineData)
    BattleResultData:setLineID(lineData.line_id)
    BattleResultData:setBattleMode(lineData.battleMode)
    BattleResultData:setReportFileId(lineData.battle_log_name)
    --初始化奖励信息
    BattleResultData:setWinReward(lineData.win_rewards)
    BattleResultData:setLoseReward(lineData.lose_rewards)

    BattleTrapData = require "battle_scene.BattleTrapData"

    log4battle:info("Enter Battle!!!")
    local battleType = lineData.type ----1、普通 2、攻城 
    log4battle:info("battleType"..battleType)
    if battleType == BattleType.kBattleNormal then
        BattleLuaScene:enterNormalBattle(lineData)
    elseif battleType == BattleType.kBattleAttackCity then
        BattleLuaScene:enterAttackCityBattle(lineData)
    end
end
--初始化部队信息lua
function BattleLuaScene:initTroopInfo(party,match,soldierTid,num,troopId,isMonster,heroData)
    local targetTroopInfo = nil
    if party == BattleParty.kFriendParty then
        targetTroopInfo = friendTroopIdToInfo
    else
        targetTroopInfo = enemyTroopIdToInfo
    end
    targetTroopInfo[troopId] = {}
    targetTroopInfo[troopId]["match"] = match
    targetTroopInfo[troopId]["tid"] = soldierTid
    targetTroopInfo[troopId]["oldNum"] = num
    targetTroopInfo[troopId]["nowNum"] = num
    targetTroopInfo[troopId]["troopId"] = troopId
    targetTroopInfo[troopId]["isMonster"] = isMonster
    if heroData then   --非怪物需要存储
        targetTroopInfo[troopId]["player_id"] = heroData.playerId
        targetTroopInfo[troopId]["hero_id"] = heroData.heroId
        targetTroopInfo[troopId]["hero_tid"] = heroData.heroTid
        targetTroopInfo[troopId]["hero_lv"] = heroData.heroLv
    else
        targetTroopInfo[troopId]["player_id"] = 0
        targetTroopInfo[troopId]["hero_id"] = 0
        targetTroopInfo[troopId]["hero_tid"] = 0
        targetTroopInfo[troopId]["hero_lv"] = 0
    end
end

function BattleLuaScene:createEnemyMonsterTroop(tid)
    --BattleLuaScene:addTroop(BattleParty.kEnemyParty, 1, 100114, BattleToward.kLeftDown, true, 9, ccp(27, 30))
    BattleLuaScene:addTroop(BattleParty.kEnemyParty, 1, tid, BattleToward.kLeftDown, true, 9, ccp(27, 30))
end


function BattleLuaScene:createEnemyNotMonsterTroop()
    local scene = BattleScene:getCurrentScene()
    local towers = scene:getSceneTowersManual(BattleParty.kEnemyParty)
    local doors = scene:getSceneEnemyDoorManual()
    local nodeIndex = 1
    local troopData = battleLuaValue.battleEnemyTroopData
    for k,v in pairs(troopData) do
        if v["num"] > 0 then
            local pos = v["pos"] or BattleLuaScene:getCrossMatchPos(BattleParty.kEnemyParty,k, battleLuaValue.enemyPoint)
            battleLuaValue.troopIndex = 20000 + k
            local troopId = BattleLuaScene:addTroop(BattleParty.kEnemyParty, nodeIndex, v["soliderTid"], BattleToward.kLeftDown, false, v["num"],  pos,20000 + k,k)
            local heroData = {
                playerId = v["player_id"],
                heroId = v["hero_id"],
                heroTid = v["hero_tid"],
                heroLv = v["hero_lv"]
            }
            BattleLuaScene:initTroopInfo(BattleParty.kEnemyParty,k,v["soliderTid"],v["num"],troopId,false,heroData)
        end
    end
    battleLuaValue.troopIndex = -1
end

function BattleLuaScene:createSelfTroopAll()
    local troopData = battleLuaValue.battleFriendTroopData
    for k,v in pairs(troopData) do
        if v["num"] > 0 then
            local pos = v["pos"] or BattleLuaScene:getCrossMatchPos(BattleParty.kFriendParty,k, battleLuaValue.friendPoint)
            battleLuaValue.troopIndex = 10000 + k
            local troopId = BattleLuaScene:addTroop(BattleParty.kFriendParty, 0, v["soliderTid"], BattleToward.kRightUp, false, v["num"],  pos,10000 + k,k)
            local heroData = {
                playerId = v["player_id"],
                heroId = v["hero_id"],
                heroTid = v["hero_tid"],
                heroLv = v["hero_lv"]
            }
            BattleLuaScene:initTroopInfo(BattleParty.kFriendParty,k,v["soliderTid"],v["num"],troopId,false,heroData)
        end
        battleLuaValue.hadMakeTroopFriend = true
    end
    battleLuaValue.troopIndex = -1
end

function BattleLuaScene:getInitPropty()
    local retTable = {}
    for i=1,BattleProp.kBattlePropCount do
        retTable[i] = 0
    end
    retTable[BattleProp.kHpMax + 1] = 999
    retTable[BattleProp.kSpeed + 1] = 999
    return retTable
end

--统计帧时间
function BattleLuaScene:calFrameTime()
    if PRINT_TEST_TIME then
        totalFrames = totalFrames + 1
        if LuaLogicVariable:theMgr():getIsDebugMo() then
            log4battle:info("curFrame:--------"..totalFrames)
        end
        local curTime = BattleScene:getCurrentScene():getCurrentTime()
        if testTime == 0 then
            testTime = curTime
            testStartTime = curTime
        else
            --print("每帧时间:",curTime - testTime)
            testTime = curTime
        end
    end
end



function BattleLuaScene:updateBattle(dt)
    BattleLuaScene:calFrameTime()

    local scene = BattleScene:getCurrentScene()
    --构造troop的时候是分帧加载的，需要异步处理
    if scene:getIsRealStart() then
        scene:setIsRealStart(false)
        BattleSceneView:getCurrentSceneView():lockScreen()
        BattleLuaScene:initUi()
        self:onBattleTimeChanged(scene:getBattleTime())
        if battleLuaValue.battleType == BattleType.kBattleMagic or battleLuaValue.battleType == BattleType.kBattleElementStrom then
            if MainScene:theScene():getIsPreCalReady() then
                self:speedUp(1)
            end
        end
        local moveToCB = cc.CallFunc:create(
            function() 
                local point = cc.p(battleLuaValue.enemyPoint.x,battleLuaValue.enemyPoint.y)
                BattleSceneView:getCurrentSceneView():focusToGrid(point)
            end)
        local delayAction1 = cc.DelayTime:create(1)
        local moveBackCB = cc.CallFunc:create(
            function() 
                local point = cc.p(battleLuaValue.friendPoint.x,battleLuaValue.friendPoint.y)
                BattleSceneView:getCurrentSceneView():focusMoveTo(point, 2) 
            end)
        local delayAction2 = cc.DelayTime:create(2)
        local startBattleCB = cc.CallFunc:create(
            function()
                BattleSceneView:getCurrentSceneView():unLockScreen()
                scene:trueStartBattle()
                scene:setAutoFocus(true)
                battleLuaValue.startToFollow = true 
            end)
        local moveSeq = cc.Sequence:create(moveToCB,delayAction1,moveBackCB,delayAction2,startBattleCB)
        
        BattleSceneView:getCurrentSceneView():runAction(moveSeq)
        local doors = scene:getSceneEnemyDoorManual()
        if #doors ~= 0 then  --守城
            scene:troopRunOutDoor()
            local event = cc.EventCustom:new("showGateEvent")
            cc.Director:getInstance():getEventDispatcher():dispatchEvent(event)
        end
    end
    if battleLuaValue.startToFollow then
        scene:updateBattleData(dt)
        --BattleLuaScene:updateTroopHpChange()
        --BattleSceneView:getCurrentSceneView():checkBattleResult()
    end

    return 0
end

--场景初始化完成
function BattleLuaScene:onInitFinish()
    if cc.Director:getInstance():getIsReply() then
        log4reply:info("onInitFinish")
    else
        log4battle:info("onInitFinish")
    end
    Audioex.playBackGoundMusic(playMusicScene.battleSceneBGM,PassConfig.music(tonumber(BattleRealData.passId)))
    local scene = BattleScene:getCurrentScene()
    local setPos = BattleConfigData.mapPos
    BattleSceneView:getCurrentSceneView():setPosition(ccp(0,0))
    BattleSceneView:getCurrentSceneView():setBottomOffsetPos(ccp(0,0))
    BattleSceneView:getCurrentSceneView():setTopOffsetPos(ccp(0,0))

    --调试战斗的控制
    if isDebugBattle then
        GameClientGM:theClientGM():setTerrainDebug(true)
        BattleSceneView:getCurrentSceneView():initTerrainFlag()
    else
        GameClientGM:theClientGM():setTerrainDebug(false)
    end

    battleLuaValue.oneInit = false
    local width = scene:getWidth()
    local height = scene:getHeight()
    local mapScale = 640/width
    --BattleSceneView:getCurrentSceneView():setSceneScale(mapScale)
    
    doorAllHP = scene:getCityDoorHp()

    local towers = scene:getSceneTowersManual(BattleParty.kEnemyParty)
    towerAllHP = 0
    for k,v in pairs(towers) do
        local tower = v
        towerAllHP = towerAllHP + tower:getHpMax()
    end

    if battleLuaValue.isAutoBattle ~= true then
        BattleScene:getCurrentScene():setAutoBattle(false)
        BattleLuaScene:initBattleCfg()
        battleLuaValue.isAutoBattle = true

        BattleLuaScene:onClickNodeGate(0)  --控制是否开场就战斗
    end

    BattleLuaScene:createTroops()     --初始部队创建

    if BattleTrapData and battleLuaValue.battleMode == BattleMode.kBattlePVP then
        BattleTrapData:createTraps(BattleRealData.passId)        --初始化陷阱
    end

end

--创建部队
function BattleLuaScene:createTroops()
    if battleLuaValue.enemyDataIsArmy == true then
        BattleScene:getCurrentScene():createArmyTroop(BattleParty.kEnemyParty, 1, BattleToward.kLeftDown)
    else  
        if battleLuaValue.hadMakeTroopEnemy ~= true then
            if battleLuaValue.battleMode == BattleMode.kBattlePVP then
                BattleLuaScene:createEnemyNotMonsterTroop(1)
            end
            battleLuaValue.hadMakeTroopEnemy = true
        end
    end
    
    if battleLuaValue.playerDataIsArmy == true then
        BattleScene:getCurrentScene():createArmyTroop(BattleParty.kFriendParty, 0, BattleToward.kRightUp)
    else  
        if battleLuaValue.hadMakeTroopFriend ~= true then
            BattleLuaScene:createSelfTroopAll()
        end
    end
    
    --self:startUpdateHP()
end

--计算双方部队总血量
function BattleLuaScene:startUpdateHP()
    if BATTLE_CAL_MOD then return end
    battleLuaValue.friendsHp = BattleLuaScene:getTroopMaxHp(BattleParty.kFriendParty)
    battleLuaValue.friendsCurHp = battleLuaValue.friendsHp
   -- print("battleLuaValue.friendsHp",battleLuaValue.friendsHp)
    battleLuaValue.enemysHp = BattleLuaScene:getTroopMaxHp(BattleParty.kEnemyParty)
    battleLuaValue.enemysCurHp = battleLuaValue.enemysHp
   -- print("battleLuaValue.enemysHp",battleLuaValue.enemysHp)

    self.battleInfoMenu:updateHpBar(BattleParty.kFriendParty,battleLuaValue.friendsHp,battleLuaValue.friendsHp)
    self.battleInfoMenu:updateHpBar(BattleParty.kEnemyParty,battleLuaValue.enemysHp,battleLuaValue.enemysHp)


end

function BattleLuaScene:getTroopTotalHp(party)
    local hp = 0
    local mbs = BattleScene:getCurrentScene():getSceneMoveObj(party)
    for k,v in pairs(mbs) do
        hp = hp + v:getHp()
    end
    return hp
end

function BattleLuaScene:getTroopMaxHp(party)
    local hp = 0
    local troopInfo = {}
    if party == BattleParty.kFriendParty then
        troopInfo = friendTroopIdToInfo
    else
        -- if battlePassEnemyTroops then   --Pass模式下的血量计算
        --     --print("Pass模式下")
        --     --table.print(troopInfo)
        --     troopInfo = battlePassEnemyTroops
        --     for k,v in pairs(troopInfo) do
        --         hp = hp + BattleScene:getCurrentScene():getTroop(v):getTroopMaxHp()
        --     end
        --     return hp
        -- else
            troopInfo = enemyTroopIdToInfo
        -- end
    end
    for k,v in pairs(troopInfo) do
        hp = hp + BattleScene:getCurrentScene():getTroop(v.troopId):getTroopMaxHp()
    end
    return hp
end

--获取单个部队的血量
function BattleLuaScene:getTroopTotalHpById(party,troopId)
    local hp = 0
    local mbs = BattleScene:getCurrentScene():getSceneMoveObj(party)
    for k,v in pairs(mbs) do
        if v:getTroopId() == troopId then
            hp = hp + v:getHp()
        end
    end
    return hp
end
--获取单个部队的总血量
function BattleLuaScene:getTroopMaxHpById(party,troopId)
    local hp = 0
    hp = BattleScene:getCurrentScene():getTroop(troopId):getTroopMaxHp()
    return hp
end


--更新计算双方当前血量
function BattleLuaScene:updateTroopHpChange()
    if BATTLE_CAL_MOD then return end
    --通过GM指令开启血条显示
    local menuWidgets = self.battleInfoMenu.widgets
    if menuWidgets then
        if isShowBattleHp then
            menuWidgets.myHpBar:setVisible(true)
            menuWidgets.enemyHpBar:setVisible(true)
        else
            menuWidgets.myHpBar:setVisible(false)
            menuWidgets.enemyHpBar:setVisible(false)
            return
        end
    end
    local tmpFriendsHp = BattleLuaScene:getTroopMaxHp(BattleParty.kFriendParty)
    if tmpFriendsHp > battleLuaValue.friendsHp then
        battleLuaValue.friendsHp = tmpFriendsHp
    end
    battleLuaValue.friendsCurHp = BattleLuaScene:getTroopTotalHp(BattleParty.kFriendParty)

    local tmpEnemysHp = BattleLuaScene:getTroopMaxHp(BattleParty.kEnemyParty)
    if tmpEnemysHp > battleLuaValue.enemysHp then
        battleLuaValue.enemysHp = tmpEnemysHp
    end
    battleLuaValue.enemysCurHp = BattleLuaScene:getTroopTotalHp(BattleParty.kEnemyParty)


    self.battleInfoMenu:updateHpBar(BattleParty.kFriendParty,battleLuaValue.friendsCurHp,battleLuaValue.friendsHp)
    self.battleInfoMenu:updateHpBar(BattleParty.kEnemyParty,battleLuaValue.enemysCurHp,battleLuaValue.enemysHp)


end
--获取部队总兵力
function BattleLuaScene:getTotalSoldierNum(party)
    local num = 0
    if party == BattleParty.kFriendParty then
        for k,v in pairs(friendTroopIdToInfo) do
            num = num + v["oldNum"]
        end
    elseif party == BattleParty.kEnemyParty then
        for k,v in pairs(enemyTroopIdToInfo) do
            num = num + v["oldNum"]
        end
    end
    return num
end

--获取部队剩余兵力
function BattleLuaScene:getLastSoldierNum(party)
    local num = 0
    --table.print(friendTroopIdToInfo)
    if party == BattleParty.kFriendParty then
        for k,v in pairs(friendTroopIdToInfo) do
            local lastNum = v.oldNum - v.deadSoldier
            num = num + lastNum
        end
    elseif party == BattleParty.kEnemyParty then
        for k,v in pairs(enemyTroopIdToInfo) do
            local lastNum = v.oldNum - v.deadSoldier
            num = num + lastNum
        end
    end
    return num
end

--获取受伤士兵数目
function BattleLuaScene:getHurtSoldierNum(party)
    local num = 0
    --table.print(friendTroopIdToInfo)
    if party == BattleParty.kFriendParty then
        for k,v in pairs(friendTroopIdToInfo) do
            num = num + v.hurtSoldier
        end
    elseif party == BattleParty.kEnemyParty then
        for k,v in pairs(enemyTroopIdToInfo) do
            num = num + v.hurtSoldier
        end
    end
    return num

end

--获取随机种子
function BattleLuaScene:getRandomSeed()
    if BattleRealData.seed then
        return BattleRealData.seed
    else
        return 1
    end
end
--保存随机种子-回放文件
function BattleLuaScene:saveRandomSeed()
    return BattleSceneView:getCurrentSceneView():getRandomSeed()
end

function BattleLuaScene:addSoldierDeadMsg(soldierTid,isMonster)
    if BATTLE_CAL_MOD then return end
    -- if self.deadPanel then
    --     self.deadPanel:removeFromParent(true)
    -- end
    local soldierName = ""
    if isMonster then
        soldierName = TextConfig[MonsterSoldierConfig[soldierTid].name_id].content
    else
        if SoldierConfig[soldierTid] then
            soldierName = TextConfig[SoldierConfig[soldierTid].name_id].content
        else  --我方的配置部队
            soldierName = TextConfig[MonsterSoldierConfig[soldierTid].name_id].content
        end
    end
    local deadPanel = require("ui.battle.BattleSoldierDeadMsgPanel").new(soldierName)
    local mainScene = tolua.cast(MainScene:theScene(),"cc.Scene")
    mainScene:addChild(deadPanel, 100);

end
