﻿#include "util/ActivityUtil.h"

#include "CCLuaEngine.h"
#include "lua/LuaWrapper.h"
#include "base/EventDispatcher.h"
#include "battle/BattleHurt.h"
#include "base/logger.h"
#include "util/MathUtil.h"
#include "util/PropUtil.h"
#include "battle/BattleReport.h"
#include "battle/buff/BuffMgr.h"
#include "model/GameClientGM.h"

#include "configure/SoldierConfigure.h"

#include "configure/MonsterSoldierConfigure.h"
#include "battle/buff/BuffMgrHelper.inl"
#include "cocos2d.h"
#include "util/LuaLogicUtil.h"
#include "model/GameSoldier.h"
#if (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
#include "battleHttpNode/http_handler.h"
#include "battleHttpNode/xy_btl_app.h"
#endif
#if CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID
#include "platform/android/jni/JniHelper.h"
#include "android/JniUtil.h"
#define CLASS_NAME "com/xuanyi/yxwd/InteractiveBridge"
#endif
using namespace std;
using namespace cocos2d;

LuaCHelper::LuaCHelper()
{

}
LuaCHelper::~LuaCHelper()
{

}

void LuaCHelper::luaCAssert()
{
	assert(false);
}

void LuaCHelper::crashC()
{
	int *p = NULL;
	*p = 1;
}
void LuaCHelper::pushNotificationFromCpp(std::string title, std::string msg, std::string ext)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo t;
	if (JniHelper::getStaticMethodInfo(t, "com/xuanyi/yxwd/InteractiveBridge", "pushNotificationFromCpp", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"))
	{
		jstring jstrData1 = t.env->NewStringUTF(title.c_str());
		jstring jstrData2 = t.env->NewStringUTF(msg.c_str());
		jstring jstrData3 = t.env->NewStringUTF(ext.c_str());
		t.env->CallStaticVoidMethod(t.classID, t.methodID, jstrData1, jstrData2, jstrData3);

		t.env->DeleteLocalRef(jstrData1);
		t.env->DeleteLocalRef(jstrData2);
		t.env->DeleteLocalRef(jstrData3);
		t.env->DeleteLocalRef(t.classID);

		return;
	}
#endif
}
void LuaCHelper::pushNotificationFromCppOnceLater(std::string title, std::string msg, std::string ext, std::string delaySecond)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo t;
	if (JniHelper::getStaticMethodInfo(t, "com/xuanyi/yxwd/InteractiveBridge", "pushNotificationFromCppOnceLater", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"))
	{
		jstring jstrData1 = t.env->NewStringUTF(title.c_str());
		jstring jstrData2 = t.env->NewStringUTF(msg.c_str());
		jstring jstrData3 = t.env->NewStringUTF(ext.c_str());
		jstring jstrData4 = t.env->NewStringUTF(delaySecond.c_str());
		t.env->CallStaticVoidMethod(t.classID, t.methodID, jstrData1, jstrData2, jstrData3, jstrData4);

		t.env->DeleteLocalRef(jstrData1);
		t.env->DeleteLocalRef(jstrData2);
		t.env->DeleteLocalRef(jstrData3);
		t.env->DeleteLocalRef(jstrData4);
		t.env->DeleteLocalRef(t.classID);

		return;
	}
#endif
}
void LuaCHelper::pushNotificationRepeatEveryDay(std::string title, std::string msg, std::string ext, std::string hour, std::string minutes, std::string second)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo t;
	if (JniHelper::getStaticMethodInfo(t, "com/xuanyi/yxwd/InteractiveBridge", "pushNotificationFromCppOnceLater", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"))
	{
		jstring jstrData1 = t.env->NewStringUTF(title.c_str());
		jstring jstrData2 = t.env->NewStringUTF(msg.c_str());
		jstring jstrData3 = t.env->NewStringUTF(ext.c_str());
		jstring jstrData4 = t.env->NewStringUTF(hour.c_str());
		jstring jstrData5 = t.env->NewStringUTF(minutes.c_str());
		jstring jstrData6 = t.env->NewStringUTF(second.c_str());
		t.env->CallStaticVoidMethod(t.classID, t.methodID, jstrData1, jstrData2, jstrData3, jstrData4, jstrData5, jstrData6);

		t.env->DeleteLocalRef(jstrData1);
		t.env->DeleteLocalRef(jstrData2);
		t.env->DeleteLocalRef(jstrData3);
		t.env->DeleteLocalRef(jstrData4);
		t.env->DeleteLocalRef(jstrData5);
		t.env->DeleteLocalRef(jstrData6);
		t.env->DeleteLocalRef(t.classID);

		return;
	}
#endif
}
void LuaCHelper::cancelAllLocalNotificationsFromCpp()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	JniMethodInfo t;
	if (JniHelper::getStaticMethodInfo(t, "com/xuanyi/yxwd/InteractiveBridge", "cancelAllLocalNotificationsFromCpp", "()V"))
	{
		t.env->CallStaticVoidMethod(t.classID, t.methodID);
		t.env->DeleteLocalRef(t.classID);

		return;
	}
#endif
}
void LuaCHelper::runLog(const char *log)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
	RUNLOG(TLogLevel_Info, TLogID_PrintInfo, log);
#endif
}
LuaLogicVariable::LuaLogicVariable()
	: m_initPropTid(-1)
	, m_initPropType(-1)
	, m_propSoliderNum(0)
	, m_initPropModel(nullptr)
	, m_isDebugMo(false)
{

}

void LuaLogicVariable::addFriendSoldierId(int id)
{
	auto iter = m_friendSoldierIds.find(id);
	if (iter == m_friendSoldierIds.end())
	{
		m_friendSoldierIds.insert(make_pair(id, id));
	}
}
void LuaLogicVariable::addEnemySoldierId(int id)
{
	auto iter = m_enemySoldierIds.find(id);
	if (iter == m_enemySoldierIds.end())
	{
		m_enemySoldierIds.insert(make_pair(id, id));
	}
}

std::map<int, int> LuaLogicVariable::getFriendSoldierIds()
{
	return m_friendSoldierIds;
}

std::map<int, int> LuaLogicVariable::getEnemySoldierIds()
{
	return m_enemySoldierIds;
}


LuaLogicVariable::~LuaLogicVariable()
{

}

bool LuaLogicVariable::respHeadHttpData()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
	HttpDataMgr::getInstance()->responseHttpData();
	return true;
#else
	assert(false);
	return false;
#endif
}

bool LuaLogicVariable::popHeadHttpData()
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_LINUX)
	std::mutex * lockData = HttpDataMgr::getInstance()->getMutex();
	lockData->lock();
	cocos2d::Vector<HttpDataInfo*>& dataVec = HttpDataMgr::getInstance()->getDataVector();
	if (dataVec.size() > 0)
	{
		ERROR_MSG("HTTP DATA SIZE IS  --   %d", dataVec.size());
		HttpDataInfo* info = *(dataVec.begin());
		char* oriHttpBuf = info->getCBuf();
		int oriBufLenth = info->getBufLenth();
		char* calDataBuf = oriHttpBuf + 8; //去除多余的协议头数据
		int calDataLenth = oriBufLenth - 8;//减去对应协议头长度
		LuaLogicVariable::theMgr()->setBattlecalData(calDataBuf);
		LuaLogicVariable::theMgr()->setBattlecalDataLen(calDataLenth);
		lockData->unlock();
		return true;
	}
	lockData->unlock();
	return false;
#else
	assert(false);
	return false;
#endif
}

CalcHurtDamage LuaLogicVariable::getHurtDamage()
{
	return m_calcHurtDamage;
}

void LuaLogicVariable::setHurtDamage(CalcHurtDamage newhurt)
{
	m_calcHurtDamage = newhurt;
	m_initPropModel = nullptr;
}

std::vector<int> LuaLogicVariable::getInitProp()
{
	return m_initPropByLua;
}

void LuaLogicVariable::setInitProp(std::vector<int> value)
{
	m_initPropByLua = value;
}



void LuaLogicVariable::clearHurt()
{
	m_calcHurtDamage.physicPercent = 0.0f;
	m_calcHurtDamage.magicPercent = 0.0f;
	m_calcHurtDamage.totalDamage = 0.0f;
	m_calcHurtDamage.bouncePhysicDmg = 0.0f;
	m_calcHurtDamage.bounceMagicDmg = 0.0f;
	m_calcHurtDamage.bounceAbsoluteDamage = 0.0f;
}

void LuaLogicVariable::clearInitProp()
{
	m_initPropByLua.clear();
	m_initPropModel = nullptr;
	m_initPropTid = -1;
	m_initPropType = -1;
}

namespace LuaLogicUtil
{
	float moveObjUpdateBylua(int objId, float dt)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<float>(L, "battle_cfg", "moveObjUpdateBylua", "if", objId, dt);
	}

	int startBattleThread()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		int retValue = LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "battleThread", "", nullptr);
		return retValue;
	}

	int startNetMessageThread()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		int retValue = LuaWrapper::callFuncInLua<int>(L, "netmessage_cfg", "netmessageThread", "", nullptr);
		return retValue;
	}

	void sendWildEvent()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "wild_cfg", "sendWildEvent", "", nullptr);
	}

	void callBattleCalculat(char * msgPack, int lenth)
	{
	    lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
	    LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "callBattleCalculat", "l", msgPack, lenth);
	}

	float battleUpdateForlua(float dt)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<float>(L, "battle_cfg", "callGameUpdate", "f", dt);
	}

	bool isBattleVictory()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<bool>(L, "BattleLuaScene", "isBattleVictory", "", nullptr);
	}

	void armySoldierHpChange(const char *playerId, int match, int changeNum)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "armySoldierHpChange", "sii", playerId,match,changeNum);
	}

	bool initBattleobjPropByLua(const std::vector<int> prop)
	{		
		LuaLogicVariable::theMgr()->setInitProp(prop);
	    lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		bool retValue = LuaWrapper::callFuncInLua<bool>(L, "battle_cfg", "initBattleobjPropByLua", "", nullptr);
		return retValue;
	}

	bool initBattleBuildingPropByLua()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		bool retValue = LuaWrapper::callFuncInLua<bool>(L, "battle_cfg", "initBattleBuildingPropByLua", "", nullptr);
		return retValue;
	}

	int initStaticObjectByLua(int oldTid)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		int retValue = LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "initStaticObjectByLua", "i", oldTid);
		return retValue;
	}

	int getBuildingTypeByLua(int tid)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		int retValue = LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "getBuildingTypeByLua", "i", tid);
		return retValue;
	}

	int getTrapTidFromLuaWithPosTid(int tid)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		int retValue = LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "getTrapTidFromLuaWithPosTid", "i", tid);
		return retValue;
	}
	const char* textContent(int id)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		const char* retValue = LuaWrapper::callFuncInLua<const char*>(L, "textConfigCom", "content", "i", id);
		return retValue;
	}
	const char* stringValue(const char* key)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		const char* retValue = LuaWrapper::callFuncInLua<const char*>(L, "stringConfigCom", "content", "s", key);
		return retValue;
	}

	void onInitFinish()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<void>(L, "BattleLuaScene", "onInitFinish", "", nullptr);
	}

	bool isBattleFail()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<bool>(L, "BattleLuaScene", "isBattleFail", "", nullptr);
	}

	void dealBattleFinished(bool isWin)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "callDealBattleFinished", "b", isWin);
	}

	void onBattleTimeChanged(float nowBattleTime)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "onBattleTimeChanged", "f", nowBattleTime);
	}

	void addSoldierDeadMsg(int soldierTid, bool isMonster)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "addSoldierDeadMsg", "ib", soldierTid,isMonster);
	}

	void onBattleSceneExit()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "onBattleSceneExit", "", nullptr);
	}

	void reInitBattleData()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "BattleLuaScene", "reInitBattleData", "", nullptr);
	}

	void onCreateTroop(int party, int troopId, bool isMonster, int soldierTid, int num)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "onCreateTroop", "iibii", party, troopId, isMonster, soldierTid, num);
	}

	void onTroopHpChange(int party, int troopId, int num)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "onTroopHpChange", "iii", party, troopId, num);
	}

	void onClickNodeGate(int index)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "onClickNodeGate", "i", index);
	}

	int doBuildingLuaAction(int id, int targetId)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "doBuildingLuaAction", "ii", id, targetId);
	}

	int canTrapTrigger(int tId)
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "canTrapTrigger", "i", tId);
	}

	int getTowerDefence()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "battle_cfg", "getTowerDefence", "", nullptr);
	}

	int getWallDefence()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getWallDefence", "", nullptr);
	}

	int getWallLife()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getWallLife", "", nullptr);
	}

	int getWallArmor()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getWallArmor", "", nullptr);
	}

	int getTowerAtk()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getTowerAtk", "", nullptr);
	}

	int getTowerLife()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getTowerLife", "", nullptr);
	}

	int getTowerArmor()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getTowerArmor", "", nullptr);
	}

	int getRandomSeed()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getRandomSeed", "", nullptr);
	}

	void callLuaCalcHurt()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		LuaWrapper::callFuncInLua<void>(L, "battle_cfg", "doLuaCalcHurt", "", nullptr);
	}

	int getNeedCreateTroopSoldiers()
	{
		lua_State *L = cocos2d::LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
		return LuaWrapper::callFuncInLua<int>(L, "BattleLuaScene", "getNeedCreateTroopSoldiers", "", nullptr);
	}

	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{

	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{

	}

	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		calcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
	}

	// ----------------------------------------------------------------

	// \CF\C2\C3溯\CA\FDֻ\CA\C7Ϊ\C1\CBgenSkillBattleReport()ģ\BF\E9չ\BF\AA\C4\DCͨ\B9\FD\A3\ACĿǰ\CE\DE\C6\E4\CB\FB\D3ô\A6(a bit ugly)
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleBuilding *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{

	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{

	}
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleBuilding *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{

	}
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		doCalcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
		LuaLogicVariable::theMgr()->setHurtDamage(*damage);
		callLuaCalcHurt();
		(*damage) = LuaLogicVariable::theMgr()->getHurtDamage();
		LuaLogicVariable::theMgr()->clearHurt();
	}
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		doCalcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
		LuaLogicVariable::theMgr()->setHurtDamage(*damage);
		callLuaCalcHurt();
		(*damage) = LuaLogicVariable::theMgr()->getHurtDamage();
		LuaLogicVariable::theMgr()->clearHurt();
	}
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		doCalcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
		LuaLogicVariable::theMgr()->setHurtDamage(*damage);
		callLuaCalcHurt();
		(*damage) = LuaLogicVariable::theMgr()->getHurtDamage();
		LuaLogicVariable::theMgr()->clearHurt();
	}
};
