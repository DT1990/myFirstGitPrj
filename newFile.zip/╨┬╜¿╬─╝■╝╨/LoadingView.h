﻿#ifndef LOADING_VIEW_H__
#define LOADING_VIEW_H__

#include "cocos2d.h"
#include "ui/UILayout.h"
#include "ui/UILoadingBar.h"
#include "ui/UIText.h"
#include "ui/UILoadingBar.h"

namespace xyui
{
	class Layout;
	class Bar;
}

namespace spine
{
	class SkeletonAnimation;
}

class ActionRunner;

class LoadingView : public cocos2d::Node
{
public:
	enum
	{
		kBattleBegin,
		kBattleEnd,
	};
public:
	static LoadingView *create(int touchPriority, int type);

	virtual void onEnter();
	virtual void onExit();
	virtual bool ccTouchBegan(cocos2d::CCTouch *pTouch, cocos2d::CCEvent *pEvent) { return true; }
	virtual bool init();

	void loadBattleRes(int sceneId);
	void loadMainSceneRes();

	void setProgressPercentage(float percent, bool isUpdateTip = true);
	void setTip(const char *text);
	
	void setHandler(std::function<void ()> func) { m_func = func; }

	void loadingCallBack(int num = 1,bool isPreCalLoad = false);
private:
	LoadingView(int touchPriority, int type);
	~LoadingView();

	void runFinishedAction();
	void remove();
	void generalCard();

private:
	int m_touchPriority;
	int m_type;
	xyui::Layout *m_layout;
	xyui::Bar *m_bar;
	int m_loadedResNum;
	int m_totalResNum;
	int m_pureResNum;
	ActionRunner *m_runner;

	std::function<void ()> m_func;
	spine::SkeletonAnimation *m_cloud1;
	spine::SkeletonAnimation *m_cloud2;

	cocos2d::ui::Text *m_tipLabel;
	cocos2d::ui::Text *m_loadingLabel;
	cocos2d::ui::LoadingBar *m_loadingBar;

public:
	CC_SYNTHESIZE(int, m_curPreCalNum, CurPreCalNum);
	CC_SYNTHESIZE(int, m_preCalNum, PreCalNum);
	static const int kPreCalNum = 6000;
};

#endif