﻿#include "BattleSceneView.h"
#include <tuple>
#include <climits>
//#include "net/NetworkHandler.h"
#include "protocol/mh_const.h"
#include "base/logger.h"
#include "base/ZOrder.h"
#include "base/UIColor.h"
#include "base/TouchPriority.h"
#include "base/EventDispatcher.h"
#include "base/InternalEvent.h"
#include "battle/BattleReport.h"
#include "battle/BattleScene.h"
#include "battle/GenGeneralPoint.h"
#include "battle/BattleObjectSkill.h"
#include "battle/HitRange.h"
#include "battle/formation/BattleGroup.h"
#include "util/view_util.h"
#include "util/GridUtil.h"
#include "util/str_util.h"
#include "util/MathUtil.h"
#include "util/SystemCfgUtil.h"
#include "util/MathUtil.h"
#include "util/SkillEffectDisplay.h"
#include "util/Shake.h"
#include "util/SkillVariableUtil.h"
#include "util/IntervalAnimationDisplayNode.h"
#include "util/gesture/GeometricRecognizer.h"
#include "util/BattlePveUtil.h"
#include "util/EffectDisplay.h"
#include "util/ShockWaveEffect.h"
#include "util/KeyboardUtil.h"
#include "util/BattlePveUtil.h"
#include "util/ConfigureUtil.h"
#include "util/ShadowMaker.h"
#include "util/AntiSpeedAbnormal.h"
#include "util/CrusadeUtil.h"
#include "util/AttackPropUtil.h"
#include "battle/BattleSkill.h"
#include "battle/BattleBuilding.h"
#include "battle/BattleTower.h"
#include "battle/buff/BuffMgr.h"
#include "battle/troop/BattleTroop.h"
#include "battle/formation/BattleFormation.h"
#include "model/GamePvp.h"
#include "model/GameGeneral.h"
#include "model/GameGeneralManager.h"
#include "model/GameClientGM.h"
#include "model/GamePlayer.h"
#include "model/GameMetric.h"

#include "model/ResourceModel.h"
#include "model/GameFunctionManager.h"
#include "view/SceneLayer.h"
#include "view/MainScene.h"
#include "view/BattleMoveObjectView.h"
#include "view/BattleStaticObjectView.h"
#include "view/BattleObjectView.h"
#include "view/BattleTinyMap.h"
#include "view/BattleBossInfo.h"
#include "view/BattleResourcePickUpLayer.h"
#include "view/BattleVictorySelectCardLayer.h"
#include "view/BattleDropOutLayer.h"
#include "view/LoadingView.h"
#include "ui/PassInfoPanel.h"

/*#include "ui/BattleResultPanel/BattleFailArenaPanel.h"
#include "ui/BattleResultPanel/BattleVictoryDungeonResourcePanel.h"
#include "ui/BattleResultPanel/BattleVictoryDungeonRewardPanel.h"
#include "ui/BattleResultPanel/BattleVictoryDungeonEquipmentPanel.h"
#include "ui/BattleResultPanel/BattleVictoryArenaPanel.h"

#include "ui/BattleResultPanel/BattleVictoryCrusadePanel.h"
#include "ui/BattleResultPanel/BattleFailCrusadePanel.h"
#include "ui/BattleResultPanel/BattleVictorySpecialCrusadePanel.h"

#include "ui/NoTouchLayer.h"
#include "ui/TextHint.h"
#include "plot/PlotSceneView.h"
#include "plot/Plot.h"*/
#include "recycle/RecycleMgr.h"
#include "audio/AudioMgr.h"
#include "IAudio.h"
#include "CommonUI/Image.h"
#include "CommonUI/Button.h"
#include "CommonUI/Lighting.h"
#include "widget/BulletEffect.h"
#include "widget/LightningChain.h"
#include "widget/CCBullet.h"
#include "CommonUI/Layout.h"

#include "ui/UILayout.h"
#include "ui/UIText.h"
#include "util/CustomEffect.h"
#include "util/LuaLogicUtil.h"
#include "configure/PassConfigure.h"

#include "configure/BattleParaConfigure.h"
#include "configure/SoldierConfigure.h"

#include "configure/PassBuildingConfigure.h"
#include "configure/PassTowerConfigure.h"

#include "configure/SkillConfigure.h"
#include "configure/SkillGroupConfigure.h"
#include "configure/SkillLogicConfigure.h"
#include "configure/StringConfigure.h"
#include "configure/PassConfigure.h"
#include "configure/DefaultValueConfigure.h"

#include "configure/PassBuildingConfigure.h"
#include "configure/PassTowerConfigure.h"
#include "configure/SystemConfigure.h"
#include "configure/MonsterSoldierConfigure.h"
#include "configure/PassConfigure.h"
#include "configure/PassSpecialCaseConfigure.h"
#include "configure/SoldierCommonConfigure.h"
#include "configure/BattleParaConfigure.h"
#include "configure/TextConfigure.h"
#include "xmlconfig/BattleSceneConfigure.h"
#include "xmlconfig/SkillEffectConfigure.h"
#include "replay/ReplayRecorder.h"
#include "replay/ReplayPlayer.h"
#include "util/ActionUtil.h"
#include "util/StarEvaluateUtil.h"
#include "util/BattleParaCfgUtil.h"
#include "battle/skill/ChainDamageMgr.h"
#include "battle/BattlePvp.h"
#include "battle/BattleTrap.h"

#include "util/AutoRunPass.h"


using namespace cocos2d;
using namespace std::placeholders;

static int g_tagBossStageChangeBkgMask = 100;
static const float kPlayTroopAtmosphereSoundTime = 4.0f;
static const float kKeyoffTroopAtmosphereSoundTime = 3.0f;
static const int kMoveTag = 1000;

BattleSceneView *BattleSceneView::s_curSceneView = nullptr;

static void handleFxBuff(BattleObject *attacker, int skillLvId, const std::set<uint16_t> &targets, bool isCalcHurt = true)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	if(!targets.empty())
	{
        int skillGroupId = skill::getSkillId(skillLvId);
        
		switch(scene->getObjectType(attacker->getId()))
		{
		case BattleScene::kMoveObj:
			{
				BattleMoveObject *moveObjAttacker = dynamic_cast<BattleMoveObject *>(attacker);
				if(isCalcHurt)
				{
					if(SKILLLOGIC_HAS_BUFF1(skillGroupId))
					{
						moveObjAttacker->setBuffObjects(targets);
					}
				}
				else
				{
					skill::doBuff(scene, attacker, targets, skillLvId, TargetSelect::kTargetOpponent);
				}
				
				skill::doSelfFx(BattleScene::kMoveObj, moveObjAttacker, nullptr, nullptr, skillLvId);
				skill::doNormalFx(scene, moveObjAttacker, targets, skillLvId, TargetSelect::kTargetOpponent);
				break;
			}
		case BattleScene::kTower:
			{
				BattleTower *towerAttacker = dynamic_cast<BattleTower *>(attacker);
				if(isCalcHurt)
				{
					if(SKILLLOGIC_HAS_BUFF1(skillGroupId))
					{
						towerAttacker->setBuffObjects(targets);
					}
				}
				else
				{
					skill::doBuff(scene, attacker, targets, skillLvId, TargetSelect::kTargetOpponent);
				}
				
				skill::doSelfFx(BattleScene::kTower, nullptr, towerAttacker, nullptr, skillLvId);
				skill::doNormalFx(scene, towerAttacker, targets, skillLvId, TargetSelect::kTargetOpponent);
				break;
			}
		case BattleScene::kBuilding:
		{
			BattleTrap *buildingAttacker = dynamic_cast<BattleTrap *>(attacker);
			if (isCalcHurt)
			{
				if (SKILLLOGIC_HAS_BUFF1(skillGroupId))
				{
					buildingAttacker->setBuffObjects(targets);
				}
			}
			else
			{
				skill::doBuff(scene, attacker, targets, skillLvId, TargetSelect::kTargetOpponent);
			}

			skill::doSelfFx(BattleScene::kTower, nullptr, nullptr, buildingAttacker, skillLvId);
			skill::doNormalFx(scene, buildingAttacker, targets, skillLvId, TargetSelect::kTargetOpponent);
			break;
		}
		default:
			break;
		}
	}
}

static cocos2d::CCPoint calcDestPixelPosition(const cocos2d::CCPoint &attackerGridPos, const cocos2d::CCPoint &targetGridPos, float angle, float maxLength)
{
	cocos2d::CCPoint destGridPos = ccpRotateByAngle(targetGridPos, attackerGridPos, angle);
	if(maxLength > FLT_EPSILON)
	{
		cocos2d::CCPoint offset = ccpMult(ccpNormalize(ccpSub(destGridPos, attackerGridPos)), maxLength);
		destGridPos = ccpAdd(attackerGridPos, offset);
	}

	PixelPoint dest = GridUtil::sharedGridUtil().floatGridToPix(destGridPos.x, destGridPos.y);
	return ccp(dest.x, dest.y);
}

void BattleSceneView::onSpeakDialogEnd(const skill::SkillResult &sr, const skill::SpecialFxData &data, uint16_t attackerId, const SkillInfo &skillInfo, bool isUseSuccess, SpeakType speakType, int speakTextId, float speakLastTime)
{
	if (m_isWatingForSpeakDialogEnd)
	{
		/*CCCallFuncND *useSkillAction = CCCallFuncND::create(this, [=](void) ->void
		{
			if (nullptr != getMoveObjectView(attackerId))
			{
				if (isUseSuccess) useSkill(sr, data, attackerId, skillInfo, false);
			}		
		});

		CCCallFuncND *resumeScenceAction = CCCallFuncND::create(this, [=](void) ->void
		{
			BattleScene::getCurrentScene()->resume();
			m_map->removeChildByTag(skill::kShapeChangeNoTouchTag);
			getMenu()->enable();
			m_shouldReorder = true;
			m_isBattleSkillProcessing = false;
		});


		CCCallFuncND *focusToHitPosAction = CCCallFuncND::create(this, [=](void) ->void
		{
			focusTo(ccp(sr.hitPos.x,sr.hitPos.y));
		});
		CCArray* arrayOfActions = CCArray::create();
		arrayOfActions->addObject(useSkillAction);	
		arrayOfActions->addObject(focusToHitPosAction);	
		arrayOfActions->addObject(resumeScenceAction);
		CCSequence* seq = CCSequence::create(arrayOfActions);	
		runAction(seq);
		EventDispatcherXY::sharedDispatcher().removeListener(kInternalCmdGeneralSpeakDialogEnded, m_speakDialogEndId);
		m_isWatingForSpeakDialogEnd = false;
		m_speakDialogEndId = -1;*/
	}
}

BattleSceneView::BattleSceneView(BattleScene *model) 
	: m_model(model)
	, m_map(nullptr)
	, m_counter(0)
	, m_isSendedResult(false)
	, m_lastBoss(nullptr)
	, m_victoryPanel(nullptr)
	, m_failedPanel(nullptr)
	, m_mapScale(1.0f)
	, m_shouldReorder(true)
	, m_isTouch(false)
	, m_isShaking(false)
	, m_isBattleSkillProcessing(false)
	, m_curTime(0.0f)
	, m_scrollSpeed(ccp(0, 0))
	, m_isScrolling(false)
	, m_dungeonResBossBarrackslostHp(0)
	, m_dungeonResBossBarracksMaxHp(0)
	, m_isBossStageChangedBegin(false)
	, m_isBossStageChangedEnd(false)
	, m_isExitPanelDiaplay(false)
	, m_isBattleCountdownStarted(false)
	, m_enemeyTroopWaveNum(0)
	, m_toAddRes(0.0f)
	, m_isLockScreen(false)
	, m_isThreeStars(false)
	, m_isWatingForSpeakDialogEnd(false)
	, m_speakDialogEndId(-1)
	, m_plotSceneView(nullptr)
	, m_SingleClickAttackerId(0)
	, m_addBlackLayerObjId(0)
	, m_nowBattleStarInfo(0)
	, m_isNewPass(false)
	, m_sound(nullptr)
	, m_playTroopAtmosphereSoundTime(0.0f)
	, m_keyOffTroopAtmosphereSoundTime(0.0f)
	, m_specialCrusadeDamageClass(-1)
	, m_turnDownAmbientMusicVolumeTime(0.0f)
	, m_isAmbientMusicVolumeTurnUping(false)
	, m_turnUpVolumeElaspedTime(0.0f)
	, m_flag(nullptr)
	, m_bottomOffsetPos(0.0f, 0.0f)
	, m_topOffsetPos(0.0f, 0.0f)
	, m_randSeed(1)
	, m_isBattleResult(false)
	, m_isWin(false)
	, m_battleSceneCameraState(kBSCTInit)
	, m_isPlaying(false)
{
	m_model->retain();
	m_model->addView(this);	

	m_map = SceneLayer::create(m_model->getId());
	m_map->setAnchorPoint(ccp(0, 0));
	m_map->setPosition(ccp(0, 0));
	addChild(m_map, 0);
    
    m_hpChangedValue = Node::create();
    m_hpChangedValue->ignoreAnchorPointForPosition(true);
    addChild(m_hpChangedValue, 1);

	setContentSize(m_map->getContentSize());

	setScale(PASS_SCALE(MainScene::theScene()->getCurPassId()));

	const BattleSceneProperty &ptyScene = getBattleScene(m_model->getId());
	const BattleMapProperty &pty = getBattleMap(ptyScene.mapId);
	focusTo(pty.focus_point);

	scheduleUpdate();
	/*
	if (Director::getInstance()->getIsReply())
	{
		Director::getInstance()->setRandSeed(LuaLogicUtil::getRandomSeed());
		srand(LuaLogicUtil::getRandomSeed());
	}
	else
	{
		int rand = (int)time(nullptr);
		srand(rand);
		m_randSeed = rand;
		//replay::ReplayRecorder::theRecorder()->initSrand(rand);
	}*/
	Director::getInstance()->setRandSeed(100);
	srand(100);		//测试种子同步情况


	CCPoint scenePos = getPosition();
	//bool isMoveAlongRoad = (PASS_MOVE_ALONG_ROAD(m_model->getId()) == 1);		// 地图地否沿着地图中道路移动;
	//if (isMoveAlongRoad)
	//{
	//	scenePos.y = calcBattleMapPosY(scenePos.x);
	//}
	//else
	//{
	//	float moveLimit = static_cast<float>(PASS_MOVE_LIMIT(m_model->getId()));
	//	scenePos = calcbattleMapPos(scenePos, moveLimit);
	//}
	setPosition(scenePos);

	schedule(schedule_selector(BattleSceneView::updateCustom));			

	if (GameClientGM::theClientGM()->isTerrainDebug() && Director::getInstance()->getIsRender())
	{
		initTerrainFlag();
	}
}

BattleSceneView::~BattleSceneView()
{
	if (m_speakDialogEndId > 0)
	{
		EventDispatcherXY::sharedDispatcher().removeListener(kInternalCmdGeneralSpeakDialogEnded, m_speakDialogEndId);
	}

	m_model->removeView(this);
	m_model->onExit();
	m_model->release();

	s_curSceneView = nullptr;
	
	if (m_plotSceneView)
	{
		//m_plotSceneView->removeFromParent();
		m_plotSceneView = nullptr;
	}

	unschedule(schedule_selector(BattleSceneView::updateCustom));			
}

void BattleSceneView::showFlag()
{
	/*BattleFormation *bf = m_model->getFormation(kFriendParty);
	uint16_t centerId = bf->getCenterId();
	if ( centerId== 0)
	{
		return;
	}
	removeFlag();
	BattleObjectView *centerMember = getObjectView(centerId);
	m_flag = IntervalAnimationDisplayNode::create("res/effects/flag");
	m_flag->setAnchorPoint(ccp(0.0f, 0.0f));
	m_flag->setPosition(ccp(0.0f,0.0f));
	centerMember->addChild(m_flag);*/

}

void BattleSceneView::removeFlag()
{
	if (m_flag)
	{
		m_flag->removeFromParentAndCleanup(true);
		m_flag = nullptr;
	}
}

void BattleSceneView::showHideFlag(bool isShow)
{
	if (isShow)
	{
		showFlag();
	}
	else
	{
		removeFlag();
	}
}
void BattleSceneView::onEnter()
{
	Node::onEnter();
	////CCDirector::sharedDirector()->getTouchDispatcher()->addTargetedDelegate(this, kTouchPriority_SceneLayer, true);
	//m_showHideFlagId = EventDispatcherXY::sharedDispatcher().addListener(kInternalCmdShowHideFlag,
		//std::bind(&BattleSceneView::showHideFlag,this,_1,_2,_3));
	/*const char *res = PASS_MUSIC(MainScene::theScene()->getCurPassId());
	if(strcmp(res, "") != 0)
	{
		IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
		if (audioEx)
		{
			audioEx->playMusic(res);
		}
	}*/

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
	//记录“自动跑关卡”战斗开始信息。战斗结束的信息在dealBattleFinished中
	if(GameClientGM::theClientGM()->isGMAutoRunPass())
	{
		AutoRunPass* runner = AutoRunPass::theAutoRunner();
		runner->recordBattleBegin();
	}
#endif
}

void BattleSceneView::onExit()
{
	setAmbientMusicVolume(1.0f);
	stopAllSoundAndMusic();
	IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
	if (audioEx)
	{
		audioEx->playMusic("music/music/BLCX-city");
		audioEx->setMusicVolume(1.0f);
	}	
	
	/*if(m_showHideFlagId  > 0 )
	{
	EventDispatcherXY::sharedDispatcher().removeListener(kInternalCmdShowHideFlag, m_showHideFlagId);
	}*/

	////CCDirector::sharedDirector()->getTouchDispatcher()->removeDelegate(this);
	unscheduleUpdate();
	Node::onExit();

	CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
	GameClientGM::theClientGM()->setGMAutoRunPass(false);
#endif
}

void BattleSceneView::stopAllSoundAndMusic()
{
	IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
	if (audioEx)
	{
		audioEx->stopAmbient(true);
		audioEx->stopMusic(true);
	}
	
	freeSound();
}

void BattleSceneView::updateCurrentNodeGateState()
{
	if(isInThisBattleMode(MainScene::kBattleArena)) return;
	IntervalAnimationDisplayNode *nodeGate = m_map->getCurrentNodeGate();
	if(!nodeGate) return;

	nodeGate->setHalo(m_model->canOpenCurrentNodeGate());
}

void BattleSceneView::update(float delta)
{
	++m_counter;
	if (m_counter > 10 && m_shouldReorder)
	{
		reOrder();
		m_counter = 0;
	}

	updateCurrentNodeGateState();

	updateTurnDownAmbientMusicVolume(delta);

	if(m_sound)
	{
		if(m_playTroopAtmosphereSoundTime >= FLT_EPSILON)
		{
			m_playTroopAtmosphereSoundTime -= delta;
			if(m_playTroopAtmosphereSoundTime < FLT_EPSILON)
			{
				//m_sound->keyOff();
				m_playTroopAtmosphereSoundTime = 0.0f;
			}
		}
		else
		{
			if(m_keyOffTroopAtmosphereSoundTime >= FLT_EPSILON)
			{
				m_keyOffTroopAtmosphereSoundTime -= delta;
			}
		}
	}
	m_autoTrackingCamera.update(delta);
}


bool BattleSceneView::ccTouchBegan(cocos2d::CCTouch *pTouch, cocos2d::CCEvent *pEvent)
{	
	CCPoint location = pTouch->getLocationInView();
	CCPoint pt0 = CCDirector::sharedDirector()->convertToGL(location);
	CCPoint pt = m_map->convertToNodeSpace(pt0);

	m_isTouch = true;

	m_prevTouchPoint = location;
	m_beganTouchPoint = pt0;

	

	m_model->setAutoFocus(false);


	/* 战斗场景地图 */;
	m_curTime = 0.0f;
	m_scrollSpeed = ccp(0, 0);
	m_isScrolling = false;

	return true;
}

void BattleSceneView::ccTouchMoved(cocos2d::CCTouch *pTouch, cocos2d::CCEvent *pEvent)
{
	if (m_isLockScreen) return;
	CCPoint location = pTouch->getLocationInView();
	CCPoint pt = m_map->convertToNodeSpace(CCDirector::sharedDirector()->convertToGL(location));

	CCPoint delta = ccpSub(location, m_prevTouchPoint);
	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	float scale = getScale();
	CCPoint pt2(getPositionX()+delta.x*scale, getPositionY()-delta.y*scale);
	float w = m_model->getWidth()*scale / getScaleFactor()*m_mapScale;
	float h = m_model->getHeight()*scale / getScaleFactor()*m_mapScale;
	if(pt2.x > 0.0f) pt2.x = 0.0f;
	else if(pt2.x < winSize.width-w) pt2.x = winSize.width-w;

	//bool isMoveAlongRoad = (PASS_MOVE_ALONG_ROAD(m_model->getId()) == 1);		// 地图地否沿着地图中道路移动
	//if (isMoveAlongRoad)
	//{
	//	pt2.y = calcBattleMapPosY(pt2.x);
	//}
	//else
	//{
	//	float moveLimit = static_cast<float>(PASS_MOVE_LIMIT(m_model->getId()));
	//	pt2 = calcbattleMapPos(pt2, moveLimit);
	//}

	if (pt2.y > m_bottomOffsetPos.y) pt2.y = m_bottomOffsetPos.y;
	else if (pt2.y < (winSize.height - h - m_topOffsetPos.y)) pt2.y = (winSize.height - h - m_topOffsetPos.y);
	setPosition(pt2);

	m_prevTouchPoint = location;

	if (m_curTime > 0.2f)
	{
		m_curTime = 0.0f;
		m_beganTouchPoint = location;
	}
}
bool BattleSceneView::ccTouchContinued(cocos2d::CCTouch *pTouch, cocos2d::CCEvent *pEvent)
{
	//ccTouchEnded(pTouch,pEvent);
	CCPoint pt0 = CCDirector::sharedDirector()->convertToGL(pTouch->getLocationInView());
	CCPoint pt = m_map->convertToNodeSpace(pt0);
	dealOnSingleClicked(pt);
	return true;
}
void BattleSceneView::ccTouchEnded(cocos2d::CCTouch *pTouch, cocos2d::CCEvent *pEvent)
{
	CCPoint pt0 = CCDirector::sharedDirector()->convertToGL(pTouch->getLocationInView());
	CCPoint pt = m_map->convertToNodeSpace(pt0);

	m_isTouch = false;

	if (ccpDistance(m_beganTouchPoint, pt0) < 30.0f / getScaleFactor())
	{
		dealOnSingleClicked(pt);
	}

	m_dest.x = static_cast<int16_t>(pt.x);
	m_dest.y = static_cast<int16_t>(pt.y);

	/* 处理地图滑动结束后的惯性移动 */
	CCPoint delta = ccpSub(pTouch->getLocation(), m_beganTouchPoint);
	float ratio = 1.0f;
	m_scrollSpeed.x = delta.x / m_curTime * ratio;
	m_scrollSpeed.y = delta.y / m_curTime * ratio;

	if(m_curTime < FLT_EPSILON || fabsf(m_scrollSpeed.x) < 300.0f)
	{
		m_scrollSpeed = ccp(0, 0);
		m_isScrolling = false;
	}
	else
	{
		/*bool isMoveAlongRoad = (PASS_MOVE_ALONG_ROAD(m_model->getId()) == 1);
		if (isMoveAlongRoad)
		{
			m_scrollSpeed.y = calcBattleMapPosY(m_scrollSpeed.x);
		}
		else
		{
			float moveLimit = static_cast<float>(PASS_MOVE_LIMIT(m_model->getId()));
			m_scrollSpeed = calcbattleMapPos(m_scrollSpeed, moveLimit);
		}*/
		m_isScrolling = true;
	}

	if(m_isLockScreen)
	{
		m_scrollSpeed = ccp(0, 0);
		m_isScrolling = false;
	}

}


void BattleSceneView::updateCustom( float dt )
{
	m_curTime += dt;

	if (!m_isScrolling)		return;

	/* 速度小于一定阈值时就停止滑动 */
	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	float speedFactor = 6.0f / scaleFactor;
	if (fabsf(m_scrollSpeed.x) < speedFactor || fabsf(m_scrollSpeed.y) < speedFactor)
	{
		m_isScrolling = false;
		m_scrollSpeed = ccp(0, 0);
		return;
	}

	CCPoint mapPos = getPosition();
	mapPos.x += m_scrollSpeed.x * dt;
	/*bool isMoveAlongRoad = (PASS_MOVE_ALONG_ROAD(m_model->getId()) == 1);
	if (isMoveAlongRoad)
	{
		mapPos.y = calcBattleMapPosY(mapPos.x);
	} 	
	else
	{
		mapPos.y += m_scrollSpeed.y * dt;
		float moveLimit = static_cast<float>(PASS_MOVE_LIMIT(m_model->getId()));
		mapPos = calcbattleMapPos(mapPos, moveLimit);
	}*/

	// 限制地图位置，使其不会超出游戏可视窗口
	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	float scale = getScale();
	float w = m_model->getWidth()*scale / getScaleFactor()*m_mapScale;
	float h = m_model->getHeight()*scale / getScaleFactor()*m_mapScale;
	mapPos.x = std::min<float>(0.0f, std::max<float>(winSize.width - w, mapPos.x));
	mapPos.y = std::min<float>(0.0f, std::max<float>(winSize.height - h, mapPos.y));

	//setPosition(mapPos);
	setPosition(ccpAdd(mapPos, m_bottomOffsetPos));


	// 速度衰减
	float ratio = 0.9f;
	m_scrollSpeed.x *= ratio;
	m_scrollSpeed.y *= ratio;
}

static int getTowardWith(const cocos2d::CCPoint &prePt, const cocos2d::CCPoint &curPt)
{
	return calcToward(prePt, curPt);
}


bool BattleSceneView::useSkill(const skill::SkillResult &sr, const skill::SpecialFxData &data, uint16_t attackerId, const SkillInfo &skillInfo, bool isNormalAttackSkill)
{	
	if(!isNormalAttackSkill)
	{		
		BattleObjectView *attackerView = getObjectView(attackerId);
		
		removeSkillIndicate(attackerId);
		attackerView->removeSkillIconName(false);
	}
	BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
	if(!attackerView)
	{
		assert(false);
		return false;
	}

	
	if (attackerView->getModel()->getParty() == kEnemyParty)
	{
		attackerView->runBeforeUseSkillMiddleUpEffect(0.0f);
	}

	if (attackerView->getModel()->isModelInContinuMagState())
	{
		return false;
	}

	if(attackerView->getModel()->getType() == BattleMoveObject::kGeneral)
	{
		attackerView->playSkillSound(skillInfo);
	}
	
	return skillAttackTarget(sr, data, attackerId, skillInfo, isNormalAttackSkill);
}

static void handleAttackInfo(const AttackInfo &info, BattleObject *attacker, uint16_t targetId, int skillLvId, bool isNormalAttack, bool isFirstObject, const PixelPoint &hitPos, bool isIgnoreHitDelay = false)
{
	BattleSceneView *sceneView = BattleSceneView::getCurrentSceneView();
	BattleObjectView *target = sceneView->getObjectView(targetId);
	if (!target) return;

	CCPoint attackerPos = attacker->getViewPosition();
	const CCPoint &defenderPos = target->getPosition();
	int toward = -1;
	if(target->getModel()->getPixelPosition() == hitPos)
	{
		toward = calcToward(defenderPos, attackerPos);
	}
	else
	{
		toward = calcToward(defenderPos, ccp(hitPos.x, hitPos.y));
	}
	float hitDelayTime = 0.0f;
	if(!isIgnoreHitDelay)
	{
		const SkillProperty &skillPty = getSkillEffect(skill::getSkillId(skillLvId));
		hitDelayTime = skillPty.hitDelay;
	}

	int num = 0;
	for (size_t j = 0; j < info.damages.size(); ++j)
	{
		const DamageInfo &damageInfo = info.damages[j];
		int damage = damageInfo.damage;
		int subDamage = info.subDamage;
		int damageState = damageInfo.state;
        if (damageState == DamageInfo::kDodgeHurt)
		{
			target->dodge(hitDelayTime);
			continue;
		}

		if (info.isDamageMultiDisplay)
		{
			if(subDamage > 0)
			{
				num = (damage + subDamage - 1) / subDamage;
			}
			else
			{
				assert(damage == 0);
				num = 1;
			}

			float delay = 0.0f;
			for (int k = 0; k < num; ++k)
			{
				delay = k * 0.15f;
				target->hit(attacker, skillLvId, isNormalAttack, isFirstObject, subDamage > damage ? damage : subDamage, damageState, damageInfo.bounceDamage, delay + hitDelayTime, toward);
				damage -= subDamage;
			}
		}
		else
		{
			target->hit(attacker, skillLvId, isNormalAttack, isFirstObject, damage, damageState, damageInfo.bounceDamage, hitDelayTime, toward);
		}
	}
}

static void handleReport(BattleObject *attacker, const BattleReport &br, bool isIgnoreHitDelay)
{
	if (br.infos.empty()) return;
	BattleScene *scene = BattleScene::getCurrentScene();
	const std::vector<AttackInfo> &infos = br.infos;
	int skillId = br.skillLvId;

	for (size_t i = 0; i < infos.size(); ++i)
	{
		uint16_t targetId = infos[i].defenderId;
		//INFO_MSG("targetId:%d",targetId);
		handleAttackInfo(infos[i], attacker, targetId, skillId, br.isNormalAttackSkill, i == 0, br.hitPos, isIgnoreHitDelay);
	}
}

static void genBulletCentesisBattleReport(BattleObject *attacker, uint16_t targetId, int skillId, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleObject *target = scene->getObject(targetId);
	if (!target) return;

	set<uint16_t> targets;
	targets.insert(targetId);
	// begin
	TargetSelectMgr::theMgr().addMainTargetId(targetId);

	handleFxBuff(attacker, skillId, targets);

	BattleReport br;
	br.hitPos = attacker->getPixelPosition();
	std::set<uint16_t> targetSet;
	targetSet.insert(targetId);
	if (scene->getObjectType(attacker->getId()) == BattleScene::kMoveObj)
	{
		scene->genSkillBattleReport(&br, dynamic_cast<BattleMoveObject *>(attacker), targetSet, skillId, calcHurtAttackProp);
	}
	else
	{
		scene->genSkillBattleReport(&br, dynamic_cast<BattleTower *>(attacker), targetSet, skillId, calcHurtAttackProp);
	}

	TargetSelectMgr::theMgr().clearMainTargetIds();
	// end
	const std::vector<AttackInfo> &infos = br.infos;
	for (size_t i = 0; i < infos.size(); ++i)
	{
		handleAttackInfo(infos[i], attacker, targetId, skillId, true, i == 0, br.hitPos);
	}
}

static void genBulletBattleReport(BattleObject *attacker, uint16_t targetId, int skillId)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleObject *target = scene->getObject(targetId);
	if (!target) return;

	set<uint16_t> targets;
	targets.insert(targetId);
	// begin
	TargetSelectMgr::theMgr().addMainTargetId(targetId);

	handleFxBuff(attacker, skillId, targets);

	BattleReport br;
	br.hitPos = attacker->getPixelPosition();
	if (scene->getObjectType(attacker->getId()) == BattleScene::kMoveObj)
	{
		scene->genBattleReport(&br, dynamic_cast<BattleMoveObject *>(attacker), targetId, skillId);
	}
	else
	{
		scene->genBattleReport(&br, dynamic_cast<BattleTower *>(attacker), targetId, skillId);
	}

	TargetSelectMgr::theMgr().clearMainTargetIds();

	const std::vector<AttackInfo> &infos = br.infos;
	for (size_t i = 0; i < infos.size(); ++i)
	{
		INFO_MSG("defenderId:%d", infos[i].defenderId);
		handleAttackInfo(infos[i], attacker, targetId, skillId, true, i == 0, br.hitPos);
	}
}

static void genBattleReport(BattleObject *attacker, uint16_t targetId, int skillId, const PixelPoint &hitPos, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleObject *target = scene->getObject(targetId);
	if (!target) return;

	BattleReport br;
	br.hitPos = hitPos;
	scene->genBattleReport(&br, attacker, targetId, skillId);

	const std::vector<AttackInfo> &infos = br.infos;
	for (size_t i = 0; i < infos.size(); ++i)
	{
		handleAttackInfo(infos[i], attacker, targetId, skillId, true, i == 0, br.hitPos);
	}	
}

static void genBattleReport(uint16_t attackerId, uint16_t targetId, int skillId, const PixelPoint &hitPos, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleObject * attacker = scene->getObject(attackerId);
	if (attacker)
	{
		genBattleReport(attacker, targetId, skillId, hitPos, calcHurtAttackProp);
	}
}

template <typename T>
static BattleReport genSkillBattleReport(T attacker, const std::set<uint16_t> &defenders, int skillId, const PixelPoint &hitPos, CalcHurtAttackProp *calcHurtAttackProp)
{
	if (attacker == nullptr)
	{
		assert(false);
	}
	BattleScene *scene = BattleScene::getCurrentScene();

	BattleReport br;
	br.hitPos = hitPos;
	scene->genSkillBattleReport(&br, attacker, defenders, skillId, calcHurtAttackProp);

	handleReport(attacker, br, true);
	return br;
}

static BattleReport genSkillBattleReport(BattleObject * attacker, const std::set<uint16_t> &defenders, int skillId, const PixelPoint &hitPos, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleScene *scene = BattleScene::getCurrentScene();

	BattleReport br;
	br.hitPos = hitPos;

	switch(scene->getObjectType(attacker->getId()))
	{
	case BattleScene::kMoveObj:
		scene->genSkillBattleReport(&br, dynamic_cast<BattleMoveObject*>(attacker), defenders, skillId, calcHurtAttackProp);
		break;
	case BattleScene::kTower:
		scene->genSkillBattleReport(&br, dynamic_cast<BattleTower*>(attacker), defenders, skillId, calcHurtAttackProp);
		break;
	default:
		assert(false);
		break;
	}

	handleReport(attacker, br, true);
	return br;
}

static BattleReport genSkillBattleReport(uint16_t attackerId, const std::set<uint16_t> &defenders, int skillId, const PixelPoint &hitPos, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleMoveObject * attacker = scene->getMoveObject(attackerId);
	return genSkillBattleReport(attacker, defenders, skillId, hitPos, calcHurtAttackProp);
}

// 普攻;
void BattleSceneView::handleAttackTargetInfo(const AttackTargetInfo &targetInfo)
{
	uint16_t attackerId = targetInfo.attackerId;
	uint16_t targetId = targetInfo.targeterId;
	int skillId = skill::getSkillId(targetInfo.skillLvId);

	BattleObjectView *attacker = getObjectView(attackerId);
	if (!attacker) return;

	int attackType = SKILL_ATTACK_TYPE(skillId);
	if (attackType == kShort)
	{
		int skillHitType = SKILL_HIT_TYPE(skillId);
		if (skillHitType == kTarget)
		{
			// begin
			TargetSelectMgr::theMgr().addMainTargetId(targetInfo.targeterId);
			set<uint16_t> targets;
			targets.insert(targetInfo.targeterId);
			handleFxBuff(attacker->getModel(), targetInfo.skillLvId, targets);
			genBattleReport(attacker->getModel(), targetId, targetInfo.skillLvId, attacker->getModel()->getPixelPosition(), nullptr);
			TargetSelectMgr::theMgr().clearMainTargetIds();
			// end
		}
		else
		{
			GridPosition grid = targetInfo.targeterPos;
			PixelPoint pixelPt = GridUtil::sharedGridUtil().gridToPix(grid);
			std::set<uint16_t> targets;
			skill::getObjects(&targets, targetInfo.skillLvId, attacker->getModel()->getParty(), attacker->getModel(), grid);
			// begin
			TargetSelectMgr::theMgr().addMainTargetId(targetInfo.targeterId);
			handleFxBuff(attacker->getModel(), targetInfo.skillLvId, targets);
			for (set<uint16_t>::iterator iter = targets.begin(); iter != targets.end(); ++iter)
			{
				genBattleReport(attacker->getModel(), *iter, targetInfo.skillLvId, pixelPt, nullptr);
			}
			TargetSelectMgr::theMgr().clearMainTargetIds();
			// end
			std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillId));
			if (!effectStr.empty())
			{
				SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillId, 0.0f, 0.0f, ccp(pixelPt.x, pixelPt.y), m_map);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(ccp(pixelPt.x, pixelPt.y));
				addChild(pEffect, 10);
			}
		}
	}
	else
	{
		const SkillProperty &skillPty = getSkillEffect(skillId);
		float scale = attacker->getCurAttackFrameIntervalScale();

		CCDelayTime *delay = CCDelayTime::create(skillPty.bulletDelay * scale);

		CCCallFuncND *addBullet = CCCallFuncND::create(this, std::bind(&BattleSceneView::addBullet, this, targetInfo));
		runAction(CCSequence::create(delay, addBullet, nullptr));
	}

}

bool BattleSceneView::bindBulletHandler(CCBullet * bullet, uint16_t attackId, AttackTargetInfo info, const cocos2d::CCPoint &pt, uint16_t targetId)
{
	BattleObject *attacker = bullet->getAttackerObject();
	if (nullptr == attacker)
	{
		return false;
	}
	int skillId = skill::getSkillId(info.skillLvId);
	int skillHitType = SKILL_HIT_TYPE(skillId);
	if (skillHitType == kTarget)
	{
		bullet->setHandler(std::bind(genBulletCentesisBattleReport, attacker, targetId, info.skillLvId, bullet->getCalcHurtAttackProp()));
	}
	else
	{
		bullet->setHandler(std::bind(&BattleSceneView::onBulletReachDest, this, info.skillLvId, pt, attacker, info.attackerId, true, bullet->getCalcHurtAttackProp()));
	}
	return true;
}

void BattleSceneView::onBulletReachDest(int skillLvId, const CCPoint &pt, BattleObject * attacker, uint16_t attackerId, bool isNormalAttack, CalcHurtAttackProp *calcHurtAttackProp)
{
	GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(pt.x, pt.y);
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillLvId, attacker->getParty(), attacker, grid);
	// begin
	TargetSelectMgr::theMgr().addMainTargetIds(m_model->getTerrain()->getGridObjects(grid.x, grid.y));
	handleFxBuff(attacker, skillLvId, targets);

	if(isNormalAttack)
	{
		for (set<uint16_t>::iterator iter = targets.begin(); iter != targets.end(); ++iter)
		{
			genBattleReport(attacker, *iter, skillLvId, PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)), calcHurtAttackProp);
		}
	}
	else
	{
		genSkillBattleReport(attacker, targets, skillLvId, PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)), calcHurtAttackProp);
	}
	TargetSelectMgr::theMgr().clearMainTargetIds();	
	// end
	int skillId = skill::getSkillId(skillLvId);
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillId));
	if (!effectStr.empty())
	{
		SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillId, 0.0f, 0.0f, pt, m_map);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(pt);
		addChild(pEffect, 10);
	}
}

bool BattleSceneView::handleSpecialFxData(BattleObjectView *attackerView, uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	skill::SpecialFxType type = data.type;
	PixelPoint targetPixelPoint = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
	CCPoint targetPosition = ccp(targetPixelPoint.x, targetPixelPoint.y);
	switch (type)
	{
	case skill::kSpecialFxNull:
		break;
	case skill::kChainLightning:
		{
			std::vector<uint16_t> objs;
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			assert(attacker);
			skill::getObjects(&objs, skillInfo, data, attacker->getParty(), attacker->getFloatGridPosition());
			if (objs.size() < 2)
			{
				return false;
			}
			objs.push_back(attacker->getId());
			addChainLightning(attacker, objs, data.data3, skill::getSkillLvId(skillInfo.skill_id, skillInfo.level));
			break;
		}
	case skill::kChainLull:
		{
			std::vector<uint16_t> objs;
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			assert(attacker);
			const set<uint16_t> &objects = TargetSelectMgr::theMgr().getObjects();
			if (objects.size() < 1)
			{
				return false;
			}
			objs.push_back(attacker->getId());
			objs.push_back(*objects.begin());
			addLullLine(attacker, objs, data.data1);
			break;
		}
	case skill::kCureOrFireflag:
		{
			std::vector<uint16_t> objs;
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			assert(attacker);
			skill::getObjects(&objs, skillInfo, data, attacker->getParty(), attacker->getFloatGridPosition());
			if (objs.size() < 2)
			{
				return false;
			}
			addChainMixing(attacker, objs, 0.0f, data.data3,skill::getSkillLvId(skillInfo.skill_id, skillInfo.level)); //没有衰弱百分比
			break;
		}
	case skill::kChainCure:
		{
			std::vector<uint16_t> objs;
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			skill::getObjects(&objs, skillInfo, data, attacker->getParty(), attacker->getFloatGridPosition());
			if (objs.size() < 2)
			{
				return false;
			}
			addChainCure(attacker, objs, data.data3, data.data4);
			break;
		}
	case skill::kChainCureBullet:
		{
			addDoPassiveChainCure(attackerId, skillInfo, data);
			break;
		}
	case skill::kStaticWhirlWind:
		{
			addStaticWhirlWind(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kBullet:
		{
			bulletImpl(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kTrap:
		{
			addTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kHurtTrap:
		{
			addHurtTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kIceTrap:
		{
			addIceTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kHellTrap:
		{
			addHellTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kAbsorbHpTrap:
	case skill::kTrapWall:
	case skill::kTrapWallAndIntervalTime:
		{
			addSimpleAccountTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kFireBull:
		{
			addFireBull(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kAddResource:
		{
			addResourceEffect(data);
			break;
		}
	case skill::kSkillHittingFrame:
		{
			addSkillHittingFrame(attackerId, skillInfo, targetPosition, data);
			break;
		}

	case skill::kInvincibleFastCut:
		{
			CCPoint atkPixPosition = ccp(attackerView->getModel()->getPixelPosition().x, attackerView->getModel()->getPixelPosition().y);
			float contentSizeWidth = attackerView->getContentSize().width;
			CCPoint attackerPos = ccp(atkPixPosition.x, atkPixPosition.y); //todo:攻击的位置和技能调试的位置有大概半格或一格的误差
			attackerView->doCutAttackForInvincible(skill::getSkillLvId(skillInfo.skill_id, skillInfo.level),false); 
			BattleMoveObject * attacker = dynamic_cast<BattleMoveObject *>(attackerView->getModel());
			attacker->setCannotMoveAndAttack(true);
			doInvincibleFastCut(attackerId, skillInfo, data, 1, GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((int16_t)attackerPos.x, (int16_t)attackerPos.y)), 0);
			
			break;
		}

	case skill::kChainDamage:
		{
			std::vector<uint16_t> objs;
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			assert(attacker);
			skill::getObjects(&objs, skillInfo, data, attacker->getParty(), attacker->getFloatGridPosition());
			if (objs.size() < 2)
			{
				return false;
			}

			ChainDamageMgr &cdm = ChainDamageMgr::theMgr();
			cdm.createChainDamage(data.data4, static_cast<int>(data.data5), static_cast<int>(data.data3));
			for ( auto it = objs.begin(); it != objs.end(); it++ )
			{
				cdm.addObjectId(*it);
			}

			addChainDamage(attacker, objs, skillInfo);
			break;
		}

	case skill::kBulletAndTrap:
		{
			addBulletAndTrap(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kFountain:
		{
			addFountain(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kEnergyBomb:
		{
			addBigEnegyBall(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kSpecAttack:
		{
			addBigBulletShoot(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kBombBullet:
	case skill::kContinuousFireBullet:
		{
			addTickShoot(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kFountainPartake:
		{
			addFountainPartake(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kSnowstorm:
		{
			addSnowstorm(attackerId, skillInfo, targetPosition, data);
			break;
		}
	case skill::kSectorIce:
		{
			addRandomShootAttack(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}	
	case skill::kMultipleTargetBullet:
		{
			addShootToSomeTargets(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kShockWave:
	case skill::kTouchBeganShockWave:
		{
			addShockWaveAttack(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kCentesis:
		{
			if (data.targetId == 0)
			{
				break;
			}
			bool isAccount = (SKILL_HIT_TYPE(skillInfo.skill_id) == kDest);
			AttackTargetInfo info;
			info.attackerId = attackerId;
			info.skillLvId = skill::getSkillLvId(skillInfo.skill_id,skillInfo.level);
			info.targeterPos.x = (int16_t)targetPixelPoint.x;
			info.targeterPos.y = (int16_t)targetPixelPoint.y;
			info.targeterId = data.targetId;

			addBulletCentesis(info,data);
			break;
		}
	case skill::kSnatchAtGeneral:
		{
			CCDelayTime *delay = CCDelayTime::create(0.8f);
			CCSequence * action = CCSequence::create(delay, CCCallFuncND::create(this, std::bind(&BattleSceneView::doCatchSkillAttack, this, attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data)), nullptr);
			action->setTag(skill::kDoCatchEffcTag + attackerId);
			runAction(action);
			break;
		}
	case skill::kTransfiguration:
		{
			doTransformToSheep(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kPyrosphere:
		{
			addWhirlFire(attackerId, skillInfo, ccp(attackerView->getModel()->getPixelPosition().x,attackerView->getModel()->getPixelPosition().y), data);
			break;
		}
	case skill::kNihility:
		{
			addNothingnessSkill(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kLightningPrison:
		{
			doThunderAttckInterval(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kLightningStrikeSheep:
		{
			doSheepAndThunderHurt(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kLifeCombat:
		{
			doLiveOrNotToLiveSkill(attackerId, skillInfo, ccp(attackerView->getModel()->getGridPosition().x,attackerView->getModel()->getGridPosition().y), data);
			break;
		}
	case skill::kTargetByOutCircle:
		{
			addOuterAttackSpecialFxImpl(attackerId, skillInfo, targetPosition, data);
			break;
		}
	default:
		assert(false);
	}

	return true;
}

void BattleSceneView::addChainLightning(BattleMoveObject *attacker, const std::vector<uint16_t> &targets, float percent, int skillLvId)
{
	LightningAction *la = LightningAction::create(attacker, targets, CCLighting::kLightning, percent, std::bind(&BattleSceneView::chainLightningAccount, this, attacker, _1, skillLvId, _2));
	addChild(la, 10);
}

void BattleSceneView::addChainMixing(BattleMoveObject *attacker, const std::vector<uint16_t> &targets, float percent, float addHp, int skillLvId)
{
	LightningAction *la = LightningAction::create(attacker, targets, CCLighting::kMixing, percent, std::bind(&BattleSceneView::chainLightningAccount, this, attacker, _1, skillLvId, _2));
	la->setAddHp(addHp);
	addChild(la, 10);
}

void BattleSceneView::addChainCure(BattleMoveObject *attacker, const std::vector<uint16_t> &targets, float percent, float addHp)
{
	LightningAction *la = LightningAction::create(attacker, targets, CCLighting::kCure, percent);
	la->setAddHp(addHp);
	addChild(la, 10);
}

void BattleSceneView::addLullLine(BattleMoveObject *attacker, const std::vector<uint16_t> &targets, float keepTime)
{
	LightningAction *la = LightningAction::create(attacker, targets, CCLighting::kLull, 1.0f);
	la->setKeepTime(keepTime);
	addChild(la, 10);
}

void BattleSceneView::addDoPassiveChainCure(uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{	
	BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
	GridPosition atkGridPos = attacker->getGridPosition();
	CCPoint position = ccp(atkGridPos.x, atkGridPos.y);
	std::set<uint16_t> targets;
	skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);
	if (!targets.empty())
	{
		uint16_t targetId = (*targets.begin());
		BattleMoveObject * targetObj = m_model->getMoveObject(targetId);
		PixelPoint pixpos = targetObj->getPixelPosition();;
		cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
		skill::SpecialFxData dataAdapt;
		dataAdapt.type = data.type;
		dataAdapt.data1 = data.data1;
		dataAdapt.data2 = data.data2;
		dataAdapt.data3 = data.data3;
		dataAdapt.data4 = data.data4;
		dataAdapt.targetId = targetObj->getId();
		addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, false);		
	}	
}

void BattleSceneView::onSpecialReachDest(int skillLvId, const CCPoint &pt, BattleMoveObject *attacker, uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleMoveObject * targetObj = m_model->getMoveObject(data.targetId);
	if (targetObj)
	{
		switch (data.type)
		{
		case skill::kChainCureBullet:
			{
				std::vector<uint16_t> objs;
				objs.push_back(data.targetId);
				skill::getObjects(&objs, skillInfo, data, targetObj->getParty(), targetObj->getFloatGridPosition());				
				if (objs.size() < 2)
				{
					return;
				}
				addChainCure(attacker, objs, data.data3, data.data4);
				break;
			}	
		case skill::kPyrosphere:
			{
				onAddBulletWhirlFire(attackerId, skillInfo, pt, data);
				break;
			}	
		case skill::kBombBullet:
			{
				GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(pt.x, pt.y);
				
				std::set<uint16_t> selfId;
				selfId.insert(data.targetId);
				genSkillBattleReport(attacker, selfId, skillLvId, PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)), calcHurtAttackProp);

				std::set<uint16_t> targets;
				getObjects(&targets, skillInfo, data, attacker->getParty(), ccp(grid.x, grid.y));

				std::set<uint16_t>::iterator findObj = find(targets.begin(), targets.end(), data.targetId);
				if (findObj !=  targets.end())
				{
					targets.erase(findObj);
				}

				// begin
				TargetSelectMgr::theMgr().addMainTargetIds(m_model->getTerrain()->getGridObjects(grid.x, grid.y));
				handleFxBuff(attacker, skillLvId, targets, false);				

				TargetSelectMgr::theMgr().clearMainTargetIds();	
				// end
				int skillId = skill::getSkillId(skillLvId);
				std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillId));
				if (!effectStr.empty())
				{
					SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillId, 0.0f, 0.0f, pt, m_map);
					pEffect->setAnchorPoint(ccp(0, 0));
					pEffect->setPosition(pt);
					addChild(pEffect, 10);
				}
				break;
			}
		case skill::kMultipleTargetBullet:
			{			
				std::set<uint16_t> targets;
				targets.insert(data.targetId);
				handleFxBuff(attacker, skillLvId, targets);
				genSkillBattleReport(attacker, targets, skillLvId, PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)), calcHurtAttackProp);
				break;
			}
		default:
			{
				assert(false);
				break;
			}
		}		
	}
}


void BattleSceneView::addChainDamage(BattleMoveObject *attacker, const std::vector<uint16_t> &targets, const SkillInfo &skillInfo)
{
	LightningAction *la = LightningAction::create(attacker, targets, CCLighting::kDamage, 1.0f);
	addChild(la, 10);

	la->setActionFinishedHandler([=](void) ->void
	{
	std::set<uint16_t> objs;
	for (size_t i = 0; i < targets.size(); ++i)
	{
	objs.insert(targets[i]);
	}
	skill::doBuff(m_model, attacker, objs, skill::getSkillLvId(skillInfo.skill_id, skillInfo.level), TargetSelect::kTargetOpponent);
	});
}

static CCPoint getBulletAndTrapDest(const CCPoint &start, const CCPoint &pos, float length)
{
	float dis = ccpDistance(start, pos);
	float sin_ = (pos.y - start.y) / dis;
	float cos_ = (pos.x - start.x) / dis;

	CCPoint dest(start.x + length * cos_, start.y + length * sin_);
	return dest;
}

static CCPoint getBullectAndTrapMid(const CCPoint &start, const CCPoint &pos, float length)
{
	float dis = ccpDistance(start, pos);
	float sin_ = (pos.y - start.y) / dis;
	float cos_ = (pos.x - start.x) / dis;

	CCPoint dest(start.x + length * cos_ * 0.5f, start.y + length * sin_ * 0.5f);
	return dest;
}

cocos2d::CCPoint BattleSceneView::posTransformMinAreaEnemy(const CCPoint &targetPos, const CCPoint &attackerPos, const CCPoint &pt)
{
	//打坐标类技能，在最小范围内，重新计算目标点
	float angleDegree = angle(attackerPos,targetPos);
	float k = tan(CC_DEGREES_TO_RADIANS(angleDegree) );
	float b = pt.y - k*pt.x;
	//下面会根据攻击方向计算最长的攻击距离，改攻击距离远大于30，所以以x轴递增30在新的平行线上指定一个目标点，让它与 startPos 构成直线
	float bulletLongestDisX = 30; 
	if (angleDegree>90 && angleDegree<270)
	{
		bulletLongestDisX = -bulletLongestDisX;
	}
	float tmpXPos = pt.x + bulletLongestDisX;

	float tmpYPos = k*tmpXPos + b;
	CCPoint finalTargetPos = ccp(tmpXPos + attackerPos.x, tmpYPos + attackerPos.y);
	return finalTargetPos;
}

void BattleSceneView::addBulletAndTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
	float bulletDelay = skillPty.bulletDelay;
	BattleObjectView *attackerView = getObjectView(attackerId);
	BattleMoveObject * attacker = nullptr;
	if (attackerView)
	{
		attacker = dynamic_cast<BattleMoveObject *>(attackerView->getModel());
	}

	std::string bulletRes = std::string(SKILL_BULLET_RES(skillInfo.skill_id));
	if (!bulletRes.empty())
	{
		PixelPoint attackerPos = attackerView->getModel()->getPixelPosition();
		int attackerToward = attackerView->getModel()->getToward();
		CCPoint pt = attackerView->getEffectHangPointPos(skillPty.bulletStartPoint[getIndexWithTowardByStartPoint(attackerToward)], shouldSetFilp(attackerToward));

		const std::vector<int> &range = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
		int length = range[0];

		//程序需求 #2539 当攻击点在攻击者最小攻击范围内时,
		//1、打目标类的技能:不播放子弹资源特效，其他特效按正常流程播放，逻辑流程正常进行
		//2、打坐标类技能:沿技能方向，以最小攻击距离为起点释放，特效和逻辑流程正常进行（由于目标不在范围内，故本次释放该目标不受技能影响）
		float minAtkAreaRadius =  sqrtf(static_cast<float>(pt.x*pt.x + pt.y*pt.y));
		bool isInMinAtkArea = isInCircle(ccp(position.x, position.y),ccp(attackerPos.x, attackerPos.y),minAtkAreaRadius);
		CCPoint finalTargetPos = ccp(position.x,position.y);
		if (isInMinAtkArea)
		{
			//最小攻击范围时，修改坐标类技能的最终攻击点
			finalTargetPos = posTransformMinAreaEnemy(finalTargetPos, ccp(position.x, position.y), pt);
		}

		CCPoint anglePos = ccp(finalTargetPos.x + pt.x, finalTargetPos.y + pt.y);
		CCPoint angleGridPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((int16_t)(anglePos.x), (int16_t)(anglePos.y)));
		CCPoint start = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((int16_t)(attackerPos.x + pt.x), (int16_t)(attackerPos.y + pt.y)));
		CCPoint dest = getBulletAndTrapDest(start, angleGridPos, (float)length);

		PixelPoint destPix = GridUtil::sharedGridUtil().floatGridToPix((int16_t)dest.x, (int16_t)dest.y);
		IntervalAnimationDisplayNode *bulletSp = IntervalAnimationDisplayNode::create(bulletRes.c_str()
			, false);
		float bulletScale = skillPty.bulletScale;
		if (attacker->getGameSoldier())
		{
			BattleMoveObjectView *attBMV = dynamic_cast<BattleMoveObjectView *>(attackerView);
			bulletScale = skillPty.bulletScale * attBMV->getSelectScale();
		}
		bulletSp->setScaleValue(bulletScale);
		BulletEffect *bullet = BulletEffect::exactDest(attackerId, 
			ccp(attackerPos.x + pt.x, attackerPos.y + pt.y),
			ccp(destPix.x, destPix.y),
			bulletSp,
			bulletDelay);

		skill::SpecialFxData bulletData;
		bulletData.type = skill::kBullet;
		bulletData.data2 = data.data1;

		bullet->setAttacker(attacker);
		bullet->setAccountHandler(std::bind(&BattleSceneView::bulletAccount, this, _1, _2, _3, _4, _5, attackerId, skillInfo, bulletData, bullet->getCalcHurtAttackProp()));
		bullet->setSpeed(skillPty.bulletSpeed / getScaleFactor());
		bullet->setRotateMode(bulletRes.c_str());
		m_map->addChild(bullet, skill::kBulletEffecZorder);

		bullet->setHandler([=](const cocos2d::CCPoint &finalTargetPos, BattleMoveObject * attacker) ->void
		{
			CCPoint mid = getBullectAndTrapMid(start, angleGridPos, (float)length);
			PixelPoint midPix = GridUtil::sharedGridUtil().floatGridToPix(mid.x, mid.y);
			std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
			if (!effectStr.empty())
			{
				skill::SpecialFxData trapData;
				trapData.type = skill::kTrap;
				trapData.pos = ccp(midPix.x, midPix.y);
				SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data3, ccp(midPix.x, midPix.y), m_map);
				pEffect->setAttacker(attacker);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(ccp(midPix.x, midPix.y));
				pEffect->setHandler(std::bind(&BattleSceneView::account, this, ccp(midPix.x, midPix.y), attacker, skillInfo, trapData, false, true, pEffect->getCalcHurtAttackProp()));
				addChild(pEffect, 10);
			}
		});

		const char *sound = SKILL_BULLET_MUSIC(skillInfo.skill_id);
		if(strcmp(sound, "") != 0)
		{
			bullet->setSound(sound);
		}
	}
}

void BattleSceneView::addStaticWhirlWind(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleObjectView *attacker = getObjectView(attackerId);
	attacker->staticWhirlWind(skillInfo, data);
	attacker->whirlWindHandler(std::bind(&BattleSceneView::account, this, _1, attacker->getModel(), skillInfo, data, false, true, nullptr));
}

void BattleSceneView::addBigBulletShoot(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
	if (attacker)
	{
		attacker->setLogicState(BattleObject::kLogicContinueMag);
		attacker->setState(BattleObject::kIdle);

		
		CCDelayTime * delayShoot = CCDelayTime::create(data.data1);
		uint16_t targetid = 0;
		std::set<uint16_t> targets;
		skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);
		if (!targets.empty())
		{
			targetid = (*targets.begin());
			BattleMoveObjectView * targetView = getMoveObjectView(targetid);
			if (targetView)
			{
				std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
				if (!effectStr.empty())
				{
					std::vector<std::string> vec = split(effectStr, "/");
					assert(vec.size() == 3);
					int customEffectId = atoi(vec[2].c_str());
					CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId,  data.data1, 0.0f);
					pEffect->setAnchorPoint(ccp(0, 0));					
					const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
					CCPoint skillEffFrontHangPoint = ccp(skillPty.skillEffectFrontHangPoint[0][0].x - 600.0f, skillPty.skillEffectFrontHangPoint[0][0].y - 600.0f);
				    pEffect->setPosition(skillEffFrontHangPoint);
					pEffect->setAutoReleaseWhenFinish(true);
					targetView->addChild(pEffect, 10);
				}
			}			
		}	
		CCCallFuncND *callFunc = CCCallFuncND::create(this, std::bind(&BattleSceneView::doBigBulletShoot, this, position, attackerId, targetid, skillInfo, data));//这里蓄力子弹有特殊处理：会在蓄力结束后再选取一次目标
		CCSequence *seqFunc = CCSequence::create(delayShoot, callFunc, nullptr); 
		runAction(seqFunc);
		seqFunc->setTag(skill::kBigBulletShootTag + attackerId);
	}
}

void BattleSceneView::doBigBulletShoot(const cocos2d::CCPoint &pt, uint16_t attackerId, uint16_t targetId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (attacker)
	{		
		attacker->setState(BattleObject::kSufContinueMagAtk);
		uint16_t realTargetId = targetId;
		if (realTargetId == 0)
		{
			std::set<uint16_t> targets;
			skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, pt);
			if (!targets.empty())
			{
				realTargetId = (*targets.begin());			
			}
		}
		
		if (realTargetId == 0)
		{
			return;
		}

		BattleMoveObject * targetObj = m_model->getMoveObject(targetId);
		if (targetObj)
		{
			PixelPoint pixpos = targetObj->getPixelPosition();;
			cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
			skill::SpecialFxData dataAdapt;
			dataAdapt.type = data.type;
			dataAdapt.data1 = 1;
			dataAdapt.targetId = targetObj->getId();
			addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, false);	
		}
	}	
}

void BattleSceneView::addTickShoot(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleObjectView *attacker = getObjectView(attackerId);
	if (attacker)
	{
		attacker->tickShoot(skillInfo, data);
		switch (data.type)
		{
		case skill::kContinuousFireBullet:
			{
				attacker->tickShootHandler(std::bind(&BattleSceneView::doOneTickShoot, this, attackerId, skillInfo, position, data));
				break;
			}
		case skill::kBombBullet:
			{
				attacker->tickShootHandler(std::bind(&BattleSceneView::doOneBombTickShoot, this, attackerId, skillInfo, position, data));
				break;
			}	
		}
	}	
}

void BattleSceneView::doOneTickShoot(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (attacker)
	{
		std::set<uint16_t> targets;
		skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);
		if (!targets.empty())
		{		
			BattleMoveObject * targetObj = m_model->getMoveObject(*targets.begin());
			PixelPoint pixpos = targetObj->getPixelPosition();;
			cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
			skill::SpecialFxData dataAdapt;
			dataAdapt.type = data.type;
			dataAdapt.data1 = 1;
			dataAdapt.targetId = targetObj->getId();
			addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, false);	
		}
	}
}

void BattleSceneView::doOneBombTickShoot(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (attacker)
	{
		std::set<uint16_t> targets;
		skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);
		if (!targets.empty())
		{
			BattleMoveObject * targetObj = m_model->getMoveObject(*targets.begin());
			PixelPoint pixpos = targetObj->getPixelPosition();;
			cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
			skill::SpecialFxData dataAdapt;
			dataAdapt.type = data.type;
			dataAdapt.data1 = 1;
			dataAdapt.data2 = data.data2;
			dataAdapt.targetId = targetObj->getId();
			addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, false);	
		}
	}
}

void BattleSceneView::addTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data1, position, m_map);
		BattleMoveObject * attaker = m_model->getMoveObject(attackerId);
		pEffect->setAttacker(attaker);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(position);
		pEffect->setHandler(std::bind(&BattleSceneView::account, this, position, attaker, skillInfo, data, false, false, pEffect->getCalcHurtAttackProp()));
		pEffect->setFinishHandler(std::bind(&BattleSceneView::trapRemoveAccount, this, position, attaker, skillInfo, data, pEffect->getCalcHurtAttackProp()));
		addChild(pEffect, 10);
	}
}

void BattleSceneView::addHurtTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data1, position, m_map);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(position);
		pEffect->setAttacker(attacker);
		pEffect->setHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, false, true, pEffect->getCalcHurtAttackProp()));
		addChild(pEffect, 10);
	}
}

void BattleSceneView::addFountain(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		attacker->setLogicState(BattleObject::kLogicContinueMag);
		attacker->setState(BattleObject::kIdle);
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		CustomEffectRandom *pEffect = CustomEffectRandom::create(customEffectId,  data.data2, m_map, data.data1);
		pEffect->setAttackerId(attackerId);
		pEffect->setAttackerSkillId(skillInfo.skill_id);
		pEffect->setAttackerSkillLevel(skillInfo.level);
		pEffect->setIsPercentToDoAi(true);
		pEffect->setAiPercent(1000);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(position);
		//可能存在两个张宝同时放技能的情况，所以需要使用EFFTAG加上攻击者ID
		m_map->addChild(pEffect, 10, skill::kFountainEffcTag+attackerId);
		pEffect->setAutoReleaseWhenFinish(false);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::fountainRemoveAccount, this, position, attacker, skillInfo, data));
		pEffect->setHittingFrameHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::fountainRemoveAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	attacker->setState(BattleObject::kSufContinueMagAtk);
}

void BattleSceneView::onAddBulletWhirlFire(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
		float delay = skillPty.skillEffectFrontDelay[0];
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		uint16_t targetId = data.targetId;
		BattleMoveObjectView * targetView = getMoveObjectView(targetId);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		if (attacker && targetView)
		{
			CCPoint targetPos = targetView->getPosition();
			CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId,  data.data1, delay);
			pEffect->setAnchorPoint(ccp(0, 0));
			Size contentSize = targetView->getContentSize();
			CCPoint effPos = ccp(0.0f, contentSize.height*0.3f);
			pEffect->setPosition(effPos);
			targetView->addChild(pEffect, 10);
			pEffect->setAutoReleaseWhenFinish(true);
			pEffect->setintervalTime(1.0f);
			pEffect->setAttacker(attacker);
			pEffect->setIntervalHandler(std::bind(&BattleSceneView::account, this, targetPos, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
		}
	}
	
}

void BattleSceneView::addWhirlFire(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStrCfg = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStrCfg.empty())
	{
		bool isFront = true;
		std::string effectStr = effectStrCfg;
		std::vector<std::string> effectStrVec = split(effectStrCfg, ";");
		if (effectStrVec.size() == 2)
		{
			isFront = false;
			effectStr = effectStrVec[1];
		}

		const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
		float delay = skillPty.skillEffectFrontDelay[0];
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		BattleMoveObjectView * attackerView = getMoveObjectView(attackerId);

		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());

		std::set<uint16_t> targets;
		skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);
 
		for(auto iter = targets.begin(); iter != targets.end(); ++iter)
		{
			uint16_t targetId = *iter;
			if (isFront)
			{
				BattleMoveObject * targetObj = m_model->getMoveObject(targetId);
				PixelPoint pixpos = targetObj->getPixelPosition();;
				cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
				skill::SpecialFxData dataAdapt;
				dataAdapt = data;
				dataAdapt.targetId = targetObj->getId();
				addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, false);	
			}
			else
			{				
				BattleMoveObjectView * targetView = getMoveObjectView(targetId);
				if (targetView)
				{
					CCPoint targetPos = targetView->getPosition();
					CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId,  data.data1, delay);
					pEffect->setAnchorPoint(ccp(0, 0));
					Size contentSize = targetView->getContentSize();

					if (targetView->getParent())
					{
						targetView->getParent()->addChild(pEffect, 0);
					}
					else
					{
						assert(false);
					}
					pEffect->setPosition(targetView->getPosition());
					pEffect->setIsPosRefreshWithAtker(false);
					pEffect->setAutoReleaseWhenFinish(true);
					pEffect->setintervalTime(1.0f);
					pEffect->setAttacker(attacker);
					pEffect->setIntervalHandler(std::bind(&BattleSceneView::account, this, targetPos, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
				}	
			}
			
		}
        
        skill::doWhirlFireBuff(targets, skillInfo, data.data2);
	}
}

void BattleSceneView::addNothingnessSkill(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		BattleMoveObjectView * attackerView = getMoveObjectView(attackerId);
		if (attacker==nullptr)
		{
			return;
		}
		float skillTimePlus = data.data5+0.1f;
		attacker->setLogicState(BattleObject::kLogicContinueMag);
		attacker->setState(BattleObject::kIdle);

		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		uint16_t targetId = data.targetId;	

		CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId, skillTimePlus, 0.0f);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(ccp(0, 0));
		attackerView->addChild(pEffect, 10, skill::kNothingnessEffTag);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::nothingnessSkillRemove, this, position, attacker, skillInfo, data));

		std::vector<uint16_t> targetsVec;						
		BattleMoveObjectView * targetView = getMoveObjectView(targetId);
		if (targetView)
		{			
			attackerView->setSkillNihilityTarget(targetId);
			targetsVec.push_back(targetId);
			CCPoint targetPos = targetView->getPosition();
			CustomEffectForever *pEffectTarget= CustomEffectForever::create(customEffectId,  skillTimePlus, 0.0f);
			pEffectTarget->setAnchorPoint(ccp(0, 0));
			pEffectTarget->setPosition(ccp(0, 0));
			targetView->addChild(pEffectTarget, 10, skill::kNothingnessEffTag);
			nothingnessAccount(targetPos, attacker, skillInfo, data, true, true);
			pEffect->setintervalTime(1.0f);			
			pEffect->setIntervalHandler(std::bind(&BattleSceneView::nothingnessAccount, this, targetPos, attacker, skillInfo, data, true, true));
		}
			
		if (targetsVec.empty())
		{
			return;
		}
		targetsVec.push_back(attackerId);
		LightningAction *la = LightningAction::create(attacker, targetsVec, CCLighting::kLightning, 0, std::bind(&BattleSceneView::lightingKeepFun, this, targetsVec, attacker));
		addChild(la, 10);
		la->setTag(skill::kNothingnessLightingTag + attackerId);		
	}
}

void BattleSceneView::lightingKeepFun(std::vector<uint16_t> &targetsVec, BattleMoveObject* attacker)
{
	uint16_t attackerId = attacker->getId();
	LightningAction *la = dynamic_cast<LightningAction *>(getChildByTag(skill::kNothingnessLightingTag + attackerId));
	if (la)
	{
		la->removeFromParent();
		for(auto iter = targetsVec.begin(); iter != targetsVec.end();)
		{
			uint16_t targetId = *iter;
			if (m_model->getMoveObject(targetId))
			{
				++iter;
			}	
			else
			{
				targetsVec.erase(iter);
				if (targetsVec.size() < 2)
				{
					return;
				}
			}
		}
		la = LightningAction::create(attacker, targetsVec, CCLighting::kLightning, 0, std::bind(&BattleSceneView::lightingKeepFun, this, targetsVec, attacker));
		addChild(la, 10);
		la->setTag(skill::kNothingnessLightingTag+ attackerId);
	}
}

void BattleSceneView::nothingnessAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt)
{
	uint16_t attackerId = attacker->getId();
	cocos2d::CCPoint usePt = pt;

	std::set<uint16_t> targets;	
	targets.insert(data.targetId);

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	handleFxBuff(attacker, skillLevelId, targets, false);
	BattleMoveObject * targeter = m_model->getMoveObject(data.targetId);
	if (targeter)
	{
		attacker->imbibition(targeter, data.data1, static_cast<int>(data.data2), data.data3, data.data4);
	}	
}

void BattleSceneView::nothingnessSkillRemove(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{	
	uint16_t attackerId = attacker->getId();
	BattleMoveObjectView * targetView = getMoveObjectView(data.targetId);
	if (targetView)
	{
		targetView->removeChildByTag(skill::kNothingnessEffTag);
		LightningAction *la = dynamic_cast<LightningAction *>(getChildByTag(skill::kNothingnessLightingTag + attackerId));
		if (la)
		{
			la->removeFromParent();
		}
	}	

	if (nullptr != attacker)
	{		
		attacker->setState(BattleObject::kSufContinueMagAtk);
		BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
		if (attackerView)
		{
			attackerView->setSkillNihilityTarget(0);
			attackerView->removeChildByTag(skill::kNothingnessEffTag);
		}		
	}
}

void BattleSceneView::addSnowstorm(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));	
	if (!effectStr.empty())
	{
		float singTime = SKILL_SING_TIME(skillInfo.skill_id);
		if (singTime > 0)  //持续施法
		{
			attacker->setLogicState(BattleObject::kLogicContinueMag);
			attacker->setState(BattleObject::kIdle);
		}

		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 4);
		int customEffectId = atoi(vec[3].c_str());
		CustomEffectRandom *pEffect = CustomEffectRandom::create(customEffectId,  data.data2, m_map, data.data1);
		pEffect->setAttackerId(attackerId);
		pEffect->setAttackerSkillId(skillInfo.skill_id);
		pEffect->setAttackerSkillLevel(skillInfo.level);
		pEffect->setIsPercentToDoAi(true);
		pEffect->setAiPercent(1000);
		pEffect->setAnchorPoint(ccp(0, 0));
		PixelPoint pixPos = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x,data.targetPos.y);	
		pEffect->setPosition(ccp(pixPos.x,pixPos.y));
		m_map->addChild(pEffect, 10, skill::kSnowstormEffcTag + attackerId);
		pEffect->setAutoReleaseWhenFinish(false);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::snowstormRemoveAccount, this, position, attacker, skillInfo, data));
		pEffect->setHittingFrameHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::snowstormRemoveAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	float singTime = SKILL_SING_TIME(skillInfo.skill_id);
	if (singTime > 0)  //持续施法
	{		
		attacker->setState(BattleObject::kSufContinueMagAtk);
	}	
	else  // 非持续施法
	{
		uint16_t attackerId = attacker->getId();
		BattleSceneView::getCurrentSceneView()->removeChildByTag(skill::kSnowstormEffcTag + attackerId);
	}	
}

void BattleSceneView::addFountainPartake(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	BattleMoveObject * attackerObj = m_model->getMoveObject(attackerId);
	if (!effectStr.empty() && attackerObj)
	{
		attackerObj->setState(BattleObject::kIdle);
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		CustomEffectOnce *pEffect = CustomEffectOnce::create(customEffectId,  data.data1);
		pEffect->setAnchorPoint(ccp(0, 0));
		CCPoint attckerGridPos = ccp(attackerObj->getGridPosition().x, attackerObj->getGridPosition().y);
		float offsetPos = 5;
		if (attackerObj->getParty() == kEnemyParty)
		{
			offsetPos = -offsetPos;
		}
		CCPoint readAttckGridPos = ccp(attckerGridPos.x, attckerGridPos.y + offsetPos);
		PixelPoint pixPos = GridUtil::sharedGridUtil().floatGridToPix(readAttckGridPos.x,readAttckGridPos.y);	
		CCPoint realPixPos = ccp(pixPos.x, pixPos.y);
		pEffect->setPosition(realPixPos);
		addChild(pEffect, 10, skill::kFountainPartakeEffcTag+attackerId);
		pEffect->setAutoReleaseWhenFinish(false);
		pEffect->setAttacker(attackerObj);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::fountainPartakeRemoveAccount, this, realPixPos, attackerObj, skillInfo, data, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::fountainPartakeRemoveAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	account(pt, attacker, skillInfo, data, true, true, calcHurtAttackProp);	
	removeChildByTag(skill::kFountainPartakeEffcTag + attacker->getId());
}

void BattleSceneView::addBombEff(BattleMoveObject * attackerObj, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		CustomEffectOnce *pEffect = CustomEffectOnce::create(customEffectId);
		pEffect->setAnchorPoint(ccp(0, 0));
		const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
		float radius = v[0] * 0.5f;
		if (data.type == skill::kLightningStrikeSheep)
		{
			radius = data.data2;
		}
		pEffect->setPosition(position);
		addChild(pEffect, 10);
		pEffect->setAutoReleaseWhenFinish(true);
		pEffect->setAttacker(attackerObj);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::account, this, position, attackerObj, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::addBigEnegyBall(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	BattleMoveObject * attackerObj = m_model->getMoveObject(attackerId);
	if (!effectStr.empty() && attackerObj)
	{
		attackerObj->setLogicState(BattleObject::kLogicContinueMag);
		attackerObj->setState(BattleObject::kIdle);
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		CustomEffectOnce *pEffect = CustomEffectOnce::create(customEffectId,  5);
		pEffect->setAnchorPoint(ccp(0, 0));
		CCPoint attckerGridPos = ccp(attackerObj->getGridPosition().x, attackerObj->getGridPosition().y);
		const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
		float radius = v[0] * 0.5f;
		float offsetPos = 5 + radius;
		if (attackerObj->getParty() == kEnemyParty)
		{
			offsetPos = -offsetPos;
		}

		CCPoint readAttckGridPos = ccp(attckerGridPos.x, attckerGridPos.y + offsetPos);
		PixelPoint pixPos = GridUtil::sharedGridUtil().floatGridToPix(readAttckGridPos.x,readAttckGridPos.y);	
		CCPoint realPixPos = ccp(pixPos.x, pixPos.y);
		pEffect->setPosition(realPixPos);
		addChild(pEffect, 10, skill::kBigEnergyEffcTag+attackerId);
		pEffect->setAutoReleaseWhenFinish(false);
		pEffect->setAttacker(attackerObj);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::bigEnergyBallRemoveAccount, this, realPixPos, attackerObj, skillInfo, data, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::bigEnergyBallRemoveAccount(const cocos2d::CCPoint &pt, BattleMoveObject * attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	account(pt, attacker, skillInfo, data, true, true, calcHurtAttackProp);	
	attacker->setState(BattleObject::kSufContinueMagAtk);
}

void BattleSceneView::doCatchSkillAttack(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attackerObj = m_model->getMoveObject(attackerId);
	if(!attackerObj)
	{
		return;
	}
	BattleMoveObjectView * attackView = getMoveObjectView(attackerId);
	if(!attackView)
	{
		return;
	}

	CCPoint atkGridPos = ccp(attackerObj->getGridPosition().x, attackerObj->getGridPosition().y);
	
	std::set<uint16_t> targets;
	skill::getTargetsWithSkillAi(&targets, attackerObj, skillInfo, atkGridPos);

	if (!targets.empty())
	{
		uint16_t targetId = -1;
		std::set<uint16_t>::iterator targetIter;
		for (targetIter = targets.begin(); targetIter != targets.end(); ++targetIter)
		{
			BattleMoveObject *targetObj = m_model->getMoveObject(*targetIter);
			if (targetObj)
			{
				targetId = *targetIter;
				break;				 
			}
		}
		if (targetId != -1)
		{
			targets.clear();
			targets.insert(targetId);
			getMoveObjectView(attackerId)->catchEnemyFrontMe(targetId);
			int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
			handleFxBuff(attackerObj, skillLevelId, targets);
			PixelPoint pix(static_cast<int16_t>(position.x), static_cast<int16_t>(position.y));
			BattleReport report = genSkillBattleReport(attackerObj, targets, skillLevelId, pix, nullptr);			
		}	
	}
}

void BattleSceneView::doTransformToSheep(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);	
	if (attckerView)
	{
		BattleMoveObject * attackObj = attckerView->getModel();
		CCPoint atkGridPos = ccp(attackObj->getGridPosition().x, attackObj->getGridPosition().y);
		std::set<uint16_t> targets;
		if (data.type == skill::kTransfiguration)
		{
			skill::getObjects(&targets, skillInfo, data, attackObj->getParty(), atkGridPos);	
		}
		else if (data.type == skill::kLightningStrikeSheep)
		{
			skill::getObjects(&targets, skillInfo, data, attackObj->getParty(), data.targetPos);	
		}
		
		if (!targets.empty())
		{
			std::set<uint16_t>::iterator targetIter;
			for (targetIter = targets.begin(); targetIter != targets.end(); ++targetIter)
			{
				BattleMoveObjectView *targetView = getMoveObjectView(*targetIter);
				if (targetView)
				{
					targetView->doTransform(skillInfo, data);
				}
			}
			if (data.type == skill::kTransfiguration)
			{
				int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
				handleFxBuff(attackObj, skillLevelId, targets);
				PixelPoint pix(static_cast<int16_t>(position.x), static_cast<int16_t>(position.y));
				BattleReport report = genSkillBattleReport(attackObj, targets, skillLevelId, pix, nullptr);			
			}			
		}
	}	
}

void BattleSceneView::doSheepAndThunderHurt(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{	
	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);	
	if (attckerView)
	{
		BattleMoveObject * attackObj = attckerView->getModel();	
		CCDelayTime *delaySheep = CCDelayTime::create(0.83f);		
		CCCallFuncND *doSheep =  CCCallFuncND::create(this, [=](void)
		{
			skill::SpecialFxData dataAdapt;
			dataAdapt.type = data.type;
			dataAdapt.data1 = data.data4;
			dataAdapt.data2 = data.data3;
			dataAdapt.pos = data.pos;
			dataAdapt.targetPos = data.targetPos;
			doTransformToSheep(attackerId, skillInfo, position, dataAdapt);
		});	

		TargetSelectMgr::theMgr().setMoveObject(attackObj);
		std::vector<cocos2d::CCPoint> targetPos = TargetSelectMgr::theMgr().selectSameScreenRandomPositions(TargetSelect::kTargetOpponent, 5);

		const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
		float hitDelay = skillPty.hitDelay;
		CCDelayTime *delayThunder = CCDelayTime::create(hitDelay);
		CCCallFuncND *doThunder = CCCallFuncND::create(this, [=](void)
		{
			for (uint32_t i = 0; i < targetPos.size(); ++i)
			{
				PixelPoint pixPos = GridUtil::sharedGridUtil().gridToPix(GridPosition((int16_t)targetPos[i].x, (int16_t)targetPos[i].y));
				CCPoint targetPos = ccp(pixPos.x, pixPos.y);
				addBombEff(attackObj, skillInfo, targetPos, data);
			}
		});	

		CCSequence * sheepSequence = CCSequence::create(delaySheep, doSheep, nullptr);
		CCSequence * thunderSequence = CCSequence::create(delayThunder, doThunder, nullptr);
		CCSpawn * spawnAction = CCSpawn::createWithTwoActions(sheepSequence, thunderSequence);
		runAction(spawnAction);	
	}
}

void BattleSceneView::doThunderAttckInterval(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleScene::IDMoveObject enemyObj = m_model->getEnemyMoveObjects();
	BattleScene::IDMoveObject::iterator enemyItr = enemyObj.begin();
	for ( ; enemyItr != enemyObj.end(); ++enemyItr)
	{
		uint16_t enemyId = enemyItr->first;
		BattleMoveObject *enemy = enemyItr->second;
		enemy->setSilent(true);
		BattleMoveObjectView * enemyView = getMoveObjectView(enemyId);
		if(enemyView)
		{
			enemyView->setViewStop(true);
		}
	}

	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);	
	if (attckerView)
	{
		attckerView->setSkillUseViewStop(true);

		BattleMoveObject * attackObj = attckerView->getModel();	
		attackObj->setLogicState(BattleObject::kLogicContinueMag);
		attackObj->setState(BattleObject::kIdle);

		int attackerEfff = skill::kLightingPrisonAtkEffId;
		CustomEffectForever *pEffect = CustomEffectForever::create(attackerEfff, data.data1);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setAutoReleaseWhenFinish(true);
		pEffect->setintervalTime(1.0f);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::thunderAttckFinish, this, attacker, 0, skillInfo, data));
		attckerView->addChild(pEffect, 10);

		std::set<uint16_t> targets;
		skill::getTargetsWithSkillAi(&targets, attackObj, skillInfo, position);

		for (std::set<uint16_t>::iterator targetItr = targets.begin(); targetItr != targets.end(); ++targetItr)
		{
			CCPoint targetPos = getMoveObjectView(*targetItr)->getPosition();
			addThunderEff(attackerId, *targetItr, skillInfo, targetPos, data);
		}
	}
}

void BattleSceneView::addThunderEff(uint16_t attackerId, uint16_t targeterId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	BattleMoveObject * targeterObj = m_model->getMoveObject(targeterId);	
	if (!effectStr.empty() && targeterObj)
	{
		BattleMoveObjectView * targetView = getMoveObjectView(targeterId);
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId, data.data1);
		pEffect->setTag(skill::kThunderAtkEffTag + attackerId);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setAutoReleaseWhenFinish(true);
		pEffect->setintervalTime(1.0f);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		pEffect->setAttacker(attacker);
		pEffect->setIntervalHandler(std::bind(&BattleSceneView::thunderAttckAccount, this, position, attacker, targeterId, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
		targetView->addChild(pEffect, 10);
	}
}

void BattleSceneView::thunderAttckAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, uint16_t targeterId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleMoveObject * targeterObj = m_model->getMoveObject(targeterId);
	if (targeterObj == nullptr)
	{
		return;
	}

	std::set<uint16_t> targets;	
	targets.insert(targeterId);

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);

	skill::doSelfFx(BattleScene::kMoveObj, attacker, nullptr, nullptr, skillLevelId);

	skill::doBuff(m_model, attacker, targets, skillLevelId, TargetSelect::kTargetOpponent);	
	genSkillBattleReport(attacker, targets, skillLevelId, PixelPoint((int16_t)pt.x, (int16_t)pt.y), calcHurtAttackProp);			
}

void BattleSceneView::thunderAttckFinish(BattleMoveObject *attacker, uint16_t targeterId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	BattleScene::IDMoveObject enemyObj = m_model->getEnemyMoveObjects();
	BattleScene::IDMoveObject::iterator enemyItr = enemyObj.begin();
	for ( ; enemyItr != enemyObj.end(); ++enemyItr)
	{
		uint16_t enemyId = enemyItr->first;
		BattleMoveObject *enemy = enemyItr->second;
		enemy->setSilent(false);
		BattleMoveObjectView * enemyView = getMoveObjectView(enemyId);
		if(enemyView)
		{
			enemyView->setViewStop(false);
		}
	}

	uint16_t attackerId = attacker->getId();
	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);	
	if (attckerView)
	{
		attckerView->setSkillUseViewStop(false);
	}	
	attacker->setState(BattleObject::kSufContinueMagAtk);
}

void BattleSceneView::doLiveOrNotToLiveSkill(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);	
	if (attckerView)
	{
		BattleMoveObject * attackObj = attckerView->getModel();	
		
		attackObj->setLogicState(BattleObject::kLogicContinueMag);
		attackObj->setState(BattleObject::kIdle);

		TargetSelectMgr::theMgr().setMoveObject(attackObj);
		std::vector<cocos2d::CCPoint> targetPos = TargetSelectMgr::theMgr().selectSameScreenRandomPositions(TargetSelect::kTargetOpponent, 5);

		for (uint32_t i = 0; i < targetPos.size(); ++i)
		{
			CCPoint targetGridPos = targetPos[i];
			addLiveOrNotToLiveDoorEff(attackerId, 0, skillInfo, targetGridPos, data);
		}
		addLiveOrNotToLiveFountainEff(attackerId, 0, skillInfo, data.targetPos, data);
	}
}

void BattleSceneView::addLiveOrNotToLiveFountainEff(uint16_t attackerId, uint16_t targeterId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject * attackObj = m_model->getMoveObject(attackerId);

	int customEffectId = skill::kLiveOrDieFountainControlEffId;
	float intervalTime = data.data5/data.data6;
	CustomEffectForever *pControlEffect = CustomEffectForever::create(customEffectId, data.data5+0.1f);
	pControlEffect->setAnchorPoint(ccp(0, 0));
	pControlEffect->setAutoReleaseWhenFinish(true);
	pControlEffect->setintervalTime(intervalTime);
	PixelPoint pixPoint = GridUtil::sharedGridUtil().floatGridToPix(position.x, position.y);
	pControlEffect->setPosition(ccp(pixPoint.x, pixPoint.y));
	pControlEffect->setIntervalHandler(std::bind(&BattleSceneView::liveOrNotToLiveAccount, this, position, attackObj, targeterId, skillInfo, data, true, true));
	pControlEffect->setFinishedHandler(std::bind(&BattleSceneView::liveOrNotToLiveFinish, this, attackerId, 0, skillInfo, data));
	addChild(pControlEffect, 10);	
}

void BattleSceneView::addLiveOrNotToLiveDoorEff(uint16_t attackerId, uint16_t targeterId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{	
	int customEffectId = skill::kLiveOrDieDoorEffId;
	CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId,data.data5+0.1f);
	pEffect->setAnchorPoint(ccp(0, 0));
	PixelPoint pixPos = GridUtil::sharedGridUtil().floatGridToPix(position.x, position.y);
	pEffect->setPosition(ccp(pixPos.x, pixPos.y));	
	pEffect->setAutoReleaseWhenFinish(true);
	pEffect->setTag(skill::kLiveOrDieDoorTag + attackerId);
	//pEffect->setFinishedHandler(std::bind(&BattleSceneView::liveOrNotToLiveFinish, this, attackerId, 0, skillInfo, data));
	m_map->addChild(pEffect, -1);	
}

void BattleSceneView::liveOrNotToLiveHurtAccount(const cocos2d::CCPoint &pt, BattleObject *attackerObj, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt, CalcHurtAttackProp *calcHurtAttackProp)
{
	account(pt, attackerObj, skillInfo, data, isForceShake, isCalcHurt, calcHurtAttackProp);
	
	CustomEffectForever * doorEff = dynamic_cast<CustomEffectForever *>(m_map->getChildByTag(skill::kLiveOrDieDoorTag + attackerObj->getId()));
	if (doorEff)
	{
		float doorRadius = data.data1;
		float soldierHpDef = data.data2;
		float generalHpDef = data.data3;
		CCPoint pixPos = doorEff->getPosition();
		CCPoint gridPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((int16_t)pixPos.x, (int16_t)pixPos.y));
		TargetSelectMgr::theMgr().setRange(gridPos, doorRadius);
		std::set<uint16_t> targets = TargetSelectMgr::theMgr().selectMoveObjByHpPercent(TargetSelect::kTargetOpponent, soldierHpDef, generalHpDef);
		TargetSelectMgr::theMgr().clearRange();				

		for (std::set<uint16_t>::iterator targetItr = targets.begin(); targetItr != targets.end(); ++targetItr)
		{
			BattleMoveObjectView * targetView = getMoveObjectView(*targetItr);
			if (targetView)
			{
				BattleMoveObject* targetObj = targetView->getModel();
				if (targetObj->isBoss())
				{
					float bossHurt = data.data4;
					targetObj->setHp(static_cast<int>(targetObj->getHp() - bossHurt));
				}
				else
				{
					bool isLiveOrDieDooring = targetView->getIsLiveOrDieDooring();
					if (!isLiveOrDieDooring)
					{
						//此处有一个HARDCODE,需要调整
						CCPoint topCenter = ccpAdd(doorEff->getPosition(), ccp(0.0f, 300.0f));
						targetView->onLiveOrNotToLiveDoor(topCenter);
					}					
				}
			}			
		}
	}
	
}

void BattleSceneView::liveOrNotToLiveAccount(const cocos2d::CCPoint &pt, BattleMoveObject * attackObj, uint16_t targeterId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt)
{
	TargetSelectMgr::theMgr().setMoveObject(attackObj);
	std::vector<cocos2d::CCPoint> targetPos = TargetSelectMgr::theMgr().selectSameScreenRandomPositions(TargetSelect::kTargetOpponent, 1);
	if (!targetPos.empty())
	{
		int oneFoutainId = skill::kLiveOrDieFountainEffId;;
		CustomEffectOnce *pEffect = CustomEffectOnce::create(oneFoutainId);
		pEffect->setAnchorPoint(ccp(0, 0));		
		pEffect->setAutoReleaseWhenFinish(true);
		CCPoint fountainGridPos = *targetPos.begin();
		PixelPoint pixPoint = GridUtil::sharedGridUtil().floatGridToPix(fountainGridPos.x, fountainGridPos.y);
		CCPoint fountainPixPos = ccp(pixPoint.x, pixPoint.y);
		pEffect->setPosition(fountainPixPos);	
		pEffect->setAttacker(attackObj);
		pEffect->setFinishedHandler(std::bind(&BattleSceneView::liveOrNotToLiveHurtAccount, this, fountainPixPos, attackObj, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
		addChild(pEffect, 10);
	}
	else
	{
		ERROR_MSG("--warning! liveOrDie Door Fountain no target!--");	
	}
}

void BattleSceneView::liveOrNotToLiveFinish(uint16_t attackerId, uint16_t targeterId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	BattleMoveObjectView * attckerView = getMoveObjectView(attackerId);
	if (attckerView)
	{
		BattleMoveObject * attacker = attckerView->getModel();		
		attacker->setState(BattleObject::kSufContinueMagAtk);
	}
}

void BattleSceneView::addShockWaveAttack(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);

	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
		float delay = skillPty.skillEffectFrontDelay[0];
		float hitScope = data.data1;
		int hitTime = static_cast<int>(data.data2);
		cocos2d::CCPoint atkerGridPos = ccp((float)attacker->getGridPosition().x, (float)attacker->getGridPosition().y);
		PixelPoint atkerPix = GridUtil::sharedGridUtil().floatGridToPix(atkerGridPos.x, atkerGridPos.y);
		cocos2d::CCPoint shockStartPixPos = ccp(atkerPix.x, atkerPix.y);
		if (data.type == skill::kTouchBeganShockWave) //使用目标位置作为冲击波起始点
		{
			if (data.targetPos.x != -1 && data.targetPos.x != -1)
			{
				PixelPoint tempPixPos = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
				shockStartPixPos = ccp(tempPixPos.x, tempPixPos.y);
			}
			else
			{
				assert(false);
			}
		}
		cocos2d::CCPoint targetGridPos = ccp(0, 0);
		cocos2d::CCPoint shockEndPixPos = ccp(0, 0);

		if (data.targetPos.x != -1 && data.targetPos.x != -1)
		{
			targetGridPos = data.targetPos;
		}
		else
		{
			if (attacker->getParty() == kFriendParty)
			{
				targetGridPos = ccpAdd(targetGridPos, ccp(0,1));
			}
			else
			{
				targetGridPos = ccpAdd(targetGridPos, ccp(0,-1));
			}
		}
		CCPoint targetPixPos = calcDestPixelPosition(atkerGridPos, targetGridPos, 0, hitScope);

		if (data.type == skill::kTouchBeganShockWave) //使用目标位置作为冲击波起始点
		{
			targetPixPos = calcDestPixelPosition(atkerGridPos, targetGridPos, 0, 99);
			targetPixPos = calcDestPixelPosition(data.targetPos, GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((uint16_t)targetPixPos.x, (uint16_t)targetPixPos.y)), 0, hitScope);
		}
		shockEndPixPos = ccp((float)targetPixPos.x, (float)targetPixPos.y);

		

		ShockWaveEffect * pEffect = ShockWaveEffect::create(skillInfo.skill_id, skill::getSkillLvId(skillInfo.skill_id, skillInfo.level), hitTime, shockStartPixPos, shockEndPixPos, delay, getMoveObjectView(attackerId)->canSetFlip());
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(shockStartPixPos);
		addChild(pEffect, 10, skill::kShockWaveEffcTag+attackerId);
		pEffect->setAttacker(attacker);
		pEffect->setAccountHandler(std::bind(&BattleSceneView::account, this, _1, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::addRandomShootAttack(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	float singTime = SKILL_SING_TIME(skillInfo.skill_id);

	if (singTime > 0) //这个技能可以作为持续施法，如果大于0就是持续施法，这里开始设置持续施法
	{
		attacker->setLogicState(BattleObject::kLogicContinueMag);
		attacker->setState(BattleObject::kIdle);
	}	
	PixelPoint pixpos = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
	cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
	cocos2d::CCPoint atkerGridPos = ccp((float)attacker->getGridPosition().x, (float)attacker->getGridPosition().y);
	const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);

	int times = (int)(data.data2/data.data1);
	assert(times >= 1);
	bool isAccount = (SKILL_HIT_TYPE(skillInfo.skill_id) == kDest);
	if(times == 1)
	{
		addBulletEffect(attackerId, skillInfo, frontTargetPos, data, isAccount);
	}
	else
	{
		float interval = data.data1;
		int randomAngle = (int) data.data5;
		int rnd = getRandNum_(0, randomAngle);

		CCPoint zeroDegreePixTarget = calcDestPixelPosition(atkerGridPos, data.targetPos, CC_DEGREES_TO_RADIANS(-(randomAngle/2)), static_cast<float>(v[0]));
		CCPoint zeroTargetGridPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint((int16_t)zeroDegreePixTarget.x, (int16_t)zeroDegreePixTarget.y));

		CCPoint randomDegreePixTarget = calcDestPixelPosition(atkerGridPos, zeroTargetGridPos, CC_DEGREES_TO_RADIANS(rnd), static_cast<float>(v[0]));

		CCFiniteTimeAction *action = CCCallFuncND::create(this, std::bind(&BattleSceneView::addBulletEffect, this, attackerId, skillInfo, randomDegreePixTarget, data, isAccount));
		for(int i = 1; i < times; ++i)
		{
			rnd = getRandNum_(0, randomAngle);
			randomDegreePixTarget = calcDestPixelPosition(atkerGridPos, zeroTargetGridPos, CC_DEGREES_TO_RADIANS(rnd), static_cast<float>(v[0]));			
			CCDelayTime *delay = CCDelayTime::create(interval);
			action = CCSequence::create(action, delay, CCCallFuncND::create(this, std::bind(&BattleSceneView::addBulletEffect, this, attackerId, skillInfo, randomDegreePixTarget, data, isAccount)), nullptr);
		}

		if (singTime > 0) //这个技能可以作为持续施法，如果大于0就是持续施法,这里是结束持续施法时要做的逻辑
		{
			CCDelayTime *delay = CCDelayTime::create(interval);
			action = CCSequence::create(action, delay, CCCallFuncND::create(this, [=](void) ->void
			{
				if (m_model->getMoveObject(attackerId))
				{					
					m_model->getMoveObject(attackerId)->setState(BattleObject::kSufContinueMagAtk);
				}				
			}), nullptr);

		}
		action->setTag(skill::kRandomShootAttackEffcTag + attackerId);
		runAction(action);
	}
}

void BattleSceneView::addShootToSomeTargets(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleObjectView *attackerView = getObjectView(attackerId);
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);

	std::set<uint16_t> targets;
	skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, position);

	
	std::set<uint16_t>::iterator iterTaregetGen = targets.begin();
	for (; iterTaregetGen != targets.end(); iterTaregetGen++)
	{
		uint16_t targetId = *iterTaregetGen;
		
		BattleMoveObject * targetObj = m_model->getMoveObject(targetId);
		if (targetObj)
		{
			PixelPoint pixpos = targetObj->getPixelPosition();;
			cocos2d::CCPoint frontTargetPos = ccp((float)pixpos.x, (float)pixpos.y);
			bool isAccount = (SKILL_HIT_TYPE(skillInfo.skill_id) == kDest);	
			skill::SpecialFxData dataAdapt;
			dataAdapt.type = skill::kMultipleTargetBullet;
			dataAdapt.data1 = 1;
			dataAdapt.targetId = targetObj->getId();
			addBulletEffect(attackerId, skillInfo, frontTargetPos, dataAdapt, isAccount);		
		};
	} 	
}

void BattleSceneView::addIceTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data1, position, m_map);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(position);
		pEffect->setAttacker(attacker);
		pEffect->setHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, false, false, pEffect->getCalcHurtAttackProp()));
		pEffect->setFinishHandler(std::bind(&BattleSceneView::iceAccount, this, position, attacker, skillInfo, data, pEffect->getCalcHurtAttackProp()));
		addChild(pEffect, 10);
	}
}

void BattleSceneView::addSimpleAccountTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		std::vector<std::string> vec = split(effectStr, "/");
		assert(vec.size() == 3);
		int customEffectId = atoi(vec[2].c_str());
		switch(data.type)
		{
		case skill::kAbsorbHpTrap:
			{
				CustomEffectRandom *pEffect = CustomEffectRandom::create(customEffectId,  data.data2, m_map, data.data1);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(position);
				m_map->addChild(pEffect, 10);
				pEffect->setAutoReleaseWhenFinish(true);
				pEffect->setAttacker(attacker);
				pEffect->setHittingFrameHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
				break;
			}
		case skill::kTrapWall:
		case skill::kTrapWallAndIntervalTime:
			{
				CustomEffectForever *pEffect = CustomEffectForever::create(customEffectId,  data.data2, data.data1);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(position);
				m_map->addChild(pEffect, 10);
				pEffect->setAutoReleaseWhenFinish(true);
				if (data.type == skill::kTrapWallAndIntervalTime)
				{
					pEffect->setintervalTime(data.data3);
				}
				else
				{
					pEffect->setintervalTime(1.0f);
				}				
				pEffect->setAttacker(attacker);
				pEffect->setIntervalHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
				break;
			}
		default:
			{
				assert(false);
				break;
			}
		}
	}
}

void BattleSceneView::addHellTrap(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data3, data.data1, position, m_map);
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		pEffect->setAnchorPoint(ccp(0, 0));
		pEffect->setPosition(position);
		pEffect->setAttacker(attacker);
		pEffect->setHandler(std::bind(&BattleSceneView::hellTrapAccount, this, position, attackerId, skillInfo, data));
		addChild(pEffect, 10);
	}
} 

void BattleSceneView::addFireBull(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	const Size &size = CCDirector::sharedDirector()->getWinSize();
	const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
	std::string bulletRes = std::string(SKILL_BULLET_RES(skillInfo.skill_id));
	if (!bulletRes.empty())
	{
		IntervalAnimationDisplayNode *bulletSp = IntervalAnimationDisplayNode::create(bulletRes.c_str()
			, false);
		bulletSp->setScaleValue(skillPty.bulletScale);
		CCPoint start(-getPositionX(), -getPositionY() + size.height * 0.5f);
		BulletEffect *bullet = BulletEffect::create(attackerId, 
			start, 
			position,
			bulletSp,
			skillPty.bulletDelay);
		bullet->setSpeed(skillPty.bulletSpeed / getScaleFactor());
		BattleMoveObject * attacker = getMoveObjectView(attackerId)->getModel();
		if (attacker)
		{
			bullet->setAttacker(attacker);
		}
		bullet->setAccountHandler(std::bind(&BattleSceneView::bulletAccount, this, _1, _2, _3, _4, _5, attackerId, skillInfo, data, bullet->getCalcHurtAttackProp()));
		bullet->setRotateMode(bulletRes.c_str());
		addChild(bullet, 10);

		const char *sound = SKILL_BULLET_MUSIC(skillInfo.skill_id);
		if(strcmp(sound, "") != 0)
		{
			bullet->setSound(sound);
		}
	}
}

void BattleSceneView::addOuterAttackSpecialFxImpl(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	std::string bulletStr = std::string(SKILL_BULLET_RES(skillInfo.skill_id));
	const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
	float hitDelay = skillPty.hitDelay;
	if (!bulletStr.empty())
	{
		bulletImpl(attackerId, skillInfo, position, data);
	}
	else
	{
		std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
		if (!effectStr.empty())
		{
			uint16_t targetid = 0;

			std::set<uint16_t> targets;
			if (data.targetId == 0)
			{
				skill::getTargetsWithSkillAi(&targets, attacker, skillInfo, data.targetPos);
			}
			else
			{
				targets.insert(data.targetId);
			}			
			
			if (!targets.empty())
			{
				targetid = (*targets.begin());
				BattleMoveObject *targeter = m_model->getMoveObject(targetid);
				if(!targeter)
				{
					return;
				}
				PixelPoint targetPix = targeter->getPixelPosition();
				CCPoint targetPos = ccp((float)targetPix.x, (float)targetPix.y);
				SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data1, targetPos, m_map);
				BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(targetPos);
				pEffect->setAttacker(attacker);
				m_map->addChild(pEffect, 10);
				CCDelayTime *delay = CCDelayTime::create(hitDelay);
				CCCallFuncND *hurtFun =  CCCallFuncND::create(this, std::bind(&BattleSceneView::accountForOuterSpecialFxImpl, this, position, attacker, targetid, skillInfo, data, true, true, pEffect->getCalcHurtAttackProp()));
				CCSequence *seqFocuEndLogic = CCSequence::create(delay, hurtFun, nullptr);
				runAction(seqFocuEndLogic);
			}		
		}
	}	
}

void BattleSceneView::accountForOuterSpecialFxImpl(const cocos2d::CCPoint &pt, BattleObject *attackerObj, uint16_t target_id, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleMoveObject * attacker = dynamic_cast<BattleMoveObject *>(attackerObj);	
	if (attacker == nullptr)
	{
		assert(false);
		return;
	}
	uint16_t attackerId = attacker->getId();
	cocos2d::CCPoint usePt = pt;
	PixelPoint pix(static_cast<int16_t>(usePt.x), static_cast<int16_t>(usePt.y));
	CCPoint grid = GridUtil::sharedGridUtil().pixToFloatGrid(pix);
	std::set<uint16_t> targets;
	targets.insert(target_id);

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	handleFxBuff(attacker, skillLevelId, targets, isCalcHurt);

	if(isCalcHurt)
	{
		genSkillBattleReport(attacker, targets, skillLevelId, pix, calcHurtAttackProp);	
	}
}

void BattleSceneView::addResourceEffect(const skill::SpecialFxData &data)
{
}

void BattleSceneView::addSkillHittingFrame(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data)
{
	std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
	if (!effectStr.empty())
	{
		BattleMoveObject * attacker = m_model->getMoveObject(attackerId);
		SkillEffectDisplay *effect = SkillEffectDisplay::create(skillInfo.skill_id, data.data2, data.data1, position, m_map);
		effect->setAnchorPoint(ccp(0, 0));
		effect->setPosition(position);
		addChild(effect, 10);
		effect->setAttacker(attacker);
		effect->setHittingFrameHandler(std::bind(&BattleSceneView::account, this, position, attacker, skillInfo, data, true, true, effect->getCalcHurtAttackProp()));
	}
}

void BattleSceneView::bulletImpl(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &targetPosition, const skill::SpecialFxData &data)
{
	int times = static_cast<int>(data.data4);
	assert(times >= 1);
	bool isAccount = (SKILL_HIT_TYPE(skillInfo.skill_id) == kDest);
	if(times == 1)
	{
		addBulletEffect(attackerId, skillInfo, targetPosition, data, isAccount);
	}
	else
	{
		float interval = data.data5;
		CCFiniteTimeAction *action = CCCallFuncND::create(this, std::bind(&BattleSceneView::addBulletEffect, this, attackerId, skillInfo, targetPosition, data, isAccount));
		for(int i = 1; i < times; ++i)
		{
			CCDelayTime *delay = CCDelayTime::create(interval);
			action = CCSequence::create(action, delay, CCCallFuncND::create(this, std::bind(&BattleSceneView::addBulletEffect, this, attackerId, skillInfo, targetPosition, data, isAccount)), nullptr);
		}
		runAction(action);
	}
}

void BattleSceneView::addBulletEffect(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &position, const skill::SpecialFxData &data, bool isAccount)
{
	const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
	float bulletDelay = skillPty.bulletDelay;
	BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);

	if ((attackerView == nullptr))  //角色死掉的时候，不释放子弹
	{
		return;
	}

	std::string bulletRes = std::string(SKILL_BULLET_RES(skillInfo.skill_id));
	if (!bulletRes.empty())
	{
		PixelPoint attackerPos = attackerView->getModel()->getPixelPosition();
		int attackerToward = attackerView->getModel()->getToward();
		CCPoint pt = attackerView->getEffectHangPointPos(skillPty.bulletStartPoint[getIndexWithTowardByStartPoint(attackerToward)], shouldSetFilp(attackerToward));

		int bulletNum = 0;
		switch(data.type)
		{
		case skill::kSectorIce:
			{
				bulletNum = static_cast<int>(data.data4);
				break;
			}
		case skill::kChainCureBullet:
		case skill::kPyrosphere:
			{
				bulletNum = 1;
				break;
			}
		default:
			{
				bulletNum = static_cast<int>(data.data1);
			}
		}

		assert(bulletNum % 2 == 1);
		static int offset[] = {0, -1, 1, -2, 2, -3, 3, -4, 4, -5, 5};
		float angleDegree = data.data3 / bulletNum;
		
		float minAtkAreaRadius =  sqrtf(static_cast<float>(pt.x*pt.x + pt.y*pt.y));
		bool isInMinAtkArea = isInCircle(ccp(position.x, position.y),ccp(attackerPos.x, attackerPos.y),minAtkAreaRadius);
		for(int i = 0; i < bulletNum; ++i)
		{
			IntervalAnimationDisplayNode *bulletSp = IntervalAnimationDisplayNode::create(bulletRes.c_str()
				, false);
			bulletSp->setScaleValue(skillPty.bulletScale);
			BulletEffect *bullet = nullptr;
			CCPoint startPos(attackerPos.x, attackerPos.y);
			if(isAccount)
			{
				float nowRadians = CC_DEGREES_TO_RADIANS(offset[i] * angleDegree);
				CCPoint finalTargetPos = ccp(position.x, position.y);
				calcBulletEffectDest(skillInfo, startPos, finalTargetPos, nowRadians, attackerView);
				float al = angle(startPos, finalTargetPos);
				float sin_ = std::fabs(sin(CC_DEGREES_TO_RADIANS(al)));
				float scale = 1.0f - sin_ * 0.5f;
				//bulletSp->setScaleValue(scale*skillPty.bulletScale);

				bullet = BulletEffect::exactDest(attackerId, 
					startPos,
					finalTargetPos,
					bulletSp,
					bulletDelay);
				BattleMoveObject * attacker = dynamic_cast<BattleMoveObject *>(attackerView->getModel());
				CalcHurtAttackProp * attackerProp = nullptr;
				if (attacker)
				{
					bullet->setAttacker(attacker);
					attackerProp = bullet->getCalcHurtAttackProp();
				}
				if (data.type == skill::kBullet || data.type == skill::kSectorIce)
				{
					bullet->setAccountHandler(std::bind(&BattleSceneView::bulletAccount, this, _1, _2, _3, _4, _5, attackerId, skillInfo, data, attackerProp), (int)data.data6);
				}
				else
				{
					bullet->setAccountHandler(std::bind(&BattleSceneView::bulletAccount, this, _1, _2, _3, _4, _5, attackerId, skillInfo, data, attackerProp));
				}
			}
			else
			{
				BattleObjectView * targetView = getObjectView(data.targetId);
				if (targetView == nullptr)
				{
					return;
				}
				float al = angle(startPos, pt);
				float sin_ = std::fabs(sin(CC_DEGREES_TO_RADIANS(al)));
				float scale = 1.0f - sin_ * 0.3f;
				//bulletSp->setScaleValue(scale*skillPty.bulletScale);
				startPos = ccpAdd(startPos, pt);
				float heightOffset = targetView->getContentSize().height*0.5f;
				bullet = BulletEffect::create(attackerId, 
					startPos,
					ccp(0.0f, heightOffset),
					data.targetId,
					bulletSp,
					bulletDelay);

				if (isInMinAtkArea)
				{
					//打目标类技能，在最小范围内，不显示子弹
					bullet->setVisible(false);
				}

				BattleMoveObject * attacker = dynamic_cast<BattleMoveObject *>(attackerView->getModel());
				CalcHurtAttackProp * attackerProp = nullptr;
				if (attacker)
				{
					bullet->setAttacker(attacker);
					attackerProp = bullet->getCalcHurtAttackProp();
				}

				bool isNormalAttack = false;
				if (data.type == skill::kChainCureBullet || data.type == skill::kBombBullet
					|| data.type == skill::kMultipleTargetBullet || data.type == skill::kPyrosphere)
				{
					bullet->setHandler(std::bind(&BattleSceneView::onSpecialReachDest, this, skill::getSkillLvId(skillInfo.skill_id, skillInfo.level), _1, _2, attackerId, skillInfo, data, attackerProp));
				}
				else
				{
					bullet->setHandler(std::bind(&BattleSceneView::onBulletReachDest, this, skill::getSkillLvId(skillInfo.skill_id, skillInfo.level), _1, _2, attackerId, isNormalAttack, attackerProp));
				}				
			}
			int bulletZorder = skill::kBulletEffecZorder;
			int toward = calcToward(attackerView->getPosition(), position);
			switch(toward)
			{
			case BattleObject::kRightDown:
			case BattleObject::kLeftDown:
				{
					bulletZorder = skill::kBulletEffecCoverGeneralZorder;
					break;
				}
			}
			bullet->setSpeed(skillPty.bulletSpeed / getScaleFactor());
			bullet->setRotateMode(bulletRes.c_str());
			m_map->addChild(bullet, bulletZorder);

			const char *sound = SKILL_BULLET_MUSIC(skillInfo.skill_id);
			if(strcmp(sound, "") != 0)
			{
				bullet->setSound(sound);
			}
		}
	}
	else
	{
		assert(false && "bullet res is empty!");
	}
}

static Node *addPreReleaseaSkillCircle(BattleObject *object, const CCPoint &centerPos, int diameter)
{
	BattleSceneView *sceneView = BattleSceneView::getCurrentSceneView();
	BattleScene *scene = BattleScene::getCurrentScene();
	PixelPoint pos = GridUtil::sharedGridUtil().floatGridToPix(centerPos.x, centerPos.y);
	IntervalAnimationDisplayNode *node = IntervalAnimationDisplayNode::create("res/effects/general_release_skills_lock");
	node->setAnchorPoint(ccp(0.0f, 0.0f));
	node->setPosition(ccp(pos.x, pos.y));
	sceneView->getLayer()->addChild(node, 1);

	return node;
}

static int calcSkillDirection(const CCPoint &start, const CCPoint &end, float *rotateAngle)
{
	float al = angle(start, end);
	float perAngle = 360.0f / 16;
	float realAngle = (al + perAngle * 0.5f);
	int index = (int)(realAngle / perAngle);

	float standardAngle = perAngle * index;
	*rotateAngle = al - standardAngle;

	if (index > 15) index = 0;
	return index;
}

static const kmVec3 eye = { 0.0f, -0.04f, 0.1f };
static const kmVec3 center = { 0.0f, 0.0f, 0.0f };
static Node *addSkillDirection(BattleObject *object, const CCPoint &startPos, const CCPoint &endPos, const SkillInfo &skillInfo)
{
	static const std::string skillDirectionRes[] =
	{
		"res/effects/skill_line9",
		"res/effects/skill_line8",
		"res/effects/skill_line7",
		"res/effects/skill_line6",
		"res/effects/skill_line5",
		"res/effects/skill_line4",
		"res/effects/skill_line3",
		"res/effects/skill_line2",
		"res/effects/skill_line1",
	};

	BattleSceneView *sceneView = BattleSceneView::getCurrentSceneView();
	BattleMoveObjectView *attackerView = sceneView->getMoveObjectView(object->getId());	

	CCPoint startPoint = startPos;
	CCPoint finalTargetPos = endPos;
	sceneView->calcBulletEffectDest(skillInfo, startPoint, finalTargetPos, 0.0f, attackerView);	
	
	int realIndex = 0;
	int delta = 0;
	float *rotateAngle = new float();
	int index = calcSkillDirection(startPoint, finalTargetPos, rotateAngle);
	index += 4;
	if (index >= 16) index -= 16;
	if (index >= 9)
	{
		realIndex = 16 - index;
		delta = index - realIndex;
	}
	else
	{
		realIndex = index;
	}

	float angle = 360.0f * delta / 16;
	angle += *rotateAngle;
	delete rotateAngle;

	bool isFlip = false;
	if (startPoint.x > finalTargetPos.x)
	{
		isFlip = true;
	}

	IntervalAnimationDisplayNode *directionNode = IntervalAnimationDisplayNode::create(skillDirectionRes[realIndex].c_str(), isFlip);
	directionNode->setPosition(startPoint);
	sceneView->getLayer()->addChild(directionNode, 1);
	//directionNode->setRotation(-angle);
	return directionNode;
}

static Node *addPreReleaseSkillDirection(BattleObject *object, const CCPoint &startPos, const CCPoint &endPos)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	BattleSceneView *sceneView = BattleSceneView::getCurrentSceneView();
	float deltaX = endPos.x - startPos.x;
	float deltaY = endPos.y - startPos.y;
	float dis = ccpDistance(startPos, endPos);
	float sin_ = deltaY / dis;
	float cos_ = deltaX / dis;
	float length = 500.0f / CC_CONTENT_SCALE_FACTOR();
	IntervalAnimationDisplayNode *node = IntervalAnimationDisplayNode::create("res/effects/general_release_skills_lock");
	node->setAnchorPoint(ccp(0.0f, 0.0f));
	node->setPosition(endPos);
	Sprite *sprite = node->getMainSprite();
	sceneView->getLayer()->addChild(node, 1);

	return node;
}

void BattleSceneView::showSkillDirection(BattleObject *object, const CCPoint &startPos, const CCPoint &endPos, const SkillInfo &skillInfo)
{
	Node *sprite = addSkillDirection(object, startPos, endPos, skillInfo);
	m_skillIndicates.insert(make_pair(object->getId(), sprite));
}

void BattleSceneView::showPreReleaseSkillCircle(BattleObject *object, const cocos2d::CCPoint &centerPos, int diameter)
{
	Node *sprite = addPreReleaseaSkillCircle(object, centerPos, diameter);
	m_preReleaseSkillIndicates.insert(make_pair(object->getId(), sprite));
}

void BattleSceneView::showPreReleaseSkillDirection(BattleObject *object, const cocos2d::CCPoint &startPos, const cocos2d::CCPoint &endPos)
{
	Node *sprite = addPreReleaseSkillDirection(object, startPos, endPos);
	m_preReleaseSkillIndicates.insert(make_pair(object->getId(), sprite));
}

void BattleSceneView::removePreReleaseSkillIndicates()
{
	for (auto iter = m_preReleaseSkillIndicates.begin(); iter != m_preReleaseSkillIndicates.end(); ++iter)
	{
		m_map->removeChild(iter->second);
	}

	m_preReleaseSkillIndicates.clear();
}

void BattleSceneView::removeSkillIndicate(uint16_t objectId)
{
	map<uint16_t, Node *>::iterator iter = m_skillIndicates.find(objectId);
	if(iter != m_skillIndicates.end())
	{
		m_map->removeChild(iter->second);
		m_skillIndicates.erase(iter);
	}
}

bool BattleSceneView::canNormalTypeSkillAutoRelease(int skillLevelId, BattleObject *attacker)
{
	BattleScene *scene = BattleScene::getCurrentScene();

	uint16_t targetId = 0;
	switch(scene->getObjectType(attacker->getId()))
	{
	case BattleScene::kMoveObj:
		{
			targetId = dynamic_cast<BattleMoveObject *>(attacker)->getTargetId();
			break;
		}
	case BattleScene::kTower:
		{
			targetId = dynamic_cast<BattleTower *>(attacker)->getTargetId();
			break;
		}
	default:
		assert(false);
		break;
	}

	return (targetId > 0 && scene->getObject(targetId));
}

bool BattleSceneView::skillAttackTarget(const skill::SkillResult &sr, const skill::SpecialFxData &data, uint16_t attackerId, const SkillInfo &skillInfo, bool isNormalAttackSkill)
{
	BattleReport report = skill::getSkillReport(sr);
    report.isNormalAttackSkill = isNormalAttackSkill;	
	BattleObjectView *attackerView = getObjectView(attackerId);
	assert(attackerView);
	BattleObject *attacker = attackerView->getModel();

	BattleMoveObjectView * battleMoveView = dynamic_cast<BattleMoveObjectView *>(attackerView);
	BattleMoveObject * battleMoveObj = dynamic_cast<BattleMoveObject *>(attacker);

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	skill::SkillType skillType = static_cast<skill::SkillType>(SKILLLOGIC_TYPE(skillInfo.skill_id));
	int modType = SKILLLOGIC_MOD_TYPE(skillInfo.skill_id);
    battleMoveObj->runUseSkillAttackPassiveFxs(skillLevelId, 0);

	PixelPoint pix = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
	CCPoint pt(pix.x, pix.y);

	std::string bulletRes = std::string(SKILL_BULLET_RES(skillInfo.skill_id));

	bool isMyselfActiveSkill = true;  //是否自己的主动技
	if (battleMoveView != nullptr && battleMoveObj != nullptr)
	{		
		int groupId = battleMoveObj->getHandSkillGroupId();
		if (groupId != skillInfo.skill_id)
		{
			isMyselfActiveSkill = false;
		}			
	}
	if (battleMoveObj->getParty() == kFriendParty && (!battleMoveObj->isMonster()) && isMyselfActiveSkill 
		&& (bulletRes.empty() ||  modType == skill::kHitRangeTypeNone))
	{
		float scaleNum = 1.0f;
		if (modType == skill::kHitRangeTypeCircle || modType == skill::kHitRangeTypeOutCircle)
		{
			const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
			if (v[0] > 0)
			{
				float radius = v[0] * 0.5f;
				scaleNum = radius/skill::kTargetMarkOriginalRadiusGrid;
			}			
		}
		cocos2d::Sprite * showTargePosEff = cocos2d::Sprite::create(skill::kSkillTargetMarkEffName.c_str());
		showTargePosEff->setPosition(pt);
		//showTargePos->setScale(scaleNum);
		CCSequence *seq = CCSequence::create(CCFadeTo::create(1.0f, 0),CCRemoveSelf::create(true), nullptr);
		showTargePosEff->runAction(seq);
		getLayer()->addChild(showTargePosEff, 0);
	}	

	if (skillType == skill::kTypeAttack)
	{
		if(modType != skill::kHitRangeTypeCircle && modType != skill::kHitRangeTypeNone && modType != skill::kHitRangeTypeCross)
		{
			PixelPoint targetPoint = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
			attacker->setToward(attackerView->getPosition(), ccp(targetPoint.x, targetPoint.y));
		}

		attackerView->attack(skillLevelId, pt, isNormalAttackSkill);

		if(modType == skill::kHitRangeTypeOutCircle)
		{
			std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
			if (!effectStr.empty())
			{
				SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, 0.0f, data.data1, pt, m_map);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(pt);
				addChild(pEffect, 10);
			}
		}

		handleReport(attacker, report, false);
	}
	else if(skillType == skill::kTypeNormal)
	{
		attackerView->attack(skillLevelId);
		std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
		if (!effectStr.empty())
		{
			SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, 0.0f, 0.0f, pt, m_map);
			pEffect->setAnchorPoint(ccp(0, 0));
			pEffect->setPosition(pt);
			addChild(pEffect, 10);
		}

	}
	else if (skillType == skill::kTypeSpecial)
	{
		skill::SpecialFxType type = data.type;
		if(type == skill::kAttackHittingFrame) // kAttackHittingFrame类型必须先调用attack（因为addHittingFrame()要访问m_attackEffects数据），所以这里特殊处理
		{
			attackerView->attack(skillLevelId);
			attackerView->addHittingFrame(skillInfo, data);
		}
		else
		{
			if(modType != skill::kHitRangeTypeCircle)
			{
				PixelPoint targetPoint = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
				PixelPoint attackPoint = attackerView->getModel()->getPixelPosition();
				attacker->setToward(ccp(attackPoint.x, attackPoint.y), ccp(targetPoint.x, targetPoint.y));
			}

			if(!handleSpecialFxData(attackerView, attackerId, skillInfo, data))
			{
				return false;
			}

			if(type == skill::kStaticWhirlWind || type == skill::kChainLightning 
				|| type == skill::kChainCure || type == skill::kCureOrFireflag || type == skill::kInvincibleFastCut || type == skill::kChainDamage)
			{
				attackerView->attack(skillLevelId);
			}
			else
			{
				PixelPoint pix = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
				attackerView->attack(skillLevelId, ccp(pix.x, pix.y));
			}
		}
	}

	if(!isNormalAttackSkill)
	{		
		switch(modType)
		{
		case skill::kHitRangeTypeCircle:
		case skill::kHitRangeTypeOutCircle:
		case skill::kHitRangeTypeSector:
		case skill::kHitRangeTypeRect:
		case skill::kHitRangeTypeScreenRect:
		case skill::kHitRangeTypeCross:
			{
				if((!bulletRes.empty()))
				{
					if (attackerView->getModel()->getParty() == kFriendParty) //敌人不显示攻击方向指示;
					{
						PixelPoint endPos = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
						PixelPoint attackerPos = attackerView->getModel()->getPixelPosition();	
						//showSkillDirection(attacker, ccp(attackerPos.x, attackerPos.y), ccp(endPos.x, endPos.y), skillInfo);
					}				
				}
				break;
			}
		default:
			{
				break;
			}
		}
		if (isMyselfActiveSkill)
		{
			attackerView->showSkillIconName(skillInfo.skill_id);
			if (dynamic_cast<BattleMoveObjectView *>(attackerView))
			{
				BattleMoveObjectView * atkerMovView = dynamic_cast<BattleMoveObjectView *>(attackerView);
				if (atkerMovView->getModel()->getParty() == kFriendParty && (!atkerMovView->getModel()->isMonster()) && (atkerMovView->getHasShowBust() == false))
				{
					//m_battleMenu->showSkillGeneralBust(attackerView->getModel()->getTid());
					//atkerMovView->setHasShowBust(true);
				}
			}
		}
	}

	BattleScene *scene = BattleScene::getCurrentScene();
	set<uint16_t> objects;
    if ( !(skillType == skill::kTypeSpecial && skill::kPyrosphere == data.type) )
    {
        skill::doBuff(scene, attacker, objects, skillLevelId, TargetSelect::kTargetSelf);
    }
	skill::doNormalFx(scene, attacker, objects, skillLevelId, TargetSelect::kTargetSelf);

	return true;
}

bool BattleSceneView::doUseSkillAction(uint16_t attackerId, const SkillGroupInfo &skillGroupInfo, const cocos2d::CCPoint &targetPoint)
{
	bool retValue = false;
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (!attacker->checkUseSkill(skillGroupInfo.skill_group_id))
	{
		return false;
	}

	skill::SkillResult sr;
	skill::SpecialFxData data;
	SkillInfo skillInfo = SkillInfo(skillGroupInfo.skill_group_id, skillGroupInfo.level);
	bool isUseSuccess = canUseSkill(&sr, &data, attackerId, skillInfo, false, targetPoint, true, false);
	if(isUseSuccess && useSkill(sr, data, attackerId, skillInfo, false))
	{
		attacker->afterUseSkill(skill::getSkillLvId(skillGroupInfo.skill_group_id, skillGroupInfo.level));
		retValue = true;
	}

	return retValue;
}

void BattleSceneView::effctForTwiceSkill(uint16_t attackerId)
{
	BattleMoveObjectView * attackerView = getMoveObjectView(attackerId);
	if (attackerView)
	{
		attackerView->runSkillEffectSkyUp();
		std::vector<BattleObjectView *> objs;
		objs.push_back(attackerView);
		addBlackLayer(objs, attackerId);
		CCDelayTime* delayFunc = CCDelayTime::create(skill::kBlackLayerFadeInTime);
		float removeTime = skill::kBlackLayerFadeOutTime / 1.5f;
		CCCallFuncND* removeFunc = CCCallFuncND::create(this, std::bind(&BattleSceneView::removeBlackLayer, this, attackerId, removeTime));
		CCSequence *seq= CCSequence::create(delayFunc, removeFunc, nullptr);
		runAction(seq);
	}	
}

static bool isClickNodeGate_(IntervalAnimationDisplayNode *nodeGate, const CCPoint &point)
{
	Sprite *mainSprite = nodeGate->getMainSprite();
	CCPoint pt = nodeGate->convertToNodeSpace(point);
	//return (mainSprite->boundingBox().containsPoint(pt) && isClickTheRealSprite(mainSprite, mainSprite->convertToNodeSpace(point)));
	return mainSprite->boundingBox().containsPoint(pt);
}
void BattleSceneView::showCallGeneralTip(const char *txtKey)
{
// 	char buf[128] = {0};
// 	snprintf(buf, sizeof(buf), "%s",STRING_ZHCHS(txtKey));
// 	//noBtnHintWithOneColor(buf);
// 
// 	std::vector<std::string> texts;
// 	texts.push_back(buf);
// 
// 	const Size &size = CCDirector::sharedDirector()->getWinSize();
// 	TextHint *hint = TextHint::create(texts);
// 	hint->setAnchorPoint(ccp(0.5f, 0.5f));
// 	hint->setPosition(ccp(size.width * 0.5f, size.height * 0.5));
// 	m_battleMenu->addChild(hint, kZOrderTips);
// 
// 	TextTipAction::runAction(hint, nullptr, -100);
}

void BattleSceneView::checkClickCurrentNodeGate(const cocos2d::CCPoint &pt)
{
	if(isInThisBattleMode(MainScene::kBattleArena))
	{
		return;
	}

	if(!m_model->getFormation(kFriendParty))
	{
		return;
	}

	CCPoint point(pt.x + getPositionX(), pt.y + getPositionY());
	IntervalAnimationDisplayNode *nodeGate = m_map->getCurrentNodeGate();
	if(!nodeGate)
	{
		return;
	}

	
	
	if (isClickNodeGate_(nodeGate, m_map->convertToWorldSpace(pt)))
	{
		if(m_model->canOpenCurrentNodeGate())
		{
			LuaLogicUtil::onClickNodeGate(0);
		}
		else
		{
			showCallGeneralTip("first_node_general_tip");
		}
	}
}

static bool isClickMoveObject_(BattleMoveObjectView *objectView, const CCPoint &point)
{
	BattleAvatar *sprite = objectView->getMainSprite();
	CCPoint pt(point.x - sprite->getOffset().x, point.y - sprite->getOffset().y);
	CCPoint pt2 = objectView->convertToNodeSpace(pt);
	return (sprite->boundingBox().containsPoint(pt2) && isClickTheRealSprite(sprite, sprite->convertToNodeSpace(pt)));
}

static bool isClickStaticObject_(BattleStaticObjectView *objectView, const CCPoint &point)
{
	BattleAvatar *sprite = objectView->getMainSprite();
	CCPoint pt(point.x - sprite->getOffset().x, point.y - sprite->getOffset().y);
	CCPoint pt2 = objectView->convertToNodeSpace(pt);
	return (sprite->boundingBox().containsPoint(pt2) && isClickTheRealSprite(sprite, sprite->convertToNodeSpace(pt)));
}
void BattleSceneView::checkClickMoveObject(const cocos2d::CCPoint &pt)
{
	g_traceMoveObjId = 0;
	g_traceTroopId = 0;
	g_traceBuildingObjId = 0;
	g_traceTowerObjId = 0;
	GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(pt.x, pt.y);
	TEST_MSG("### Current click grid(%d, %d) ###", grid.x, grid.y);
	CCPoint point(pt.x + getPositionX(), pt.y + getPositionY());
	for(auto it = m_friendMoveObjects.begin(); it != m_friendMoveObjects.end(); ++it)
	{
		if(isClickMoveObject_(it->second, point))
		{
			g_traceMoveObjId = it->first;
			if(m_model->getObjectType(g_traceMoveObjId) == BattleScene::kMoveObj)
			{
				g_traceTroopId = dynamic_cast<BattleMoveObject *>(it->second->getModel())->getTroopId();
			}
			
			return;
		}
	}
	for(auto it = m_enemyMoveObjects.begin(); it != m_enemyMoveObjects.end(); ++it)
	{
		if (isClickMoveObject_(it->second, point))
		{
			g_traceMoveObjId = it->first;
			if(m_model->getObjectType(g_traceMoveObjId) == BattleScene::kMoveObj)
			{
				g_traceTroopId = dynamic_cast<BattleMoveObject *>(it->second->getModel())->getTroopId();
			}

			return;
		}
	}

	for (auto it = m_friendBuildings.begin(); it != m_friendBuildings.end(); ++it)
	{
		if (isClickStaticObject_(it->second, point))
		{
			g_traceBuildingObjId = it->first;

			return;
		}
	}

	for (auto it = m_enemyBuildings.begin(); it != m_enemyBuildings.end(); ++it)
	{
		if (isClickStaticObject_(it->second, point))
		{
			g_traceBuildingObjId = it->first;

			return;
		}
	}

	for (auto it = m_friendTowers.begin(); it != m_friendTowers.end(); ++it)
	{
		if (isClickStaticObject_(it->second, point))
		{
			g_traceTowerObjId = it->first;

			return;
		}
	}

	for (auto it = m_enemyTowers.begin(); it != m_enemyTowers.end(); ++it)
	{
		if (isClickStaticObject_(it->second, point))
		{
			g_traceTowerObjId = it->first;

			return;
		}
	}
	
}

void BattleSceneView::dealOnSingleClicked(const cocos2d::CCPoint &pt)
{
	if (GameClientGM::theClientGM()->isTerrainDebug() && Director::getInstance()->getIsRender())
	{
		checkClickMoveObject(pt);
	}
}

void BattleSceneView::resetSingleClick()
{
	setSingleClickAttackerId(0);
}

void BattleSceneView::hittingFrameAccount(BattleObjectView *attackerView, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	account(attackerView->getPosition(), attackerView->getModel(), skillInfo, data, false, false, nullptr);
}

void BattleSceneView::account(const cocos2d::CCPoint &pt, BattleObject *attackerObj, const SkillInfo &skillInfo, const skill::SpecialFxData &data, bool isForceShake, bool isCalcHurt, CalcHurtAttackProp *calcHurtAttackProp)
{
	BattleMoveObject * attacker = dynamic_cast<BattleMoveObject *>(attackerObj);	
	if (attacker == nullptr)
	{
		assert(false);
		return;
	}
	uint16_t attackerId = attacker->getId();
	cocos2d::CCPoint usePt = pt;
	if (data.type == skill::kFountain || data.type == skill::kSnowstorm)
	{
		int attckEffTag = skill::kFountainEffcTag;
		if (data.type == skill::kSnowstorm)
		{
			attckEffTag = skill::kSnowstormEffcTag;
		}
		
		Node * tmp = m_map->getChildByTag(attckEffTag + attackerId);
		if (tmp)
		{
			CustomEffectRandom * attackEff = dynamic_cast<CustomEffectRandom *>(tmp);
			if (attackEff)
			{
				usePt =ccpAdd(pt,attackEff->getEffectShowAtkPos());
			}
		}
	}
	
	PixelPoint pix(static_cast<int16_t>(usePt.x), static_cast<int16_t>(usePt.y));
	CCPoint grid = GridUtil::sharedGridUtil().pixToFloatGrid(pix);
	std::set<uint16_t> targets;

	if (data.type == skill::kPyrosphere)
	{
		int skillLvId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);

		TargetSelect::TargetSide targetSide = (TargetSelect::TargetSide)static_cast<int>(data.data3);	
		int targetTypeValue = static_cast<int>(data.data4);

		char attackerParty = attacker->getParty();
		TargetSelect::UnitType targetType = static_cast<TargetSelect::UnitType>(targetTypeValue);		
		char party = (targetSide == TargetSelect::kTargetSelf) ? attackerParty : getOppoParty(attackerParty);
		getObjects(&targets, party, targetType, skillLvId, data, attackerParty, grid);
	}
	else
	{
		skill::getObjects(&targets, skillInfo, data, attacker->getParty(), grid);
	}	

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	if(targets.empty())
	{
		if(isForceShake)
		{
			const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
			CCAction *sceneShakeAction = getSceneShakeAction(skillPty.hitScreenShake);
			if(sceneShakeAction) runAction(sceneShakeAction);
		}
	}
	else
	{
		handleFxBuff(attacker, skillLevelId, targets, isCalcHurt);

		if(isCalcHurt)
		{
			if (data.type == skill::kFountainPartake)
			{
				if (!targets.empty())
				{
					m_model->partakeDamage(targets, (int)data.data3);
				}			
				return;
			}	    

			if (data.type == skill::kAbsorbHpTrap)
			{	
				int targetSize = targets.size();
				int32_t averageHurt = (int32_t)data.data3;
				int32_t totalHurtHp = targetSize * averageHurt;			
				m_model->partakeDamage(targets, totalHurtHp);
				m_model->shareCureGenerals(attacker->getParty(), totalHurtHp);
			}
			else
			{
				bool isNotShowHurt = false;
				if (data.type == skill::kPyrosphere)
				{
					isNotShowHurt = true;
					attacker->setNotShowHurt(true);					
				}

				genSkillBattleReport(attacker, targets, skillLevelId, pix, calcHurtAttackProp);

				if (isNotShowHurt)
				{
					attacker->setNotShowHurt(false);
				}
			}
		}
	}
}

void BattleSceneView::trapRemoveAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	int hurt = static_cast<int>(data.data3);
	if(attacker == nullptr || hurt == 0)
	{
		return;
	}

	PixelPoint pix(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y));
	CCPoint grid = GridUtil::sharedGridUtil().pixToFloatGrid(pix);
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillInfo, data, attacker->getParty(), grid);

	BattleScene *scene = BattleScene::getCurrentScene();
	for(auto it = targets.begin(); it != targets.end(); ++it)
	{
		BattleObject *object = scene->getObject(*it);
		object->setHp(object->getHp() - hurt, 0, true);
	}
}

void BattleSceneView::iceAccount(const cocos2d::CCPoint &pt, BattleMoveObject *attacker, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	PixelPoint pix(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y));
	CCPoint grid = GridUtil::sharedGridUtil().pixToFloatGrid(pix);
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillInfo, data, attacker->getParty(), grid);

	BuffMgr &mgr = BuffMgr::theMgr();
	BattleScene *scene = BattleScene::getCurrentScene();
	float buffLifeTime = data.data3;
	int buffId = static_cast<int>(data.data4);
	int hurt = static_cast<int>(data.data5);
	for(auto it = targets.begin(); it != targets.end(); ++it)
	{
		uint16_t objectId = *it;

		mgr.freeze(buffId, objectId, buffLifeTime);
		switch(scene->getObjectType(objectId))
		{
		case BattleScene::kMoveObj:
			{
				BattleMoveObject *moveObj = scene->getMoveObject(objectId);
				moveObj->calcBuffs(0.0f);
				moveObj->setHp(moveObj->getHp() - hurt, 0, true);
				break;
			}
		case BattleScene::kTower:
			{
				BattleTower *tower = scene->getTower(objectId);
				tower->calcBuffs(0.0f);
				tower->setHp(tower->getHp() - hurt, 0, true);
				break;
			}
		default:
			assert(false);
		}
	}
}

void BattleSceneView::hellTrapAccount(const cocos2d::CCPoint &pt, uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data)
{
	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (!attacker) return;

	CCPoint grid = GridUtil::sharedGridUtil().pixToFloatGrid( PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)) );
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillInfo, data, attacker->getParty(), grid);

	std::set<uint16_t>::iterator iter = targets.begin();
	for (; iter != targets.end(); ++iter)
	{
		BattleMoveObject *target = m_model->getMoveObject(*iter);
		target->setHp(0, 0, true);
	}
}

void BattleSceneView::bulletAccount(std::vector<uint16_t> *hurtObjects, const cocos2d::CCPoint &startGrid, const cocos2d::CCPoint &endGrid, bool &hasEnemy, 
	BattleMoveObject *attacker, uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, CalcHurtAttackProp *calcHurtAttackProp)
{
	if (!m_model->getTerrain()->isValidGrid( static_cast<int>(endGrid.x), static_cast<int>(endGrid.y) ))
	{
		return;
	}
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillInfo, data, attacker->getParty(), startGrid, endGrid);
	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);

	FxMgr &mgr = FxMgr::theMgr();
	set<uint16_t> newHurtObjects;
	for(std::set<uint16_t>::iterator iter = targets.begin(); iter != targets.end(); ++iter)
	{
		uint16_t objectId = *iter;
		if(std::find(hurtObjects->begin(), hurtObjects->end(), objectId) != hurtObjects->end()) continue; //上次已经被伤害过了;
		newHurtObjects.insert(objectId);
		BattleScene::ObjectType objectType = m_model->getObjectType(objectId);
		if(objectType == BattleScene::kMoveObj && data.type != skill::kSectorIce)
		{
			BattleMoveObject *obj = m_model->getMoveObject(objectId);
			if(obj->getType() == BattleMoveObject::kGeneral)
			{
				mgr.setMoveObject(obj);
				mgr.physicHurtedMul(data.data2);
			}
		}
	}

	if(newHurtObjects.empty())
	{
		hasEnemy = false;
		return;
	}

	hasEnemy = true;
	hurtObjects->insert(hurtObjects->end(), newHurtObjects.begin(), newHurtObjects.end());
	handleFxBuff(attacker, skillLevelId, newHurtObjects);
	genSkillBattleReport(attacker, newHurtObjects, skillLevelId, GridUtil::sharedGridUtil().floatGridToPix(startGrid.x,startGrid.y), calcHurtAttackProp);
}

void BattleSceneView::chainLightningAccount(BattleMoveObject *attacker, BattleMoveObject *defender, int skillLvId, CalcHurtAttackProp *calcHurtAttackProp)
{
	skill::doSelfFx(BattleScene::kMoveObj, attacker, nullptr, nullptr, skillLvId);
	set<uint16_t> targets;
	targets.insert(defender->getId());
	genSkillBattleReport(attacker, targets, skillLvId, defender->getPixelPosition(), calcHurtAttackProp);
}

void BattleSceneView::onStaticWhirlWindFinished(uint16_t attackerId)
{
	BattleObjectView *attacker = getObjectView(attackerId);
	if (!attacker) return;

	BattleMoveObject *attackerModel = dynamic_cast<BattleMoveObject *>(attacker->getModel());
	attackerModel->setCloak(false);
	attacker->setVisible(true);
	attackerModel->stopRunning();
	attackerModel->resume();
}

void BattleSceneView::onLookOver(const cocos2d::CCPoint &pt)
{
	focusTo(pt);

	updateTinyMap();
}

float BattleSceneView::focusToWithAnimation(const cocos2d::CCPoint &pt, std::function<void ()> focusToFinished)
{
	const CCPoint &perfectOrig = convertToPerfectFocusPos(pt);
	const CCPoint &curPos = getPosition();
	float duration = 0.3f;
	float dis = ccpDistance(perfectOrig, ccp(curPos.x, curPos.y));
	if (dis > 200.0f / CC_CONTENT_SCALE_FACTOR())
	{
		duration = 0.3f;
	}
	else
	{
		duration = dis / (600.0f / CC_CONTENT_SCALE_FACTOR()); 
	}				

	CCMoveTo *moveAction = CCMoveTo::create(duration, perfectOrig);
	CCEaseExponentialOut *expAction = CCEaseExponentialOut::create(moveAction);
	expAction->setTag(skill::kFocusActionTagForBattleScene);
	runAction(expAction);

	CCDelayTime * delayMove = CCDelayTime::create(duration);
	CCCallFuncND *func = CCCallFuncND::create(this, focusToFinished);
	CCSequence *seqFunc = CCSequence::create(delayMove, func,nullptr);	
	runAction(seqFunc);
	return duration;
}

void BattleSceneView::releaseSkillFocusTo(uint16_t attackerId, const SkillInfo &skillInfo, const cocos2d::CCPoint &pt, std::function<void ()> focusToFinished)
{
	bool isReleaseSkill = SKILLGROUP_RELEASE_TYPE(skillInfo.skill_id) == 0;

	stopActionByTag(skill::kFocusActionTagForBattleScene);
	BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
	if (!isReleaseSkill)
	{
		attackerView->runWaitForSelectTargetEffect();
	}
	
	if (attackerView)
	{
		std::vector<BattleObjectView *> objs;
		objs.push_back(attackerView);
		if (isReleaseSkill)
		{
			addBlackLayer(objs, attackerId);
		}		
	}
	else
	{
		return;
	}

	float duration = 0.0f;
	if (isReleaseSkill || ((m_model->getIsInAutoBattleMode()) && (!isReleaseSkill)) )
	{
		duration = focusToWithAnimation(pt);
	}
	
	CCDelayTime * delayMove = CCDelayTime::create(duration);
	CCCallFuncND *moveScreenEnd = CCCallFuncND::create(this, [=](void){
		if (isReleaseSkill)
		{
			removeBlackLayer(attackerId);
		}
		
		if (attackerView == nullptr)
		{
			return;
		}		
		attackerView->runBeforeUseSkillEffect(isReleaseSkill);
	});		

	float delayForFocus = 0.4f;
	if (!isReleaseSkill)
	{
		delayForFocus = 0.1f;
	}
	CCDelayTime * delayFunc = CCDelayTime::create(delayForFocus);
	CCCallFuncND *func = CCCallFuncND::create(this, focusToFinished);	

	CCSequence *seqFunc = CCSequence::create(delayFunc, func, nullptr); 
	CCSpawn *spw = CCSpawn::create(moveScreenEnd, seqFunc, nullptr);	

	CCSequence *seqFocuEndLogic = CCSequence::create(delayMove, spw, nullptr);
	seqFocuEndLogic->setTag(skill::kFocusEndLogicTag + attackerId);
	runAction(seqFocuEndLogic);
}

void BattleSceneView::focusTo(const cocos2d::CCPoint &pt)
{
	const CCPoint &perfectOrig = convertToPerfectFocusPos(pt);
	CCPoint setPos = ccp(perfectOrig.x, perfectOrig.y);
	float scale = getScale();
	float w = m_model->getWidth()*scale / getScaleFactor()*m_mapScale;
	float h = m_model->getHeight()*scale / getScaleFactor()*m_mapScale;
	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	if (setPos.y < (winSize.height - h - m_topOffsetPos.y)) setPos.y = (winSize.height - h - m_topOffsetPos.y);
	setPosition(ccp(setPos.x, setPos.y));
}

void BattleSceneView::focusToGrid(const cocos2d::CCPoint &pt)
{
	PixelPoint pixPoint = GridUtil::sharedGridUtil().gridToPix(GridPosition(pt.x, pt.y));
	cocos2d::CCPoint destPoint = cocos2d::CCPoint(pixPoint.x, pixPoint.y);
	focusTo(destPoint);
}

void BattleSceneView::focusMoveTo(const cocos2d::CCPoint &pt, int time)
{
	PixelPoint pixPoint = GridUtil::sharedGridUtil().gridToPix(GridPosition(pt.x,pt.y));
	cocos2d::CCPoint destPoint = cocos2d::CCPoint(pixPoint.x, pixPoint.y);

	if (m_battleSceneCameraState == kBSCTBuilding) return;

	// ToDo 移动中到指定的中心点
	const CCPoint &perfectOrig = convertToPerfectFocusPos(destPoint);

	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	CCPoint pt2(perfectOrig.x, perfectOrig.y);
	float w = m_model->getWidth() / getScaleFactor()*m_mapScale;
	float h = m_model->getHeight() / getScaleFactor()*m_mapScale;
	if (pt2.x > 0.0f) pt2.x = 0.0f;
	else if (pt2.x < winSize.width - w) pt2.x = winSize.width - w;

	if (pt2.y > m_bottomOffsetPos.y) pt2.y = m_bottomOffsetPos.y;

	else if (pt2.y < (winSize.height - h - m_topOffsetPos.y)) pt2.y = (winSize.height - h - m_topOffsetPos.y);

	CCSequence *seqActions = CCSequence::create(CCMoveTo::create(time, pt2), nullptr);
	runAction(seqActions);
	//setManualCamera();
}

CCPoint BattleSceneView::getScreenKeyPoint(screen::ScreenKeyPointType type, const CCPoint &offset)
{
	const Size &size = CCDirector::sharedDirector()->getWinSize();

	switch(type)
	{
	case screen::kScreenLeftUp:
		{
			return ccp(-getPositionX() + offset.x, -getPositionY() + size.height - offset.y);
		}
	case screen::kScreenLeftMid:
		{
			return ccp(-getPositionX() + offset.x, -getPositionY() + size.height * 0.5f);
		}
	case screen::kScreenLeftDown:
		{
			return ccp(-getPositionX() + offset.x, -getPositionY() + offset.y);
		}
	case screen::kScreenMidUp:
		{
			return ccp(-getPositionX() + size.width * 0.5f, -getPositionY() + size.height - offset.y);
		}
	case screen::kScreenMidDown:
		{
			return ccp(-getPositionX() + size.width * 0.5f, -getPositionY() + offset.y);
		}
	case screen::kScreenRightUp:
		{
			return ccp(-getPositionX() + size.width - offset.x, -getPositionY() + size.height - offset.y);
		}
	case screen::kScreenRightMid:
		{
			return ccp(-getPositionX() + size.width - offset.x, -getPositionY() + size.height * 0.5f);
		}
	case screen::kScreenRightDown:
		{
			return ccp(-getPositionX() + size.width - offset.x, -getPositionY() + offset.y);
		}
	default:
		assert(false);
		return ccp(0, 0);
	}
}

GridPosition BattleSceneView::getScreenCenterGrid()
{
	const Size &size = CCDirector::sharedDirector()->getWinSize();
	return GridUtil::sharedGridUtil().pixToGrid(-getPositionX() + size.width * 0.5f, -getPositionY() + size.height * 0.5f);
}

float BattleSceneView::getAtkAreaWithGrid(float gridNum)
{
	float retValue = gridNum * 1.414f * 0.5f * GridUtil::sharedGridUtil().getTileWidth() / getScaleFactor();
	return retValue;
}

void BattleSceneView::initBattleInfoTips(std::function<void ()> func)
{
}


void BattleSceneView::initTerrainFlag()
{
	dynamic_cast<SceneLayer *>(m_map)->initTerrainFlag();
}

void BattleSceneView::deinitTerrainFlag()
{
	dynamic_cast<SceneLayer *>(m_map)->deinitTerrainFlag();
}

void BattleSceneView::deinitAreaFlag()
{
	dynamic_cast<SceneLayer *>(m_map)->deinitAreaFlag();
}

void BattleSceneView::gmShowSoldierIds(bool isShow)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_friendMoveObjects.begin();
	for(; iter != m_friendMoveObjects.end(); ++iter)
	{
		iter->second->gmShowId(isShow);
	}

	iter = m_enemyMoveObjects.begin();
	for(; iter != m_enemyMoveObjects.end(); ++iter)
	{
		iter->second->gmShowId(isShow);
	}

	std::map<uint16_t, BattleStaticObjectView *>::iterator iter2 = m_friendBuildings.begin();
	for(; iter2 != m_friendBuildings.end(); ++iter2)
	{
		iter2->second->gmShowId(isShow);
	}

	iter2 = m_enemyBuildings.begin();
	for(; iter2 != m_enemyBuildings.end(); ++iter2)
	{
		iter2->second->gmShowId(isShow);
	}

	iter2 = m_friendTowers.begin();
	for(; iter2 != m_friendTowers.end(); ++iter2)
	{
		iter2->second->gmShowId(isShow);
	}

	iter2 = m_enemyTowers.begin();
	for(; iter2 != m_enemyTowers.end(); ++iter2)
	{
		iter2->second->gmShowId(isShow);
	}
}

void BattleSceneView::onFriendMoveObjectAdd(BattleMoveObject *mo, bool isHide)
{
	if (m_friendMoveObjects.find(mo->getId()) == m_friendMoveObjects.end())
	{
		BattleMoveObjectView *view = BattleMoveObjectView::create(mo);
		m_map->addChild(view, 2);

		m_friendMoveObjects.insert(std::make_pair(mo->getId(), view));
		
		if(!isHide)
		{
			view->runAppearanceEffect();
		}

		if(mo->getType() == BattleMoveObject::kGeneral)
		{
			view->playBirthSound();
		}
	}
}

void BattleSceneView::onFriendMoveObjectRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_friendMoveObjects.find(id);
	if (iter != m_friendMoveObjects.end())
	{
		m_toAddRes += resource;
		if (m_toAddRes >= 1.0f)
		{
			int addRes = (int)m_toAddRes;
			m_toAddRes -= (float)addRes;
			if (isInThisBattleMode(MainScene::kBattlePVP) || isInThisBattleMode(MainScene::kBattleArena))
			{
				BattlePvp::thePvp()->addBattleRes(addRes);
			}	
		}

		if ((isInThisBattleMode(MainScene::kBattlePVP) || isInThisBattleMode(MainScene::kBattleArena)) &&
            (iter->second->getModel()->getType() == BattleMoveObject::kGeneral)
            )
		{
			m_model->costBattleResource(BATTLEPARA_VALUE("pvp_general_dead_cost"));
		}

		m_friendMoveObjects.erase(iter);
		
		checkBattleResult();
	}
}


void BattleSceneView::onEnemyMoveObjectAdd(BattleMoveObject *mo, bool isHide)
{
	if (m_enemyMoveObjects.find(mo->getId()) == m_enemyMoveObjects.end())
	{
		BattleMoveObjectView *view = BattleMoveObjectView::create(mo);
		m_map->addChild(view, 2);

		m_enemyMoveObjects.insert(std::make_pair(mo->getId(), view));

		if(!isHide)
		{
			view->runAppearanceEffect();
		}

		if(mo->getType() == BattleMoveObject::kGeneral)
		{
			view->playBirthSound();
		}
	}

}

void BattleSceneView::onEnemyMoveObjectRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_enemyMoveObjects.find(id);
	if (iter != m_enemyMoveObjects.end())
	{
		BattleMoveObjectView *battleMoveObjview = iter->second;
		CCPoint position = m_map->convertToWorldSpace(iter->second->getPosition());	

		if (isInThisBattleMode(MainScene::kBattlePass))																				
		{
			if (battleMoveObjview->getModel()->getType() == BattleMoveObject::kGeneral)
			{
				std::vector<ItemInfo> *dropOut = m_model->getGeneralDropOut(battleMoveObjview->getModel()->getTid(), false);
				if (dropOut)
				{
					for (size_t i = 0; i < dropOut->size(); ++i)
					{
						BattleDropOutLayer *layer = BattleDropOutLayer::create(0, position, dropOut->at(i));
						layer->setPosition(m_map->convertToNodeSpace(ccp(0, 0)));
						layer->finishedHandler(std::bind(&BattleSceneView::addDropOut, this));
						addChild(layer);
					}
				}
			}
		}

		m_toAddRes += resource;
		if (m_toAddRes >= 1.0f)
		{
			int addRes = (int)m_toAddRes;
			m_toAddRes -= (float)addRes;

			BattleResourcePickUpLayer * layer = createBattleResourcePickUpLayer((float)addRes, position, true);
			addChild(layer);
		}

		m_enemyMoveObjects.erase(iter);

		// BOSS关卡中的BOSS死亡特写 及 战斗检查;
		//if (m_model->getPassType() == BattleScene::kBossPass 
		//	&& battleMoveObjview->getModel()->getType() == BattleMoveObject::kGeneral
		//	&& battleMoveObjview->getModel()->getParty() == kEnemyParty
		//	&& MONSTERGENERAL_BOSS_TYPE(battleMoveObjview->getModel()->getTid()) != 0)			// BOSS武将
		//{
		//	focusTo(battleMoveObjview->getPosition());
		//}

		checkBattleResult();
	}
}

void BattleSceneView::onEnemyBuildingAdd(BattleBuilding *building, bool isRunshowAction)
{
	if (m_enemyBuildings.find(building->getId()) == m_enemyBuildings.end())
	{
		int zOrder = zOrderOf(building);
		/*if (building->getSubType() == BattleStaticObject::kTrigger)
		{
			zOrder = 2;
		}*/
		BattleStaticObjectView *bsv = BattleStaticObjectView::withModel(building, isRunshowAction);
		m_map->addChild(bsv, zOrder);
		if (building->getIsHideModel())
		{
			bsv->setVisible(false);
		}

		m_enemyBuildings.insert(std::make_pair(building->getId(), bsv));

	}
}

void BattleSceneView::onEnemyBuildingRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_enemyBuildings.find(id);
	if (iter != m_enemyBuildings.end())
	{
		m_enemyBuildings.erase(iter);

		checkBattleResult();
	}
}

void BattleSceneView::onEnemyBuildingDisappear(uint16_t id)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_enemyBuildings.find(id);
	if (iter != m_enemyBuildings.end())
	{
		iter->second->removeFromParentAndCleanup(true);
		m_enemyBuildings.erase(iter);

		checkBattleResult();
	}
}

void BattleSceneView::onFriendBuildingDisappear(uint16_t id)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_friendBuildings.find(id);
	if (iter != m_friendBuildings.end())
	{
		iter->second->removeFromParentAndCleanup(true);
		m_friendBuildings.erase(iter);

		checkBattleResult();
	}
}

void BattleSceneView::onFriendBuildingAdd(BattleBuilding *building, bool isRunshowAction)
{
	if (m_friendBuildings.find(building->getId()) == m_friendBuildings.end())
	{
		int zOrder = zOrderOf(building);
		if (building->getSubType() == BattleStaticObject::kTrigger)
		{
			zOrder = 2;
		}
		BattleStaticObjectView *bsv = BattleStaticObjectView::withModel(building, isRunshowAction);
		m_map->addChild(bsv, zOrder);

		m_friendBuildings.insert(std::make_pair(building->getId(), bsv));
	}
}

void BattleSceneView::onFriendBuildingRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_friendBuildings.find(id);
	if (iter != m_friendBuildings.end())
	{
		if (BattleScene::getCurrentScene()->isBossBarrack(kFriendParty, iter->second->getModel()->getId()))
		{
			m_lastBoss = iter->second;
		}
		m_friendBuildings.erase(iter);

		checkBattleResult();
	}
}

void BattleSceneView::onEnemyTowerAdd(BattleTower *tower)
{
	if (m_enemyTowers.find(tower->getId()) == m_enemyTowers.end())
	{
		int zOrder = zOrderOf(tower);
		if (tower->getSubType() == BattleStaticObject::kTrigger)
		{
			zOrder = 2;
		}
		BattleStaticObjectView *bsv = BattleStaticObjectView::withModel(tower);
		m_map->addChild(bsv, zOrder);

		m_enemyTowers.insert(std::make_pair(tower->getId(), bsv));
	}
}

void BattleSceneView::onEnemyTowerRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_enemyTowers.find(id);
	if (iter != m_enemyTowers.end())
	{
		CCPoint position = m_map->convertToWorldSpace(iter->second->getPosition());		// 转换为相对当前窗口的坐标;
		if (resource > FLT_EPSILON)
		{
			m_toAddRes += resource;
			if (m_toAddRes >= 1.0f)
			{
				int addRes = (int)m_toAddRes;
				m_toAddRes -= (float)addRes; 
				BattleResourcePickUpLayer * layer = createBattleResourcePickUpLayer((float)addRes, position, true);
				addChild(layer);
			}
		}

		m_enemyTowers.erase(iter);
	}
	checkBattleResult();
}

void BattleSceneView::onEnemyTowerDisappear(uint16_t id)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_enemyTowers.find(id);
	if (iter != m_enemyTowers.end())
	{
		iter->second->removeFromParentAndCleanup(true);
		m_enemyTowers.erase(iter);
	}
}

void BattleSceneView::onFriendTowerAdd(BattleTower *tower)
{
	if (m_friendTowers.find(tower->getId()) == m_friendTowers.end())
	{
		int zOrder = zOrderOf(tower);
		if (tower->getSubType() == BattleStaticObject::kTrigger)
		{
			zOrder = 2;
		}
		BattleStaticObjectView *bsv = BattleStaticObjectView::withModel(tower);
		m_map->addChild(bsv, zOrder);

		m_friendTowers.insert(std::make_pair(tower->getId(), bsv));
	}
}

void BattleSceneView::onFriendTowerRemoved(uint16_t id, float resource)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator iter = m_friendTowers.find(id);
	if (iter != m_friendTowers.end())
	{
		m_friendTowers.erase(iter);

		checkBattleResult();
	}
}

void BattleSceneView::onFriendMoveObjectDisappear(uint16_t id)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_friendMoveObjects.find(id);
	if (iter != m_friendMoveObjects.end())
	{
		iter->second->removeFromParent();
		m_friendMoveObjects.erase(iter);
	}
}

void BattleSceneView::onEnemyMoveObjectDisappear(uint16_t id)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_enemyMoveObjects.find(id);
	if (iter != m_enemyMoveObjects.end())
	{
		iter->second->removeFromParent();
		m_enemyMoveObjects.erase(iter);
	}
}

BattleObjectView *BattleSceneView::getObjectView(uint16_t id)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_enemyMoveObjects.find(id);
	if (iter != m_enemyMoveObjects.end())
		return iter->second;

	iter = m_friendMoveObjects.find(id);
	if (iter != m_friendMoveObjects.end())
		return iter->second;

	std::map<uint16_t, BattleStaticObjectView *>::iterator staticIter = m_enemyBuildings.find(id);
	if (staticIter != m_enemyBuildings.end())
		return staticIter->second;

	staticIter = m_friendBuildings.find(id);
	if (staticIter != m_friendBuildings.end())
		return staticIter->second;

	staticIter = m_enemyTowers.find(id);
	if (staticIter != m_enemyTowers.end())
		return staticIter->second;

	staticIter = m_friendTowers.find(id);
	if (staticIter != m_friendTowers.end())
		return staticIter->second;

	return nullptr;
}

BattleMoveObjectView *BattleSceneView::getMoveObjectView(uint16_t id)
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_enemyMoveObjects.find(id);
	if (iter != m_enemyMoveObjects.end())
		return iter->second;

	iter = m_friendMoveObjects.find(id);
	if (iter != m_friendMoveObjects.end())
		return iter->second;

	return nullptr;
}

BattleStaticObjectView *BattleSceneView::getStaticObjectView(uint16_t id)
{
	std::map<uint16_t, BattleStaticObjectView *>::iterator staticIter = m_enemyBuildings.find(id);
	if (staticIter != m_enemyBuildings.end())
		return staticIter->second;

	staticIter = m_enemyTowers.find(id);
	if (staticIter != m_enemyTowers.end())
		return staticIter->second;

	staticIter = m_friendBuildings.find(id);
	if (staticIter != m_friendBuildings.end())
		return staticIter->second;

	staticIter = m_friendTowers.find(id);
	if (staticIter != m_friendTowers.end())
		return staticIter->second;

	return nullptr;
}

template<class T>
static bool eraseFrom(std::map<uint16_t, T *> &objects, uint16_t id)
{
	typename std::map<uint16_t, T *>::iterator iter = objects.find(id);
	if (iter != objects.end())
	{
		objects.erase(iter);
		return true;
	}
	else
		return false;
}

bool BattleSceneView::isBattleVictory()
{
	return LuaLogicUtil::isBattleVictory();
}

bool BattleSceneView::isBattleFail()
{
	return LuaLogicUtil::isBattleFail();
}

void BattleSceneView::checkBattleResult()
{
	if (m_isSendedResult) return;

	if (isBattleVictory())
	{
		dealBattleFinished(true);
	}
	else if (isBattleFail())
	{
		dealBattleFinished(false);
	}
}

void BattleSceneView::dealBattleFinished(bool isWin)
{
	m_isBattleResult = true;
	m_isWin = isWin;
	beginRecycleRes();
	int battleType = MainScene::theScene()->getBattleType();
	if (battleType == MainScene::kBattleMagic || battleType == MainScene::kBattleElementStrom)
	{
		LoadingView *lv = MainScene::theScene()->getLoadingView();
		if (lv)
		{
			if (lv->getCurPreCalNum() < LoadingView::kPreCalNum)
			{
				lv->loadingCallBack(LoadingView::kPreCalNum - lv->getCurPreCalNum(),true);
			}
		}
	}
	LuaLogicUtil::dealBattleFinished(isWin);
}

int BattleSceneView::winStarRefreshQuery(std::vector<int> &retInfos, int passEvaluateTypes, int type, unsigned int index)
{
	return 2;
}

int BattleSceneView::winStar(std::vector<int> &star_infos, const std::vector<int> &passEvaluateTypes, int type, bool isBattleEnd)
{
	return 1;
}

void BattleSceneView::requestPvpResult()
{
}

void BattleSceneView::dealWithBattleResult(int battleResult)
{

}

void BattleSceneView::requestDungeonTrainingVictory()	//练兵副本
{
	
}

void BattleSceneView::onRequestDungeonTrainingVictoryReply(int cmd, void *buf, int len, bool isPerfect)
{
	
}

void BattleSceneView::requestDungeonEquipmentVictory() //讨伐群雄胜利
{

}

void BattleSceneView::onRequestDungeonEquipmentVictoryReply(int cmd, void *buf, int len, int star, std::vector<int> &star_infos)
{
}

void BattleSceneView::onRequestPveVictoryFailed(int code, const std::string &str)
{
	MainScene::theScene()->battleEnd();
}

void BattleSceneView::requestPveVictory()
{
	
}

void BattleSceneView::onRequestPveVictoryReply(int cmd, void *buf, int len)
{
	
}

void BattleSceneView::onRequestNormalVictoryFailed(int code, const std::string &str)
{
	MainScene::theScene()->battleEnd();
}

void BattleSceneView::requestNormalVictory()
{
	
}

void BattleSceneView::onRequestNormalVictoryReply(int cmd, void *buf, int len, int star, std::vector<int> &star_infos)
{
	
}

void BattleSceneView::requestArenaVictory()
{
}

void BattleSceneView::onRequestArenaVictoryReply(int ingot, int64_t upRank)
{

}

void BattleSceneView::requestArenaFailed()
{
}

void BattleSceneView::onRequestArenaFailedReply(int ingot)
{
	
}

static int getEnemyGeneralHp(int generalTid)
{
	BattleScene *scene = BattleScene::getCurrentScene();
	std::vector<BattleMoveObject *> generals = scene->getEnemyGenerals();
	for (size_t i = 0; i < generals.size(); ++i)
	{
		if (generals[i]->getTid() == generalTid)
		{
			return generals[i]->getHp();
		}
	}

	return 0;
}

static void getCrusadeEnemyGeneral(std::vector<CrusadeGeneral> *infos)
{
	
}


void BattleSceneView::handleCrusadeSpecialResult(bool isWin)
{
	
}

void BattleSceneView::onHandleCrusadeSpecialResultReply(int cmd, void *buf, int len, bool isWin)
{
	
}

void BattleSceneView::handleCrusadeResult(bool isWin)
{
	
}

void BattleSceneView::onHandleCrusadeResultReply(int cmd, void *buf, int len, bool isWin, int res, int mp, const std::vector<CrusadeGeneral> &generals)
{
	
}

static int getPlotId(int index)
{
	return -1;
}

void BattleSceneView::battleResult(bool isWin)
{
	//播放胜利动作
	if (BattleSceneView::getCurrentSceneView()->getIsBattleResult())
	{
		if ((BattleSceneView::getCurrentSceneView()->getIsWin()))
		{
			auto friendMOs = m_model->getFriendMoveObjects();
			for (auto friendIter = friendMOs.begin(); friendIter != friendMOs.end(); ++friendIter)
			{
				friendIter->second->setState(BattleObject::kWin);
			}
		}
		else
		{
			auto enemyMOs = m_model->getEnemyMoveObjects();
			for (auto friendIter = enemyMOs.begin(); friendIter != enemyMOs.end(); ++friendIter)
			{
				friendIter->second->setState(BattleObject::kWin);
			}
		}
	}
	m_model->pause();
	m_isSendedResult = true;

}

// 普攻的子弹;
void BattleSceneView::addBullet(const AttackTargetInfo &info)
{	
	int skillId = skill::getSkillId(info.skillLvId);
	BattleObjectView *attacker = getObjectView(info.attackerId);
	if(!attacker) return;

	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();

	//场上存在两个可以改变技能的武将时，因为子弹释放的延迟性，所以可能出现skillId 和 normalAttackSkillLvId 不一致的情况导致断言
	//assert(attacker->getModel()->getBattleEffect()->normalAttackSkillLvId == 0 || attacker->getModel()->isDefaultSkillId(skillId));
	std::string bulletRes = std::string(SKILL_BULLET_RES(skillId));
	const SkillProperty &skillPty = getSkillEffect(skillId);
	if (bulletRes.empty())
	{
		assert(false);
		BattleObjectView *target = getObjectView(info.targeterId);
		if (!target) return;
		genBattleReport(attacker->getModel(), info.targeterId, info.skillLvId, attacker->getModel()->getPixelPosition(), nullptr);
	}
	else
	{
		int flyType = SKILL_BULLET_FLY_TYPE(skillId);
		const CCPoint &attackerPos = attacker->getPosition();
		const GridPosition *pos = nullptr; 
		float w = 0.0f;
		float h = 0.0f;
		CCPoint targetPoint;
		PixelPoint targetPos;
		if (attacker)
		{
			w = (skillPty.bulletStartPoint[0].x - 6.0f) * attacker->getContentSize().width;
			h = (skillPty.bulletStartPoint[0].y - 6.0f) * attacker->getContentSize().height;
		}

		if(info.targetType == AttackTargetInfo::kObject)
		{
			BattleObject *targeter = BattleScene::getCurrentScene()->getObject(info.targeterId);
			if (!targeter) return;
			pos = &(targeter->getGridPosition());

			targetPos = GridUtil::sharedGridUtil().gridToPix(*pos);
			BattleObjectView *target = getObjectView(info.targeterId);
			if(!target) return;
			const Size &targetSize = target->getContentSize();
			targetPoint.x = targetPos.x;

			if (m_model->getObjectType(target->getModel()->getId()) == BattleScene::kMoveObj)
			{
				targetPoint.x = target->getPositionX();
				targetPoint.y = target->getPositionY() + targetSize.height * 0.5f;
			}
			else
			{
				CCPoint hitPoint;
				bool result = ResourceBattleData::theMgr().getHittedPoint(&hitPoint, target->getResPath().c_str());
				if(result)
				{
					targetPoint = ccpAdd(target->getPosition(), effectHangPointPos(target, hitPoint, false));
				}
				else
				{
					targetPoint.y = targetPos.y + targetSize.height * 0.25f;
				}
			}
		}
		else
		{
			pos = &(info.targeterPos);

			targetPos = GridUtil::sharedGridUtil().gridToPix(*pos);
			targetPoint.x = targetPos.x;
			targetPoint.y = targetPos.y;
		}

		int attackerToward = attacker->getModel()->getToward();
		CCPoint pt = attacker->getEffectHangPointPos(skillPty.bulletStartPoint[getIndexWithTowardByStartPoint(attackerToward)], shouldSetFilp(attackerToward));

		IntervalAnimationDisplayNode *bulletSp = IntervalAnimationDisplayNode::create(bulletRes.c_str()
			, attackerPos.x + pt.x > targetPoint.x);
		float bulletScale = skillPty.bulletScale;
		if (attacker->getModel()->getGameSoldier())
		{
			BattleMoveObjectView *attBMV = dynamic_cast<BattleMoveObjectView *>(attacker);
			bulletScale = skillPty.bulletScale * attBMV->getSelectScale();  //军团部队士兵缩小对子弹的影响
		}
		bulletSp->setScaleValue(bulletScale);
		float minAtkAreaRadius =  sqrtf(static_cast<float>(pt.x*pt.x + pt.y*pt.y));
		bool isInMinAtkArea = isInCircle(ccp(targetPos.x, targetPos.y), attackerPos, minAtkAreaRadius);
		
		if ( isInMinAtkArea && (info.targetType == AttackTargetInfo::kObject) ) 
		{
			bulletSp->setVisible(false);		
		}

		CCBullet *bullet = CCBullet::create(
			ccp(attackerPos.x + pt.x,
			attackerPos.y + pt.y)
			, targetPoint
			, bulletSp
			, flyType);

		int bulletZorder = skill::kBulletZorder;
		int toward = calcToward(attackerPos, targetPoint);
		switch(toward)
		{
		case BattleObject::kRightDown:
		case BattleObject::kLeftDown:
			{
				bulletZorder = skill::kBulletCoverGeneralZorder;
				break;
			}
		}
		bullet->setAttacker(attacker->getModel());
		int skillHitType = SKILL_HIT_TYPE(skillId);
		float bulletSpeed = skillPty.bulletSpeed / scaleFactor;
		float scale = attacker->getCurAttackFrameIntervalScale();
		bullet->setSpeed(bulletSpeed / sqrtf(scale));
		bullet->setSpeedY(skillPty.bulletSpeedY / scaleFactor);
		m_map->addChild(bullet, bulletZorder);

		if (skillHitType == kTarget)
		{
			uint16_t targetId = info.targeterId;

			bullet->setHandler(std::bind(genBulletBattleReport, attacker->getModel(), targetId, info.skillLvId));

			int type = m_model->getObjectType(targetId);
			if (type == BattleScene::kMoveObj)
			{
				BattleMoveObject *obj = m_model->getMoveObject(targetId);
				if (obj)
				{
					bullet->setModel(obj);
				}
			}
		}
		else
		{		
			bullet->setHandler(std::bind(&BattleSceneView::onBulletReachDest, this, info.skillLvId, targetPoint, attacker->getModel(), info.attackerId, true, bullet->getCalcHurtAttackProp()));					
		}
	}
}

// 弹射的子弹
void BattleSceneView::addBulletCentesis(const AttackTargetInfo &info, const skill::SpecialFxData & fxdata)
{	
	int skillId = skill::getSkillId(info.skillLvId);
	BattleObjectView *attacker = getObjectView(info.attackerId);
	if(!attacker) return;

	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();

	//assert(attacker->getModel()->getBattleEffect()->normalAttackSkillLvId == 0 || attacker->getModel()->isDefaultSkillId(skillId));
	std::string bulletRes = std::string(SKILL_BULLET_RES(skillId));
	const SkillProperty &skillPty = getSkillEffect(skillId); 

	uint16_t lastDefenderId  = attacker->getModel()->getLastDefenderId();

	if (bulletRes.empty())
	{
		assert(false);
		BattleObjectView *target = getObjectView(lastDefenderId);
		if (!target) return;
		genBattleReport(attacker->getModel(), lastDefenderId, info.skillLvId, attacker->getModel()->getPixelPosition(), nullptr);
	}
	else
	{
		BattleObject *starter = BattleScene::getCurrentScene()->getObject(lastDefenderId);
		BattleObjectView * starterView = getMoveObjectView(lastDefenderId);
		if (!starter) return;

		PixelPoint startPos = starter->getPixelPosition();

		TargetSelect::UnitType targetType = static_cast<TargetSelect::UnitType>(SKILLLOGIC_OBJ_TYPE(skill::getSkillId(info.skillLvId)));
		set<uint16_t> objects;
		CCPoint startGridPos = GridUtil::sharedGridUtil().pixToFloatGrid(startPos);
		CCPoint direction = getDirection(ccp(attacker->getModel()->getGridPosition().x, attacker->getModel()->getGridPosition().y), startGridPos);
		calcObjsInSectorRange(&objects, BattleScene::getCurrentScene()->getTerrain(), starter->getParty(), targetType, startGridPos, direction,fxdata.data2,fxdata.data4);

		bool needReturn = true;
		uint16_t enderId = 0;
		for (auto iter = objects.begin(); iter != objects.end(); ++iter)
		{
			if (*iter != info.targeterId)
			{
				needReturn = false;
				enderId = *iter;
			}
		}

		if (needReturn)
		{
			return;
		}

		int flyType = SKILL_BULLET_FLY_TYPE(skillId);		
		const GridPosition *pos = nullptr; 
		float w = 0.0f;
		float h = 0.0f;
		CCPoint targetPoint;
		PixelPoint targetPos;
		if (starterView)
		{
			w = (skillPty.bulletStartPoint[0].x - 6.0f) * starterView->getContentSize().width;
			h = (skillPty.bulletStartPoint[0].y - 6.0f) * starterView->getContentSize().height;
		}

		//弹射子弹必须是打目标才能够弹射
		BattleObject *ender = BattleScene::getCurrentScene()->getObject(enderId);
		BattleObjectView * enderView = getMoveObjectView(enderId);
		if (!ender || !enderView) return;
		pos = &(ender->getGridPosition());
		targetPos = GridUtil::sharedGridUtil().gridToPix(*pos);
		
		const Size &targetSize = enderView->getContentSize();
		targetPoint.x = targetPos.x;

		if (m_model->getObjectType(enderView->getModel()->getId()) == BattleScene::kMoveObj)
		{
			targetPoint.y = targetPos.y + targetSize.height * 0.5f;
		}
		else
		{
			CCPoint hitPoint;
			bool result = ResourceBattleData::theMgr().getHittedPoint(&hitPoint, enderView->getResPath().c_str());
			if(result)
			{
				targetPoint = ccpAdd(enderView->getPosition(), effectHangPointPos(enderView, hitPoint, false));
			}
			else
			{
				targetPoint.y = targetPos.y + targetSize.height * 0.25f;
			}
		}

		int attackerToward = attacker->getModel()->getToward();
		CCPoint pt = attacker->getEffectHangPointPos(skillPty.bulletStartPoint[getIndexWithTowardByStartPoint(attackerToward)], shouldSetFilp(attackerToward));

		IntervalAnimationDisplayNode *bulletSp = IntervalAnimationDisplayNode::create(bulletRes.c_str()
			, startPos.x > targetPos.x);

		float minAtkAreaRadius =  sqrtf(static_cast<float>(pt.x*pt.x + pt.y*pt.y));
		bool isInMinAtkArea = isInCircle(ccp(targetPos.x, targetPos.y),ccp(startPos.x, startPos.y),minAtkAreaRadius);
	
		if ( isInMinAtkArea && (info.targetType == AttackTargetInfo::kObject) ) 
		{
			bulletSp->setVisible(false);		
		}

		CCBullet *bullet = CCBullet::create(
			ccp(startPos.x + pt.x,
			startPos.y + pt.y)
			, targetPoint
			, bulletSp
			, flyType);
		bullet->setAttacker(attacker->getModel());
		int skillHitType = SKILL_HIT_TYPE(skillId);

		int bulletCetesisTime = ((int)fxdata.data1)-1;
		bullet->setTargetInfo(info);
		bullet->setBulletEntesisTime(bulletCetesisTime);
		bullet->setAtkAngle(fxdata.data2);
		bullet->setAtkHurtPercent(fxdata.data3);
		bullet->setAtkRadius(fxdata.data4);

		float bulletSpeed = skillPty.bulletSpeed/ scaleFactor;
		float scale = attacker->getCurAttackFrameIntervalScale();
		bullet->setSpeed(bulletSpeed / sqrtf(scale));
		m_map->addChild(bullet, skill::kBulletZorder);


		if (skillHitType == kTarget)
		{
			uint16_t targetId = enderId;
			bullet->setHandler(std::bind(genBulletCentesisBattleReport, attacker->getModel(), targetId, info.skillLvId, bullet->getCalcHurtAttackProp()));

			int type = m_model->getObjectType(targetId);
			if (type == BattleScene::kMoveObj)
			{
				BattleMoveObject *obj = m_model->getMoveObject(targetId);
				if (obj)
				{
					bullet->setModel(obj);
				}
			}
		}
		else
		{		
			assert(false);
			//bullet->setHandler(std::bind(&BattleSceneView::onBulletReachDest, this, info.skillLvId, targetPoint, attacker->getModel(), info.attackerId, true, bullet->getCalcHurtAttackProp()));		
		}
	}
}


void BattleSceneView::onAttackBegin(const AttackTargetInfo &targetInfo)
{
	BattleObjectView *attacker = getObjectView(targetInfo.attackerId);
	if(!attacker)
	{
		ERROR_MSG("BattleSceneView::onAttackBegin: attacker is nullptr");
		//assert(false && "See the console for error message");
		return;
	}
	if(!attacker->getModel())
	{
		ERROR_MSG("BattleSceneView::onAttackBegin: attacker->getModel is nullptr");
		//assert(false && "See the console for error message");
		return;
	}

	CCPoint targetPos;
	if(targetInfo.targetType == AttackTargetInfo::kObject)
	{
		BattleObjectView *targeter = getObjectView(targetInfo.targeterId);
		if(!targeter)
		{
			ERROR_MSG("BattleSceneView::onAttackBegin: targeter is nullptr");
			//assert(false && "See the console for error message");
			return;
		}
		targetPos = targeter->getPosition();
	}
	else
	{
		PixelPoint targetPixel = GridUtil::sharedGridUtil().gridToPix(targetInfo.targeterPos);
		targetPos.setPoint(targetPixel.x, targetPixel.y);
	}

	attacker->getModel()->setToward(attacker->getPosition(), targetPos);
	attacker->attack(targetInfo.skillLvId, targetPos, true);
	handleAttackTargetInfo(targetInfo);
}

void BattleSceneView::reOrder()
{
	std::map<uint16_t, BattleMoveObjectView *>::iterator iter = m_enemyMoveObjects.begin();
	for (; iter != m_enemyMoveObjects.end(); ++iter)
	{
		int zOrder = zOrderOf(iter->second->getModel());
		if (iter->second->getModel()->isInTransparent())
		{
			zOrder += skill::kMaxZOrder;
		}
		m_map->reorderChild(iter->second, zOrder);
	}

	iter = m_friendMoveObjects.begin();
	for (; iter != m_friendMoveObjects.end(); ++iter)
	{
		BattleMoveObject *model = iter->second->getModel();
		int zOrder = zOrderOf(model);
		if (model->isInTransparent())
		{
			zOrder += skill::kMaxZOrder;
		}
		m_map->reorderChild(iter->second, zOrder);
	}

	for(auto it = m_deadBodys.begin(); it != m_deadBodys.end(); ++it)
	{
		int zOrder = zOrderOf(*it);
		m_map->reorderChild(*it, zOrder);
	}
}

void BattleSceneView::onSkillSelected(uint16_t attackerId, const SkillGroupInfo &info)
{
	int skillId = info.skill_group_id;
	int skillLevelId = skill::getSkillLvId(skillId, info.level);

	bool isReleaseSkill = SKILLGROUP_RELEASE_TYPE(skillId) == 0;
	bool isActiveSkill = SKILLGROUP_SKILL_TYPE(skillId) == 1;  //是否主动技
	int defaultScope = SKILL_DEFAULT_SCOPE(skillId);

	SkillInfo skillInfo(info.skill_group_id, info.level);
	PixelPoint targetPixPos;
	bool canGetTarget = isReleaseSkill ? false : skill::getAiTargetPosition(&targetPixPos, attackerId, skillInfo);

	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	skill::SpecialFxData data;
	//程序需求 #2442  主动技没有目标时按照默认方向和配置的默认距离作为释放目标
	if ( (!canGetTarget) && isActiveSkill)
	{		
		cocos2d::CCPoint virtualTarget = ccpAdd(attacker->getFloatGridPosition(),ccp(0,defaultScope)) ;
		PixelPoint pixPos = GridUtil::sharedGridUtil().floatGridToPix(virtualTarget.x,virtualTarget.y);	
		targetPixPos.x =  (int16_t)pixPos.x ;
		targetPixPos.y =  (int16_t)pixPos.y;
		data.targetPos.x = (float)virtualTarget.x;
		data.targetPos.y = (float)virtualTarget.y;
	}

	BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
	skill::SkillResult sr;


	CCPoint targetPos(targetPixPos.x, targetPixPos.y);
	if (!isReleaseSkill && !canGetTarget)
	{
		if (!m_model->getIsInAutoBattleMode())
		{
			if(attacker->getParty() == kFriendParty && !attacker->isMonster() && attacker->getType() == BattleMoveObject::kGeneral)
			{
				releaseSkillFocusTo(attackerId, skillInfo, ccpAdd(attackerView->getPosition(), skill::kReleaseOffsetPos), std::bind(&BattleSceneView::onUseSkillFocusToFinished, this, sr, data, attackerId, skillInfo, targetPos, true));
			}
		}

		return;
	}

	bool isAutoSkill = (SKILLGROUP_RELEASE_TYPE(skillId) == 0 || m_model->getIsInAutoBattleMode());
	bool isUseSuccess = isAutoSkill ? canUseSkill(&sr, &data, attackerId, skillInfo, false, targetPos, false) : true;
	if (!isUseSuccess && m_model->getIsInAutoBattleMode()) 
	{
		removeBlackLayer(attackerId);
		return;
	}

	if(attacker->getParty() == kFriendParty && !attacker->isMonster() && attacker->getType() == BattleMoveObject::kGeneral)
	{
		if (m_model->getIsInAutoBattleMode())
		{
			//onUseSkillFocusToFinished(sr, data, attackerId, skillInfo, targetPos, isUseSuccess);
			releaseSkillFocusTo(attackerId, skillInfo, ccpAdd(attackerView->getPosition(), skill::kReleaseOffsetPos) , std::bind(&BattleSceneView::onUseSkillFocusToFinished, this, sr, data, attackerId, skillInfo, targetPos, isUseSuccess));
		}
		else
		{
			releaseSkillFocusTo(attackerId, skillInfo, ccpAdd(attackerView->getPosition(), skill::kReleaseOffsetPos) , std::bind(&BattleSceneView::onUseSkillFocusToFinished, this, sr, data, attackerId, skillInfo, targetPos, isUseSuccess));
		}		
	}
}

BattleSceneView *BattleSceneView::withModel(BattleScene *model)
{
	BattleSceneView *bs = new BattleSceneView(model);
	bs->autorelease();
	s_curSceneView = bs;

	return bs;
}

CCAction *BattleSceneView::getSceneShakeAction(int id)
{
	if(m_isShaking || m_isTouch || id == 0) return nullptr;

	const vector<float> &v = DEFAULTVALUE_VALUE(id);
	assert(v.size() == 4);

	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();

	CCCallFunc	*shake = CCCallFunc::create(this, callfunc_selector(BattleSceneView::shake));
	CCShake *dampShake = CCShake::createDampShake(v[0], v[1] / scaleFactor, v[2] / scaleFactor, v[3]);
	dampShake->setStartPosition(getPosition());
	CCTargetedAction *shakeAction = CCTargetedAction::create(this, dampShake);
	CCCallFunc	*unShake = CCCallFunc::create(this, callfunc_selector(BattleSceneView::unShake));
	return CCSequence::create(shake, shakeAction, unShake, nullptr);
}

void BattleSceneView::onBattleTimeChanged()
{
	
}

static const int kStopSoldierSoundNum = 1;
void BattleSceneView::onSoldierAttackNumChanged(int soldierBattleSoundId)
{
	
}

void BattleSceneView::pauseAmbient()
{
	IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
	if (audioEx)
	{
		audioEx->stopAmbient();
		m_isPlaying = false;
	}
}
void BattleSceneView::reusmeAmbient()
{
	onMoveObjAttackMoveObjNumChanged();
}
static const int kPlayAtmosphereSoundNum = 15;
static const int kStopAtmosphereSoundNum = 1;
void BattleSceneView::onMoveObjAttackMoveObjNumChanged()
{
	if (m_isBattleResult)
	{
		return;
	}
	int num = m_model->getMoveObjAttackMoveObjNum();
	if(num >= kPlayAtmosphereSoundNum)
	{
		if(!m_isPlaying)
		{
			IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
			if (audioEx)
			{
				audioEx->playAmbient(PASS_ATMOSPHERE_AUDIO(MainScene::theScene()->getCurPassId()));
			}
			m_isPlaying = true;
		}
	}
	else if(num < kStopAtmosphereSoundNum)
	{
		if(m_isPlaying)
		{
			IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
			if (audioEx)
			{
				audioEx->keyoffAmbient();
			}
			m_isPlaying = false;
		}
	}
}


void BattleSceneView::setMapScale(float scaleValue)
{
	assert(false && "sorry, no longer supported");
}

void BattleSceneView::setGeneralScale(float scaleValue)
{
	map<uint16_t, BattleMoveObjectView *>::iterator iter;
	for(iter = m_friendMoveObjects.begin(); iter != m_friendMoveObjects.end(); ++iter)
	{
		if(iter->second->getModel()->getType() == BattleMoveObject::kGeneral)
		{
			iter->second->setScaleValue(scaleValue);
		}
	}

	for(iter = m_enemyMoveObjects.begin(); iter != m_enemyMoveObjects.end(); ++iter)
	{
		if(iter->second->getModel()->getType() == BattleMoveObject::kGeneral)
		{
			iter->second->setScaleValue(scaleValue);
		}
	}
}

void BattleSceneView::setSoldierScale(float scaleValue)
{
	map<uint16_t, BattleMoveObjectView *>::iterator iter;
	for(iter = m_friendMoveObjects.begin(); iter != m_friendMoveObjects.end(); ++iter)
	{
		if(iter->second->getModel()->getType() == BattleMoveObject::kSoldier)
		{
			iter->second->setScaleValue(scaleValue);
		}
	}

	for(iter = m_enemyMoveObjects.begin(); iter != m_enemyMoveObjects.end(); ++iter)
	{
		if(iter->second->getModel()->getType() == BattleMoveObject::kSoldier)
		{
			iter->second->setScaleValue(scaleValue);
		}
	}
}

void BattleSceneView::setStaticObjScale(float scaleValue)
{
	map<uint16_t, BattleStaticObjectView *>::iterator iter;
	for(iter = m_friendBuildings.begin(); iter != m_friendBuildings.end(); ++iter)
	{
		iter->second->setScaleValue(scaleValue);
	}
	for(iter = m_enemyBuildings.begin(); iter != m_enemyBuildings.end(); ++iter)
	{
		iter->second->setScaleValue(scaleValue);
	}
	for(iter = m_friendTowers.begin(); iter != m_friendTowers.end(); ++iter)
	{
		iter->second->setScaleValue(scaleValue);
	}
	for(iter = m_enemyTowers.begin(); iter != m_enemyTowers.end(); ++iter)
	{
		iter->second->setScaleValue(scaleValue);
	}
}


void BattleSceneView::exitBattle()
{
	
}

void BattleSceneView::onGridFriendObjectDead(int x, int y, bool isClear)
{
	const PixelPoint &pt = GridUtil::sharedGridUtil().gridToPix(GridPosition(x, y));
	EffectDisplay *effect = EffectDisplay::withRes("res/effects/fireball", 0.0f, 0.0f, ccp(pt.x, pt.y));
	m_map->addChild(effect, 10);

	if (isClear)
	{
		BattleScene::IDMoveObject friendObjects = m_model->getFriendMoveObjects();
		if (!friendObjects.empty())
		{
			BattleScene::IDMoveObject::iterator iter = friendObjects.begin();
			for (; iter != friendObjects.end(); ++iter)
			{
				iter->second->suicide();
			}
		}

		CCCallFunc *func = CCCallFunc::create(this, callfunc_selector(BattleSceneView::exitBattle));
		runAction(CCSequence::create(CCDelayTime::create(2.0f), func, nullptr));

		
	}
}

void BattleSceneView::addBulletAction(const CCPoint &start, const CCPoint &dest, bool isClear)
{
	const GridPosition gridPt = GridUtil::sharedGridUtil().pixToGrid(PixelPoint((int16_t)dest.x, (int16_t)dest.y));
	float dis = ccpDistance(start, dest);
	float speed = dis / 1.5f;
	IntervalAnimationDisplayNode *node = IntervalAnimationDisplayNode::create("res/effects/fireball_fly", true, false);
	CCBullet *bullet = CCBullet::create(start, dest, node, CCBullet::kCurveType);
	bullet->setSpeed(speed);
	bullet->setCannotPause(true);
	bullet->setHandler(std::bind(&BattleSceneView::onGridFriendObjectDead, this, (int)gridPt.x, (int)gridPt.y, isClear));
	m_map->addChild(bullet, 10000);
}

void BattleSceneView::battleFailedAction()
{
	m_model->pause();
	const Size &size = CCDirector::sharedDirector()->getWinSize();
	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();

	const CCPoint &position = getPosition();

	/*int i = 0;
	while (i < 20)
	{
		int randX = getRandNum(50, (int)size.width - 50);
		int randY = getRandNum(50, (int)size.height - 50);
		PixelPoint pt = PixelPoint((int16_t)(-position.x + randX), (int16_t)(-position.y + randY));
		const GridPosition &gridPt = GridUtil::sharedGridUtil().pixToGrid(pt);
		addBulletAction(ccp(-position.x + size.width + 100.0f / scaleFactor, -position.y + size.height - 100.0f / scaleFactor), ccp(pt.x, pt.y), i == 0);
		++i;
	}*/

	
}

void BattleSceneView::showBattleResultPanel()
{
}

void BattleSceneView::showVictoryPanel()
{
	CCCallFunc *func = CCCallFunc::create(this, callfunc_selector(BattleSceneView::showBattleResultPanel));
	runAction(CCSequence::create(CCDelayTime::create(1.0f), func, nullptr));
}

void BattleSceneView::beginRecycleRes()
{
	INFO_MSG("BattleSceneView::beginRecycleRes");
	for(auto it = m_friendMoveObjects.begin(); it != m_friendMoveObjects.end(); ++it)
	{
		it->second->beginRecycleGeneralRes(BattleMoveObjectView::kRecycleSkill);
	}

	for(auto it = m_enemyMoveObjects.begin(); it != m_enemyMoveObjects.end(); ++it)
	{
		it->second->beginRecycleGeneralRes(BattleMoveObjectView::kRecycleSkill);
	}

	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillBeforeUseEffSkyUpName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillBeforeUseEffMiddleUpName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillBeforeUseEffBaseDownName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillTargetMarkEffName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillWaitingForTargetBaseEffName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillWaitingForTargetMiddleEffName);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillWaitingForTargetBaseEffName2);
	RecycleMgr::theMgr().addCanRecycleResource(skill::kSkillWaitingForTargetMiddleEffName2);

	RecycleMgr::theMgr().addCanRecycleResource("res/effects/soldier_appearance_blossom");
}

void BattleSceneView::onFocusFinished()
{
	if(m_lastBoss)
	{
		BattleObjectView::HitSkillDir data;
		data.skillId = 0;
		data.dir = 0;
		m_lastBoss->playDeadEffect(data);
	}

	showVictoryPanel();
}

void BattleSceneView::runScaleAction(float scale)
{
}

void BattleSceneView::setSceneScale(float scale)
{
	m_mapScale = scale;
	m_map->setScale(scale);
	m_hpChangedValue->setScale(scale);
}

void BattleSceneView::removeHelper(cocos2d::Node *node, void *data)
{
	Node *removeNode = (Node *)data;
	removeNode->removeFromParent();
}

cocos2d::CCPoint BattleSceneView::getCurScreenCenterPos()
{
	const Size &size = CCDirector::sharedDirector()->getWinSize();
	return ccp(-getPositionX() + 0.5f * size.width, -getPositionY() + 0.5f * size.height);
}

BattleResourcePickUpLayer * BattleSceneView::createBattleResourcePickUpLayer( float resource, const cocos2d::CCPoint &position, bool isAutoPickUp, const std::string &resIconPath, float resUnit)
{
	BattleResourcePickUpLayer *resPickUpLayer = nullptr;

	float displayDuration = BATTLEPARA_VALUE("food_gain_time");
	float radius  = BATTLEPARA_VALUE("food_scatter_area");
	if (resUnit < 0)
	{
		resUnit = BATTLEPARA_VALUE("food_icon_value");
	}
	float autoRadius = BATTLEPARA_VALUE("auto_scatter_area");

	resPickUpLayer = BattleResourcePickUpLayer::create(kTouchPriority_BattleLayer - 5, resource, 
		position, isAutoPickUp, resUnit, radius, displayDuration, autoRadius, resIconPath);
	resPickUpLayer->setPickUpResCallBack([=](float count){
		m_model->addBattleResource(static_cast<float>(count), false);
	});
	resPickUpLayer->setRemovedCallback([=](){
		m_battleResourcePickUpLayers.erase(resPickUpLayer);
	});
	resPickUpLayer->setPosition(m_map->convertToNodeSpace(ccp(0, 0)));
	m_battleResourcePickUpLayers.insert(resPickUpLayer);				// 保存粮草拾取层，用于游戏暂停时，暂停粮草拾取计时;

	return resPickUpLayer;
}

void BattleSceneView::requestHandleRewardDungeonVictory()
{
	/*auto model = GameDungeonArmyRewardModel::getInstance();

	auto challengeResultCallback = [=](const std::vector<ItemInfo> &items){
		std::vector<ItemInfo> rewardItems;
		for (auto it = items.begin(); it != items.end(); ++it )
		{
            if((*it).item_amount > 0)
            {
                rewardItems.push_back( *it );
            }
		}

		const Size &size = CCDirector::sharedDirector()->getWinSize();
		CCPoint center = getCurScreenCenterPos();
		PixelPoint bossPosition;
		if(m_lastBoss && m_lastBoss->getModel())
		{
			bossPosition = m_lastBoss->getModel()->getPixelPosition();
		}
		else
		{
			bossPosition.x = static_cast<int16_t>(center.x) + 2;
			bossPosition.y = static_cast<int16_t>(center.y) + 2;
		}
		const Size &mapSize = m_map->getContentSize();
		if (bossPosition.x + size.width * 0.5f > mapSize.width) bossPosition.x = (int16_t)(mapSize.width - size.width * 0.5f);
		if (bossPosition.y + size.height * 0.5f > mapSize.height) bossPosition.y = (int16_t)(mapSize.height - size.height * 0.5f);

		m_victoryPanel = BattleVictoryDungeonRewardPanel::create(kTouchPriority_Dialog, rewardItems);

		m_victoryPanel->setAnchorPoint(ccp(0.5f, 0.5f));
		m_victoryPanel->setPosition(ccp(size.width/2, size.height/2));
		m_victoryPanel->focusToAction(center, ccp((float)bossPosition.x, (float)bossPosition.y));
		m_victoryPanel->setHandler(std::bind(&BattleSceneView::onFocusFinished, this));
		MainScene::theScene()->addChild(m_victoryPanel, kZOrderDialog);
	};

	bool isVictory = true;
	model->requestHandleChallengeResult(isVictory, challengeResultCallback);*/
}

void BattleSceneView::onBattleStarInfoRefresh()
{
}

void BattleSceneView::onEnemyEnterMyArea(char myParty, uint16_t enemyId)
{

}
bool BattleSceneView::onTrapUseSkill(uint16_t objectId, const SkillGroupInfo &skillGroupInfo, bool isNormalAttackSkill)
{
	BattleBuilding *attacker = m_model->getBuilding(objectId);
	if (attacker == nullptr) return false;
	TargetSelectMgr::theMgr().resetPoint();
	skill::SkillResult sr;
	skill::SpecialFxData data;
	SkillInfo skillInfo = SkillInfo(skillGroupInfo.skill_group_id, skillGroupInfo.level);

	
	BattleStaticObjectView *attackerView = getStaticObjectView(objectId);
	if (!attackerView) return false;

	bool isUseSuccess = false;
	skill::SkillType skillType = skill::kTypeAttack;
	int modType = SKILLLOGIC_MOD_TYPE(skillInfo.skill_id);

	skillType = skill::handleSkillAttackTarget(&isUseSuccess, &sr, &data, objectId, skillInfo);

	if (skillType == skill::kTypeSpecial && isUseSuccess)
	{
		isUseSuccess = isShouldAutoReleaseSpecialSkill(&data, objectId, skillInfo);
	}

	//useSkill(sr, data, objectId, skillInfo, isNormalAttackSkill);


	//BattleMoveObjectView * battleMoveView = dynamic_cast<BattleMoveObjectView *>(attackerView);
	//BattleMoveObject * battleMoveObj = dynamic_cast<BattleMoveObject *>(attacker);
	BattleReport report = skill::getSkillReport(sr);
	report.isNormalAttackSkill = isNormalAttackSkill;

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	skillType = static_cast<skill::SkillType>(SKILLLOGIC_TYPE(skillInfo.skill_id));
	modType = SKILLLOGIC_MOD_TYPE(skillInfo.skill_id);

	PixelPoint pix = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
	CCPoint pt(pix.x, pix.y);

	std::string bulletRes = std::string(SKILL_BULLET_RES(skillInfo.skill_id));

	bool isMyselfActiveSkill = true;  //是否自己的主动技

	if (attacker->getParty() == kFriendParty  && isMyselfActiveSkill
		&& (bulletRes.empty() || modType == skill::kHitRangeTypeNone))
	{
		float scaleNum = 1.0f;
		if (modType == skill::kHitRangeTypeCircle || modType == skill::kHitRangeTypeOutCircle)
		{
			const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
			if (v[0] > 0)
			{
				float radius = v[0] * 0.5f;
				scaleNum = radius / skill::kTargetMarkOriginalRadiusGrid;
			}
		}
		cocos2d::Sprite * showTargePosEff = cocos2d::Sprite::create(skill::kSkillTargetMarkEffName.c_str());
		showTargePosEff->setPosition(pt);
		//showTargePos->setScale(scaleNum);
		CCSequence *seq = CCSequence::create(CCFadeTo::create(1.0f, 0), CCRemoveSelf::create(true), nullptr);
		showTargePosEff->runAction(seq);
		getLayer()->addChild(showTargePosEff, 0);
	}

	if (skillType == skill::kTypeAttack)
	{
		if (modType != skill::kHitRangeTypeCircle && modType != skill::kHitRangeTypeNone && modType != skill::kHitRangeTypeCross)
		{
			PixelPoint targetPoint = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
			attacker->setToward(attackerView->getPosition(), ccp(targetPoint.x, targetPoint.y));
		}

		attackerView->attack(skillLevelId, pt, isNormalAttackSkill);

		if (modType == skill::kHitRangeTypeOutCircle)
		{
			std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
			if (!effectStr.empty())
			{
				SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, 0.0f, data.data1, pt, m_map);
				pEffect->setAnchorPoint(ccp(0, 0));
				pEffect->setPosition(pt);
				addChild(pEffect, 10);
			}
		}

		handleReport(attacker, report, false);
	}
	else if (skillType == skill::kTypeNormal)
	{
		attackerView->attack(skillLevelId);
		std::string effectStr = std::string(SKILL_SKILL_EFFECT(skillInfo.skill_id));
		if (!effectStr.empty())
		{
			SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skillInfo.skill_id, 0.0f, 0.0f, pt, m_map);
			pEffect->setAnchorPoint(ccp(0, 0));
			pEffect->setPosition(pt);
			addChild(pEffect, 10);
		}

	}
	else if (skillType == skill::kTypeSpecial)
	{
		skill::SpecialFxType type = data.type;
		if (type == skill::kAttackHittingFrame) // kAttackHittingFrame类型必须先调用attack（因为addHittingFrame()要访问m_attackEffects数据），所以这里特殊处理
		{
			attackerView->attack(skillLevelId);
			attackerView->addHittingFrame(skillInfo, data);
		}
		else
		{
			if (modType != skill::kHitRangeTypeCircle)
			{
				PixelPoint targetPoint = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
				PixelPoint attackPoint = attackerView->getModel()->getPixelPosition();
				attacker->setToward(ccp(attackPoint.x, attackPoint.y), ccp(targetPoint.x, targetPoint.y));
			}

			if (!handleSpecialFxData(attackerView, objectId, skillInfo, data))
			{
				return false;
			}

			if (type == skill::kStaticWhirlWind || type == skill::kChainLightning
				|| type == skill::kChainCure || type == skill::kCureOrFireflag || type == skill::kInvincibleFastCut || type == skill::kChainDamage)
			{
				attackerView->attack(skillLevelId);
			}
			else
			{
				PixelPoint pix = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
				attackerView->attack(skillLevelId, ccp(pix.x, pix.y));
			}
		}
	}

	if (!isNormalAttackSkill)
	{
		switch (modType)
		{
		case skill::kHitRangeTypeCircle:
		case skill::kHitRangeTypeOutCircle:
		case skill::kHitRangeTypeSector:
		case skill::kHitRangeTypeRect:
		case skill::kHitRangeTypeScreenRect:
		case skill::kHitRangeTypeCross:
		{
			if ((!bulletRes.empty()))
			{
				if (attackerView->getModel()->getParty() == kFriendParty) //敌人不显示攻击方向指示;
				{
					PixelPoint endPos = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
					PixelPoint attackerPos = attackerView->getModel()->getPixelPosition();
					showSkillDirection(attacker, ccp(attackerPos.x, attackerPos.y), ccp(endPos.x, endPos.y), skillInfo);
				}
			}
			break;
		}
		default:
		{
			break;
		}
		}
	}

	BattleScene *scene = BattleScene::getCurrentScene();
	set<uint16_t> objects = TargetSelectMgr::theMgr().getObjects();
	TargetSelectMgr::theMgr().setBuilding(attacker);
	if (!(skillType == skill::kTypeSpecial && skill::kPyrosphere == data.type))
	{
		skill::doBuff(scene, attacker, objects, skillLevelId, TargetSelect::kTargetOpponent);
	}
	skill::doNormalFx(scene, attacker, objects, skillLevelId, TargetSelect::kTargetOpponent);

	return true;

}


bool BattleSceneView::onObjectUseSkill(uint16_t objectId, const SkillGroupInfo &skillGroupInfo, bool isNormalAttackSkill)
{
	BattleMoveObject *attacker = m_model->getMoveObject(objectId);
	if(attacker == nullptr) return false;
	TargetSelectMgr::theMgr().resetPoint();
	skill::SkillResult sr;
	skill::SpecialFxData data;
	SkillInfo skillInfo = SkillInfo(skillGroupInfo.skill_group_id, skillGroupInfo.level);
	
	bool isUseSuccess = canUseSkill(&sr, &data, objectId, skillInfo, isNormalAttackSkill, cocos2d::Vec2(0, 0), false, false);

	if (isUseSuccess && useSkill(sr, data, objectId, skillInfo, isNormalAttackSkill))
	{
		attacker->afterUseSkill(skill::getSkillLvId(skillGroupInfo.skill_group_id, skillGroupInfo.level));
		return true;
	}

	return false;
}

void BattleSceneView::onShapeChangeUseSkillFocusToFinished(const skill::SkillResult &sr, const skill::SpecialFxData &data, uint16_t attackerId, const SkillInfo &skillInfo, bool isUseSuccess, SpeakType speakType, int speakTextId, float speakLastTime)
{
	//BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
	////策划需求：战场技能过程中要屏蔽点击
	//int zOrder = 100000;	
	//m_map->reorderChild(attackerView, zOrder + 1);

	//m_shouldReorder = false;
	//NoTouchLayer *noTouch = NoTouchLayer::create();
	//m_map->addChild(noTouch, zOrder, skill::kShapeChangeNoTouchTag);
	//noTouch->setColor(ccc3(0, 0, 0));
	//noTouch->setOpacity(skill::kGrayLayerOpacityValue);
	//noTouch->ignoreAnchorPointForPosition(false);
	//noTouch->setAnchorPoint(ccp(0.0f, 0.0f));
	//noTouch->setPosition(ccp(0.0f, 0.0f));
	//noTouch->setContentSize(m_map->getContentSize());

	//if (attackerView == nullptr)
	//{
	//	BattleScene::getCurrentScene()->resume();
	//	m_map->removeChildByTag(skill::kNoTouchTag);
	//	m_map->removeChildByTag(skill::kShapeChangeNoTouchTag);

	//	m_shouldReorder = true;
	//	m_isBattleSkillProcessing = false;
	//	return;
	//}
	//std::vector<BattleObjectView *> objs;
	//objs.push_back(attackerView);

	//CCArray* arrayOfActions = CCArray::create();
	//const float duration = 1.0f; 
	//CCCallFuncND *doSpeakAction = CCCallFuncND::create(this, [=](void) ->void
	//{
	//	if (nullptr != getMoveObjectView(attackerId))
	//	{
	//		attackerView->onSpeak(speakType,speakTextId,speakLastTime);
	//	}
	//});

	//CCCallFuncND *useSkillAction = CCCallFuncND::create(this, [=](void) ->void
	//{
	//	if (nullptr != getMoveObjectView(attackerId))
	//	{
	//		if (isUseSuccess) useSkill(sr, data, attackerId, skillInfo, false);
	//	}		
	//});

	//CCCallFuncND *resumeScenceAction = CCCallFuncND::create(this, [=](void) ->void
	//{
	//	BattleScene::getCurrentScene()->resume();
	//	m_map->removeChildByTag(skill::kShapeChangeNoTouchTag);
	//	getMenu()->enable();
	//	m_shouldReorder = true;
	//	m_isBattleSkillProcessing = false;
	//});


	//CCCallFuncND *focusToHitPosAction = CCCallFuncND::create(this, [=](void) ->void
	//{
	//	CCPoint realHitPos = ccp(sr.hitPos.x,sr.hitPos.y);
	//	if (realHitPos.x == -1 && realHitPos.y == -1)
	//	{
	//		PixelPoint posPix = GridUtil::sharedGridUtil().floatGridToPix(data.targetPos.x, data.targetPos.y);
	//		realHitPos = ccp(posPix.x, posPix.y);
	//	}
	//	focusTo(ccp(realHitPos.x, realHitPos.y));
	//});


	//if (speakType == kSpeakBubble)
	//{
	//	arrayOfActions->addObject(doSpeakAction);	
	//	arrayOfActions->addObject(CCDelayTime::create((speakLastTime)));
	//	arrayOfActions->addObject(useSkillAction);	
	//	arrayOfActions->addObject(focusToHitPosAction);	
	//	arrayOfActions->addObject(resumeScenceAction);
	//}
	//else if (speakType == kSpeakDialog)
	//{
	//	arrayOfActions->addObject(doSpeakAction);	
	//	m_speakDialogEndId = EventDispatcherXY::sharedDispatcher().addListener(kInternalCmdGeneralSpeakDialogEnded,
	//		std::bind(&BattleSceneView::onSpeakDialogEnd, this, sr, data, attackerId, skillInfo, isUseSuccess, speakType, speakTextId, speakLastTime));
	//	m_isWatingForSpeakDialogEnd = true;
	//}
	//else if (speakType == kSpeakNone)
	//{
	//	arrayOfActions->addObject(useSkillAction);	
	//	arrayOfActions->addObject(focusToHitPosAction);	
	//	arrayOfActions->addObject(resumeScenceAction);
	//}

	/*CCSequence* seq = CCSequence::create(arrayOfActions);	
	runAction(seq);	*/
}

bool BattleSceneView::onObjectShapeChangeUseSkill(uint16_t objectId, const SkillGroupInfo &skillGroupInfo, SpeakType speakType, int speakTextId, float speakLastTime)
{
	if (m_isBattleSkillProcessing == false)
	{
		m_isBattleSkillProcessing = true;
	}
	else
	{
		return false;
	}
	skill::SkillResult sr;
	skill::SpecialFxData data;
	SkillInfo skillInfo = SkillInfo(skillGroupInfo.skill_group_id, skillGroupInfo.level);
	bool isUseSuccess = canUseSkill(&sr, &data, objectId, skillInfo, false, cocos2d::Vec2(0, 0), false, true);

	if(!isUseSuccess)
	{
		return false;
	}

	BattleMoveObjectView *attackerView = getMoveObjectView(objectId);
	assert(attackerView);
	attackerView->setScaleValue(BATTLEPARA_VALUE("general_shape_change_scale"));
	focusToWithAnimation(attackerView->getPosition(), std::bind(&BattleSceneView::onShapeChangeUseSkillFocusToFinished, this, sr, data, objectId, skillInfo,isUseSuccess,speakType,speakTextId,speakLastTime));
	BattleScene::getCurrentScene()->pause();

	return true;
}

void BattleSceneView::updateTinyMap()
{
}

void BattleSceneView::onBossStageChange(int battleObjectId)
{
	assert(m_model->getPassType() == BattleScene::kBossPass);		

	BattleMoveObjectView *bossGeneralView= getMoveObjectView(battleObjectId);
	assert(bossGeneralView != nullptr);

	m_model->pause();
	//	pauseBackgroundMusic();
	//	pauseAllEffectSounds();

	// BOSS变身时的战斗背景黑屏特效;
	Size size = CCSizeMake(m_model->getWidth(), m_model->getHeight());
	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	CCLayerColor *maskBkg = CCLayerColor::create(ccc4(0, 0, 0, 200));
	maskBkg->setContentSize(Size(size.width / scaleFactor * 2.0f, size.height / scaleFactor * 2.0f));
	maskBkg->ignoreAnchorPointForPosition(false);
	maskBkg->setAnchorPoint(ccp(0.5f, 0.5f));
	maskBkg->setPosition(ccp(size.width/2, size.height/2));
	m_map->addChild(maskBkg, 0, g_tagBossStageChangeBkgMask);


	bossGeneralView->runBossTelesportUp(std::bind(&BattleSceneView::onBossTelesportEffectFinishedA, this, bossGeneralView));
	bossGeneralView->getMainSprite()->setVisible(false);
}

void BattleSceneView::onBossTelesportEffectFinishedA(BattleMoveObjectView *bossGeneralView)
{
	assert(bossGeneralView != nullptr);
	bossGeneralView->stopAllActions(); // 注意：这里必须要清除action
	bossGeneralView->unbright();
	bossGeneralView->unred();
	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	// 瞬移
	float moveDuration = 0.6f;
	BattleMoveObject *generalModel = bossGeneralView->getModel();
	generalModel->setCloak(true);
	generalModel->setManualMode(true, true);
	generalModel->jumpTo(skill::covertGridCenterToFloat(m_model->getEnemyBornPoint()));		// 设置武将逻辑位置

	// 设置BOSS武将变身后的属性;
	int newTid= bossGeneralView->getModel()->getTid() + SYSTEM_VALUE("boss_pass_delta_general_tid");			
	generalModel->setMonster(true);
	int battleProp[BattleProp::kBattlePropCount];
	initMonGeneralBattleProp(battleProp, newTid);
	generalModel->initProps(battleProp, newTid);

	float bossHpPercent =  PASSSPECIALCASE_VALUE("boss_pass_enemy_general_hp_percent");
	float bossChangeStateHp = generalModel->getHpMax() * bossHpPercent;
	generalModel->setHp(static_cast<int>(bossChangeStateHp));

	// 镜头聚焦到BOSS武将;
	PixelPoint dstPos = GridUtil::sharedGridUtil().gridToPix(m_model->getEnemyBornPoint());
	const CCPoint &perfectOrig = convertToPerfectFocusPos(ccp(static_cast<float>(dstPos.x), static_cast<float>(dstPos.y)));
	float duration = 0.3f;				
	float speedRatio = 0.6f;
	CCMoveTo *moveAction = CCMoveTo::create(moveDuration, perfectOrig);
	CCEaseExponentialOut *easeExpOut = CCEaseExponentialOut::create(moveAction);
	runAction(CCSpeed::create(easeExpOut, speedRatio));

	// BOSS变身
	CCDelayTime *delayAction = CCDelayTime::create(moveDuration);			
	auto callback = std::bind(&BattleSceneView::onBossTelesportEffectFinishedB, this, bossGeneralView);
	CCCallFuncND *func = CCCallFuncND::create(this, [=](void){
		bossGeneralView->setVisible(true);
		bossGeneralView->getMainSprite()->setVisible(true);
		bossGeneralView->runBossTelesportDown(callback);
		bossGeneralView->getModel()->setToward(BattleObject::kLeftDown);

		// 振屏效果
		int defaultValueTid = 1005;					// 参考表 DefaultValue.xls
		CCAction *shake = getSceneShakeAction(defaultValueTid);
		if (shake) bossGeneralView->runAction(shake);

		// 爆出粮草
		float resource = PASSSPECIALCASE_VALUE("boss_pass_enemy_general_resource");
		float decreaseSpeed = PASSSPECIALCASE_VALUE("boss_pass_res_decrease_speeed");
		int elapsedBattleTime =  m_model->getStartBattleTime() - m_model->getBattleTime();
		float actualRes = resource - decreaseSpeed * elapsedBattleTime;						
		CCPoint position = m_map->convertToWorldSpace(bossGeneralView->getPosition());			
		auto layer = createBattleResourcePickUpLayer(actualRes, position, true);
		addChild(layer);

//		if (m_battleMenu && m_battleMenu->getPopulationLimit())
//		{
//			int maxPopulation = BattleScene::getCurrentScene()->getMaxPopulation();
//			int toAddPopulation = static_cast<int>(PASSSPECIALCASE_VALUE("boss_pass_add_population_limit"));
//			BattleScene::getCurrentScene()->setMaxPopulation(maxPopulation + toAddPopulation);
//		}

	});
	CCSequence *seqActions = CCSequence::create(delayAction,func, nullptr);
	runAction(seqActions);
}

void BattleSceneView::onBossTelesportEffectFinishedB(BattleMoveObjectView *generalView)
{

	// 播放BOSS第三阶段变身特效
	generalView->runBossChangeEffectC();

	BattleMoveObject *generalModel = generalView->getModel();
	generalView->getModel()->setCloak(false);							

	// 恢复游戏
	if (m_model->isPause() && !isExitPanelDisplay())
	{
		m_model->resume();
		generalModel->resume();
		resumeAllEffectSounds();
		resumeBackgroundMusic();
	}


	// 触发其他逻辑
	CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);				
	m_model->triggerSceneGenGeneralPoints(kEnemyParty);									 // 触发敌方所有的出兵行为
	generalModel->setInvincible(false);											    
	m_map->removeChildByTag(g_tagBossStageChangeBkgMask);							 // 移除黑屏特效							
	m_isBossStageChangedEnd = true;													 
}

void BattleSceneView::onBattleRealBegin()
{
	if (isInThisBattleMode(MainScene::kBattlePVP))
	{
		DefendArmy army;
		if (isInThisBattleMode(MainScene::kBattlePVP)) army = GamePvp::thePvp()->getTarget().army;
		if (army.soldiers.empty()) checkBattleResult();
	}
}
cocos2d::CCPoint BattleSceneView::convertToPerfectFocusPos( const cocos2d::CCPoint &pt0 )
{
	float scale = getScale();
	CCPoint pt = ccp(pt0.x * scale, pt0.y * scale);

	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	cocos2d::Size newSize = winSize;
	newSize.height = newSize.height - 300;
	CCPoint curPosition = ccp(getPosition().x, getPosition().y);

	const CCPoint &anchorPoint = m_map->getAnchorPoint();
	const Size &size = m_map->getContentSize();
	cocos2d::CCPoint perfectOrig(pt.x - newSize.width * 0.5f - size.width * anchorPoint.x * (m_mapScale - 1),
		pt.y - newSize.height * 0.5f - size.height * anchorPoint.y * (m_mapScale - 1));

	float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	float bottom = 0.0f;
	if (perfectOrig.x + newSize.width > size.width * (m_mapScale - anchorPoint.x * (m_mapScale - 1)) - bottom)
		perfectOrig.x = size.width * (m_mapScale - anchorPoint.x * (m_mapScale - 1)) - newSize.width - bottom;
	if (perfectOrig.y + newSize.height > size.height * (m_mapScale - anchorPoint.y * (m_mapScale - 1)) - bottom)
		perfectOrig.y = size.height * (m_mapScale - anchorPoint.y * (m_mapScale - 1)) - newSize.height - bottom;
	if ( perfectOrig.x <= -size.width * anchorPoint.x * (m_mapScale - 1) + bottom ) 
		perfectOrig.x = -size.width * anchorPoint.x * (m_mapScale - 1) + bottom;
	if ( perfectOrig.y <= -size.height * anchorPoint.y * (m_mapScale - 1) + bottom ) 
		perfectOrig.y = -size.height * anchorPoint.y * (m_mapScale - 1) + bottom;

	perfectOrig.x = -perfectOrig.x;
	perfectOrig.y = -perfectOrig.y;

	return perfectOrig;
}

void BattleSceneView::onBattleMaxResourcesChanged()
{
}

void BattleSceneView::onDropResourceFromObject(uint16_t objectId, float count)
{
	BattleObjectView *objectView = getObjectView(objectId);
	CCPoint position = m_map->convertToWorldSpace(objectView->getPosition());			
	auto layer = createBattleResourcePickUpLayer(count, position, true);
	addChild(layer);
}

// 资源副本（多多益善）资源点HP变化时的回调函数;
void BattleSceneView::onDungeonResBossBarracksHpChanged(int hpDiff, BattleStaticObject *barrack)
{
	

}

// 敌方兵营血量变化时的回调函数（实现边打兵营边掉粮草）;
void BattleSceneView::onEnemyBarracksHpChanged(int hpDiff, BattleStaticObject *barrack)
{
	return;
	static CCPoint srcPos = ccp(0, 0);
	hpDiff = std::abs(hpDiff);

	if (m_enemyBuildings.find(barrack->getId()) != m_enemyBuildings.end())
	{
		srcPos = m_enemyBuildings[barrack->getId()]->getPosition();	
	}

	//const std::vector<int> &vec = PASSBUILDING_BARRACK_HP_FOOD(barrack->getTid());
	//assert(vec.size() == 2);
	//float N = static_cast<float>(vec[0]);											// 攻击兵营过程中可掉落的粮草总数
	//float M = static_cast<float>(vec[1]);											// 粮草掉落次数

	//// 计算方式问策划
	//int step = round_(barrack->getHpMax() * (1 / M));			// 四舍五入
	//int A = (barrack->getHp() + hpDiff) / step;
	//int B = std::max<int>(barrack->getHp(), 0) / step;
	//int resCount = static_cast<int>(std::abs(A - B) * (N / M));

	//const float resIconCount = 4.0f;
	//auto layer = createBattleResourcePickUpLayer(static_cast<float>(resCount), 
	//	m_map->convertToWorldSpace(srcPos), true, "res/ui/battle/icon_food_normal.png", resCount / resIconCount);
	//addChild(layer);
}

void BattleSceneView::onBossHpChanged(int id, int hpDiff)
{
	if (m_isBossStageChangedBegin)	return;

	BattleMoveObject *general = m_model->getBossGeneral();
	if (general == nullptr)	return;									

	if (general->getHp() <= 0 && !m_isBossStageChangedBegin)			
	{
		checkBattleResult();
		return;
	}
	float bossHpPercent =  PASSSPECIALCASE_VALUE("boss_pass_enemy_general_hp_percent");
	int bossChangeStateHp = static_cast<int>(general->getHpMax() * bossHpPercent);
	bool isBossStateChange = general->getHp() <= bossChangeStateHp;
	if (isBossStateChange)
	{
		general->setInvincible(true);						
		m_isBossStageChangedBegin = true;					
		onBossStageChange(id);						
	}

}

static void invincibleFastCutAttack(uint16_t attackerId, uint16_t targetId, const SkillInfo &skillInfo)
{
	if (!BattleScene::getCurrentScene()->getMoveObject(targetId)) return;
	if (!BattleScene::getCurrentScene()->getMoveObject(attackerId)) return;

	BattleMoveObjectView *attacker = BattleSceneView::getCurrentSceneView()->getMoveObjectView(attackerId);
	if(!attacker) return;
	BattleMoveObjectView *target = BattleSceneView::getCurrentSceneView()->getMoveObjectView(targetId);
	if(!target) return;

	assert(attacker->getModel()->getParty() != target->getModel()->getParty());
	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	skill::doSelfFx(BattleScene::kMoveObj, attacker->getModel(), nullptr, nullptr, skillLevelId);

	std::set<uint16_t> targets;
	targets.insert(targetId);
	genSkillBattleReport(attacker->getModel(), targets, skillLevelId, target->getModel()->getPixelPosition(), nullptr);

	const CCPoint &attackerPos = attacker->getPosition();
	const CCPoint &targetPos = target->getPosition();
	int toward = calcToward(attackerPos, targetPos);
	attacker->getModel()->setToward(toward);
	attacker->doCutAttackForInvincible(skillLevelId, true);
}

static CCPoint findInvincibleFastCutTargetPosition(const CCPoint &start, const CCPoint &dest)
{
	CCPoint pos;

	float dis = ccpDistance(start, dest);
	float sin_ = (dest.y - start.y) / dis;
	float cos_ = (dest.x - start.x) / dis;

	float l = 50.0f / CC_CONTENT_SCALE_FACTOR();
	pos.x = dest.x + cos_ * l;
	pos.y = dest.y + sin_ * l;
	return pos;
}

static void invincibleFastCutAction(uint16_t attackerId, uint16_t targetId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, int cutTimes, std::function<void ()> actionFinishedCallBack)
{
	BattleMoveObjectView *attacker = BattleSceneView::getCurrentSceneView()->getMoveObjectView(attackerId);
	if ( (!BattleScene::getCurrentScene()->getMoveObject(attackerId)) || (!attacker) ) 
	{
		return;
	}

	BattleMoveObjectView *target = BattleSceneView::getCurrentSceneView()->getMoveObjectView(targetId);
	if ( (!BattleScene::getCurrentScene()->getMoveObject(targetId)) || (!target) )
	{
		if (actionFinishedCallBack) actionFinishedCallBack();
		return;
	}	
	
	const CCPoint &attackerPos = attacker->getPosition();
	const CCPoint &targetPos = target->getPosition();
	CCPoint pos = findInvincibleFastCutTargetPosition(attackerPos, targetPos);

	BattleSceneView *sceneView = BattleSceneView::getCurrentSceneView();
	attacker->getModel()->setToward(attackerPos, targetPos);
	int toward = attacker->getModel()->getToward();
	CCSpriteFrame *shadowFrame = attacker->getFrame(toward);
	const CCPoint &shadowOffset = attacker->getOffset(toward);
	float delay = cutTimes == 1 ? 0.0f : data.data5;

	ShadowMaker *sm = ShadowMaker::create(attackerPos, pos, shadowFrame, shadowOffset, attacker, sceneView, delay, attacker->getSelectScale(), attackerPos.x > targetPos.x);
	sceneView->addChild(sm);
	sm->setHandler([=](const CCPoint &destPos) ->void
	{
		invincibleFastCutAttack(attackerId, targetId, skillInfo);
		if (actionFinishedCallBack) actionFinishedCallBack();
	});
}

static void onInvincibleFastCutFinished(BattleMoveObjectView *attacker, uint16_t lastTargetId)
{
	const CCPoint &attackerPosition = attacker->getPosition();
	GridPosition grid = GridUtil::sharedGridUtil().pixToGrid(attackerPosition.x, attackerPosition.y);
	BattleMoveObject *attackerModel = attacker->getModel();
	BattleScene *scene = BattleScene::getCurrentScene();

	const GridRect &rect = attackerModel->getIntRect(grid);
	bool isBeyondTarget = false;
	BattleMoveObject * lastTarget = scene->getMoveObject(lastTargetId);
	if (lastTarget)
	{
		const GridRect &targetRect = attackerModel->getIntRect(grid);
		isBeyondTarget = targetRect.isContaninGrid(grid);
	}	

	bool isFindNearNotBarrierNode = false;
	
	for(int16_t y = rect.rb.y; y <= rect.lt.y; ++y)
	{
		for(int16_t x = rect.lt.x; x <= rect.rb.x; ++x)
		{
			if(scene->getTerrain()->isStaicBarrier(x, y) || scene->getTerrain()->isDynamicBarrier(x, y) || isBeyondTarget)
			{
				int flagId = terrain::genFlagId(attackerModel->getParty(), attackerModel->getTroopId(), true, attackerModel->getSize());
				grid = scene->getTerrain()->getNearNotBarrierNode(grid, flagId); //会因为找不到合适的位置而导致跳出的距离很远
				if (grid.x != -1 && grid.y != -1)
				{
					isFindNearNotBarrierNode = true;
					break;
				}				
			}
		}
		if (isFindNearNotBarrierNode)
		{
			break;
		}
	}

	attackerModel->jumpTo(skill::covertGridCenterToFloat(grid));
	attackerModel->setInvincible(false);
	attackerModel->setCannotMoveAndAttack(false);
	attacker->setSkillAttackFrameIntervalScale(1.0f);
	attacker->doCutAttackForInvincible(0, false); 
}

void BattleSceneView::doInvincibleFastCut(uint16_t attackerId, const SkillInfo &skillInfo, const skill::SpecialFxData &data, int cutTimes, cocos2d::CCPoint attackerPosition, uint16_t lastTargetId)
{
	int cutMaxTimes = (int)data.data3;
	BattleMoveObject * attackerModel = m_model->getMoveObject(attackerId);
	if (attackerModel == nullptr)
	{
		return;
	}
	BattleMoveObjectView *attacker = getMoveObjectView(attackerId);
	if(!attacker)
	{
		return;
	}
	if (cutTimes > cutMaxTimes)
	{
		onInvincibleFastCutFinished(attacker, lastTargetId);
		return;
	}
	std::set<uint16_t> targets;
	skill::getObjects(&targets, skillInfo, data, attackerModel->getParty(), attackerPosition);
	uint16_t targetId = 0;
	if (targets.size()>0)
	{
		targetId = (*targets.begin());
	}

	if (targetId == 0)
	{
		onInvincibleFastCutFinished(attacker, lastTargetId);
		return;
	}	

	attacker->setSkillAttackFrameIntervalScale(data.data4);
	attackerModel->setInvincible(true);

	BattleMoveObjectView *target = getMoveObjectView(targetId);
	invincibleFastCutAction(attackerId, targetId, skillInfo, data, cutTimes, [=](void) ->void
	{
		int curCutTimes = cutTimes + 1;
		doInvincibleFastCut(attackerId, skillInfo, data, curCutTimes, attackerPosition, targetId);
	});
}

void BattleSceneView::addBattleSkillMessage(int generalTid, int skillGroupId)
{
}

void BattleSceneView::addGeneralFightMsg( int generalTid, const std::string &msg, float duration)
{
}

void BattleSceneView::addBattleMessage( const std::string &msg, ccColor3B color)
{
}

void BattleSceneView::addBlackLayer(const std::vector<BattleObjectView *> &objs, uint16_t addObjId, float fadeInTime)
{
	if (m_model->getIsInAutoBattleMode())
	{
		return;
	}

	int zOrder = skill::kBigestUpperLayerZorder;
	dynamic_cast<SceneLayer *>(m_map)->addBlackLayer(zOrder, fadeInTime);

	for (size_t i = 0; i < objs.size(); ++i)
	{
		m_map->reorderChild(objs[i], zOrder + 1);
	}
	for (auto iter = m_preReleaseSkillIndicates.begin(); iter != m_preReleaseSkillIndicates.end(); ++iter)
	{
		m_map->reorderChild(iter->second, zOrder);
	}
	for (auto iter = m_skillIndicates.begin(); iter != m_skillIndicates.end(); ++iter)
	{
		m_map->reorderChild(iter->second, zOrder-1);
	}	
	m_shouldReorder = false;
	m_addBlackLayerObjId = addObjId;
}

void BattleSceneView::reinitBlackLayerEnv()
{
	int zOrder = skill::kBigestUpperLayerZorder;
	//战场技能表现过程中，全程黑屏，不能重设ZORDER
	if (m_isBattleSkillProcessing == false)
	{
		m_shouldReorder = true;
	}

	if (getMoveObjectView(m_addBlackLayerObjId))
	{
		m_map->reorderChild(getMoveObjectView(m_addBlackLayerObjId), zOrder - 1);
	}	

	for (auto iter = m_preReleaseSkillIndicates.begin(); iter != m_preReleaseSkillIndicates.end(); ++iter)
	{
		m_map->reorderChild(iter->second, 1);
	}
	for (auto iter = m_skillIndicates.begin(); iter != m_skillIndicates.end(); ++iter)
	{
		m_map->reorderChild(iter->second, 1);
	}	
}
//适用于武将点击的黑屏清除
void BattleSceneView::removeBlackLayer(uint16_t applyObjId, float fadeOutTime)
{
	if (applyObjId != m_addBlackLayerObjId)
	{
		return;
	}	
	dynamic_cast<SceneLayer *>(m_map)->removeBlackLayer(fadeOutTime);	
}

void BattleSceneView::onUseSkillFocusToFinished(const skill::SkillResult &sr, const skill::SpecialFxData &data, uint16_t attackerId, const SkillInfo &info, const cocos2d::CCPoint &pt, bool isUseSuccess)
{
	int skillId = info.skill_id;
	int skillLevelId = skill::getSkillLvId(skillId, info.level);
	bool isReleaseSkill = SKILLGROUP_RELEASE_TYPE(skillId) == 0;

	if (!isUseSuccess) 
	{		
		return;
	}

	BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
	if (!attacker) 
	{
		return;
	}

	if (!attacker->isMpEnough(skillId))
	{
		attacker->skillReleaseEnd();
		return;
	}

	if (isReleaseSkill || m_model->getIsInAutoBattleMode())
	{
		Vector<FiniteTimeAction*> arrayOfActions;
		if (!isReleaseSkill)
		{
			CCCallFuncND * twiceSkillEff = CCCallFuncND::create(this, [=](void) ->void
			{
				effctForTwiceSkill(attackerId);	
			});
			arrayOfActions.pushBack(twiceSkillEff);
			arrayOfActions.pushBack(CCDelayTime::create(0.4f));
		}
		

		CCCallFuncND * useSkillAction = CCCallFuncND::create(this, [=](void) ->void
		{
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			if (!attacker) 
			{
				return;
			}
			if (!isReleaseSkill)
			{
				attacker->stopWaitSkill();
			}
			
			if(useSkill(sr, data, attackerId, info, false))
			{

				attacker->afterUseSkill(skillLevelId);
			}
		});
		arrayOfActions.pushBack(useSkillAction);
		CCSequence* seq = CCSequence::create(arrayOfActions);	
		runAction(seq);	
		return;
	}
	else
	{
		attacker->stopRunning();
		attacker->skillReleaseBegin();
		BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
		CCPoint atkPixPos = attackerView->getPosition();
		int releaseScope = SKILLLOGIC_RELEASE_SCOPE(info.skill_id);
		float atkRadius = 0.0f;
		if (releaseScope <= 0)
		{
			atkRadius = 7.0f; //二次释放如果是无限施法范围，范围圈按默认范围显示
		}
		else
		{
			atkRadius = attacker->getBattleEffect()->getModifiedSkillReleaseScope(releaseScope) * 0.5f;
		}

		Sprite* showTargePosEff = Sprite::create(skill::kSkillAtkAreaEffName.c_str());
		showTargePosEff->setAnchorPoint(ccp(0.5f, 0.5f));
		showTargePosEff->setPosition(ccp(atkPixPos.x, atkPixPos.y));
		float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
		float width = getAtkAreaWithGrid(atkRadius);
		float scale = width / (showTargePosEff->getContentSize().width/2);
		showTargePosEff->setScale(scale);	
		getLayer()->addChild(showTargePosEff, 0, skill::kAtkAreaEffTag + attackerId);

		CCDelayTime * delayCancel = CCDelayTime::create(skill::kCancelSelectTargetTime);
		CCCallFuncND *cancelSelectTarget = CCCallFuncND::create(this, [=]{
			resetSingleClick();
			BattleMoveObject *attacker = m_model->getMoveObject(attackerId);
			if (attacker)
			{
				attacker->stopWaitSkill();
			}			
			else
			{
				getLayer()->removeChildByTag(skill::kAtkAreaEffTag + attackerId);
			}

		});

		CCSequence *seqFunc = CCSequence::create(delayCancel, cancelSelectTarget, nullptr);
		seqFunc->setTag(skill::kCancelSelectTargetActTag + attackerId); 
		runAction(seqFunc);
	}
}

void BattleSceneView::addSoliderDeadMsg(int soliderTid, bool isMonster, const std::string &msg, float duration)
{
}

void BattleSceneView::addGeneralDeadMsg( int generalTid, const std::string &msg, float duration)
{
}

bool BattleSceneView::canUseSkill(skill::SkillResult *sr, skill::SpecialFxData *data, uint16_t attackerId, const SkillInfo &skillInfo, bool isNormalAttackSkill, const cocos2d::CCPoint &pt, bool isClickSkillIcon, bool isAiTriggered)
{
	BattleMoveObjectView *attackerView = getMoveObjectView(attackerId);
	if(!attackerView) return false;

	int skillLevelId = skill::getSkillLvId(skillInfo.skill_id, skillInfo.level);
	BattleMoveObject *attacker = attackerView->getModel();
	if(!isAiTriggered && (attacker->getParty() == kEnemyParty || m_model->getIsInAutoBattleMode()))
	{
		if(SKILLLOGIC_TYPE(skillInfo.skill_id) == skill::kTypeNormal)
		{
			if(!canNormalTypeSkillAutoRelease(skillLevelId, attacker))
			{
				return false;
			}
		}
	}

	bool isUseSuccess = false;
	skill::SkillType skillType = skill::kTypeAttack;
	int modType = SKILLLOGIC_MOD_TYPE(skillInfo.skill_id);

	// 是否要手动选目标点;
	if(true || attacker->isMonster() || attacker->getParty() == kEnemyParty || SKILLGROUP_RELEASE_TYPE(skillInfo.skill_id) == skill::kAutoRelease) // 不需要;
	{
		skillType = skill::handleSkillAttackTarget(&isUseSuccess, sr, data, attackerId, skillInfo);

		if(isClickSkillIcon && !m_model->getIsInAutoBattleMode() && SKILL_HIT_TYPE(skillInfo.skill_id) == kDest)// 手动释放的打格子的技能，即时没目标也要放出来;
		{
			isUseSuccess = true;
		}

		if (attacker->getParty() == kFriendParty && attacker->isMonster() == false && !BattleScene::getCurrentScene()->getIsInAutoBattleMode())//我方在非自动战斗时允许空放技能
		{
			isUseSuccess = true; 
		}
		
	}
	else // 需要;
	{
		isUseSuccess = true;
		CCPoint targetPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint(static_cast<int16_t>(pt.x), static_cast<int16_t>(pt.y)));
		assert(targetPos.x >= 0.0f && targetPos.y >= 0.0f);
		TargetSelectMgr::theMgr().addMainTargetIds(m_model->getTerrain()->getGridObjects(static_cast<int16_t>(targetPos.x), static_cast<int16_t>(targetPos.y)));
		switch (modType)
		{
		case skill::kHitRangeTypeOutCircle:
			{
				skillType = skill::handleSkillAttackOutsideCircle(sr, data, attackerId, targetPos, skillInfo);
				break;
			}
		case skill::kHitRangeTypeSector:
			{
				skillType = skill::handleSkillAttackSector(sr, data, attackerId, targetPos, skillInfo);
				break;
			}
		case skill::kHitRangeTypeRect:
			{
				skillType = skill::handleSkillAttackRectangle(sr, data, attackerId, targetPos, skillInfo);
				break;
			}
		case skill::kHitRangeTypeCross:
			{
				skillType = skill::handleSkillAttackCross(&isUseSuccess, sr, data, attackerId, skillInfo);
				break;
			}
		default:
			assert(false);
		}
		
		TargetSelectMgr::theMgr().clearMainTargetIds();
	}

	if(skillType == skill::kTypeSpecial && isUseSuccess)
	{
		isUseSuccess = isShouldAutoReleaseSpecialSkill(data, attackerId, skillInfo);
	}

	if(GameClientGM::theClientGM()->isSkillDebug())
	{
		PixelPoint atkerPix = attacker->getPixelPosition();
		CCPoint startPoint = ccp(atkerPix.x, atkerPix.y);
		std::vector<PixelPoint> targetsPos;
		bool isAccount = (SKILL_HIT_TYPE(skillInfo.skill_id) == kDest);
		if (SKILLLOGIC_MOD_TYPE(skillInfo.skill_id) == skill::kHitRangeTypeRect && isAccount)
		{			
			PixelPoint target = GridUtil::sharedGridUtil().gridToPix(GridPosition((int16_t)data->targetPos.x, (int16_t)data->targetPos.y));
			CCPoint finalTargetPos = ccp((float)target.x, (float)target.y);	
			calcBulletEffectDest(skillInfo, startPoint, finalTargetPos, 0.0f, attackerView);
			atkerPix.x = (int16_t)startPoint.x;
			atkerPix.y = (int16_t)startPoint.y;
			targetsPos.push_back(PixelPoint((int16_t)finalTargetPos.x, (int16_t)finalTargetPos.y));
		}
		else
		{
			targetsPos = GameClientGM::theClientGM()->getSkillTargetPoses();
		}

		dynamic_cast<SceneLayer *>(m_map)->setSkillRangeData(skillInfo, GridUtil::sharedGridUtil(). pixToFloatGrid(atkerPix), GridPosition(0,0), targetsPos);
	}

	return isUseSuccess;
}

void BattleSceneView::calcBulletEffectDest(const SkillInfo &skillInfo, cocos2d::CCPoint& startPoint, cocos2d::CCPoint& finalTargetPos, float nowRadians, BattleMoveObjectView * attack)
{
	BattleMoveObject * attacker = attack->getModel();
	int attackerToward = attacker->getToward();
	const SkillProperty &skillPty = getSkillEffect(skillInfo.skill_id);
	CCPoint pt = attack->getEffectHangPointPos(skillPty.bulletStartPoint[getIndexWithTowardByStartPoint(attackerToward)], shouldSetFilp(attackerToward));
	float minAtkAreaRadius = sqrtf(static_cast<float>(pt.x * pt.x + pt.y * pt.y));		
	bool isInMinAtkArea = isInCircle(startPoint, ccp((float)finalTargetPos.x, (float)finalTargetPos.y), minAtkAreaRadius);
	if (isInMinAtkArea)
	{			
		finalTargetPos = posTransformMinAreaEnemy(finalTargetPos, startPoint, pt);
	}
	startPoint.x += pt.x;
	startPoint.y += pt.y;

	const vector<int> v = SKILLLOGIC_MOD_SCOPE(skillInfo.skill_id);
	if (v.empty())
	{
		return;
	}
	int length = v[0];		
	CCPoint startGridPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint(static_cast<int16_t>(startPoint.x), static_cast<int16_t>(startPoint.y)));
	CCPoint targetGridPos = GridUtil::sharedGridUtil().pixToFloatGrid(PixelPoint(static_cast<int16_t>(finalTargetPos.x), static_cast<int16_t>(finalTargetPos.y)));
	finalTargetPos = calcDestPixelPosition(startGridPos, targetGridPos, nowRadians, static_cast<float>(length));
}

void BattleSceneView::addDeadBody(BattleObjectView *deadBody)
{
	INFO_MSG("(%d) addDeadBody", deadBody->getModel()->getId());
	//	assert(std::find(m_deadBodys.begin(), m_deadBodys.end(), deadBody) == m_deadBodys.end());
	m_deadBodys.push_back(deadBody);
}

void BattleSceneView::removeDeadBody(BattleObjectView *deadBody)
{
	INFO_MSG("(%d) removeDeadBody", deadBody->getModel()->getId());
	m_deadBodys.remove(deadBody);
}

void BattleSceneView::initBattle()
{	
	m_model->resume();
	int battleMode = MainScene::theScene()->getBattleMode();
	if (battleMode == MainScene::kBattlePass)
	{
		m_model->initStaticObject();
		m_model->initTroopSet();
		m_model->initMoveObject();
	}
	else if (battleMode == MainScene::kBattlePVP)
	{
		m_model->initStaticObject();
	}

	m_model->initFocusPoint();

	m_model->onInitFinish();
	if (battleMode == MainScene::kBattlePass)
	{
		const std::vector<ItemInfo> &dropOut = MainScene::theScene()->getPassDropOut();
		if (!dropOut.empty()) m_model->initDropOut(dropOut);
	}

	if (m_plotSceneView)
	{
// 		m_plotSceneView->cleanUp();
// 		m_plotSceneView->removeFromParent();
// 		m_plotSceneView = nullptr;
	}
}

void BattleSceneView::initStartPlot(int plotId)
{/*
	m_plotSceneView = PlotSceneView::create(m_map, plotId, true);
	addChild(m_plotSceneView);
	m_model->pause();
	lockScreen();
	m_plotSceneView->setFinishedCallBack([=](void) ->void
	{
		unLockScreen();
		focusTo(ccp(0.0f, 0.0f));
		initBattle();
		m_model->onStarUiTouchEnd();
	});

	char plotStr[64];
	snprintf(plotStr, sizeof(plotStr), "plot_%d_pre", plotId);
	lua_State *L = LuaEngine::defaultEngine()->getLuaStack()->getLuaState();
	LuaWrapper::callFuncInLua<void>(L, plotStr, "start", ""); */ 
}

void BattleSceneView::battleStart()
{
	auto dispatcher = Director::getInstance()->getEventDispatcher();
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(BattleSceneView::ccTouchBegan, this);
	touchListener->onTouchMoved = CC_CALLBACK_2(BattleSceneView::ccTouchMoved, this);
	touchListener->onTouchEnded = CC_CALLBACK_2(BattleSceneView::ccTouchEnded, this);
	dispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

	initBattle();
	m_model->resume();
	m_model->onStarUiTouchEnd();
	return;
}

void BattleSceneView::onNotCallGeneralMpChanged()
{
}

static const int kPlayTroopAtmosphereSoundMinSoldierNum = 4;
void BattleSceneView::onLaunchTroop(int memberCount)
{
	if(memberCount >= kPlayTroopAtmosphereSoundMinSoldierNum)
	{
		playTroopAtmosphereSound();
	}
}

void BattleSceneView::addDropOut()
{
}

void BattleSceneView::clearScene()
{
	for (auto iter = m_friendMoveObjects.begin(); iter != m_friendMoveObjects.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_friendMoveObjects.clear();

	for (auto iter = m_enemyMoveObjects.begin(); iter != m_enemyMoveObjects.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_enemyMoveObjects.clear();

	for (auto iter = m_enemyBuildings.begin(); iter != m_enemyBuildings.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_enemyBuildings.clear();

	for (auto iter = m_friendBuildings.begin(); iter != m_friendBuildings.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_friendBuildings.clear();

	for (auto iter = m_enemyTowers.begin(); iter != m_enemyTowers.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_enemyTowers.clear();

	for (auto iter = m_friendTowers.begin(); iter != m_friendTowers.end(); ++iter)
	{
		iter->second->removeFromParent();
	}
	m_friendTowers.clear();

	m_deadBodys.clear();
	cleanup();
	removeAllChildren();
	m_map = SceneLayer::create(m_model->getId());
	m_map->setAnchorPoint(ccp(0, 0));
	m_map->setPosition(ccp(0, 0));
	addChild(m_map, 0);
	//plot::destoryPlot();
}

void BattleSceneView::accountFireBomb(BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, int skillLvId, BattleObject *defender)
{
    int skillGroupId = skill::getSkillId(skillLvId);
    BattleScene *scene = BattleScene::getCurrentScene();
    const GridPosition &gridPosition = defender->getGridPosition();
    cocos2d::CCPoint targetPos = CCPointMake(gridPosition.x, gridPosition.y);
    const vector<int> &v = SKILLLOGIC_MOD_SCOPE(skillGroupId);
    TargetSelect::UnitType targetType = static_cast<TargetSelect::UnitType>(SKILLLOGIC_OBJ_TYPE(skillGroupId));
    float radius = v[0] * 0.5f;
    char party = getOppoParty(attacker->getParty());
    
    std::set<uint16_t> targets;
    calcObjsInCircleRange(&targets, scene->getTerrain(), party, targetType, targetPos, radius);
    
    auto it = targets.find(defender->getId());
    if ( it == targets.end())
    {
        targets.insert(defender->getId());
    }
    
	skill::doSelfFx(BattleScene::kMoveObj, attacker, nullptr, nullptr, skillLvId);
    genSkillBattleReport(attacker, targets, skillLvId, defender->getPixelPosition(), calcHurtAttackProp);
    
    CCPoint point = CCPointMake(defender->getPixelPosition().x, defender->getPixelPosition().y);
    SkillEffectDisplay *pEffect = SkillEffectDisplay::create(skill::getSkillId(skillLvId), 0, 0, point, m_map);
    pEffect->setAttacker(attacker);
    pEffect->setAnchorPoint(ccp(0, 0));
    pEffect->setPosition(point);
    addChild(pEffect, 10);
}

void BattleSceneView::freeSound()
{/*
	if(m_sound)
	{
		m_sound->stop(true);
		AudioMgr::theMgr().getAudio()->freeSound(m_sound);
		m_sound = nullptr;
	}*/
}

void BattleSceneView::playTroopAtmosphereSound()
{
	/*
	if(m_keyOffTroopAtmosphereSoundTime > FLT_EPSILON)
	{
		return;
	}

	freeSound();

	int rand = getRandNum(2, 3);
	char buf[256];
	snprintf(buf, sizeof(buf), "audio/audio/environment/battle_atmosphere_%d", rand);
	if ( AudioMgr::theMgr().getAudio()->createSound(buf, &m_sound ) )
	{
		m_sound->play();
		m_playTroopAtmosphereSoundTime = kPlayTroopAtmosphereSoundTime;
		m_keyOffTroopAtmosphereSoundTime = kKeyoffTroopAtmosphereSoundTime;
	}
	else
	{
		ERROR_MSG("BattleSceneView::playTroopAtmosphereSound: create sound fail: %s", buf);
	}*/
}

void BattleSceneView::addHpChangedValue(cocos2d::Node *node)
{
    if(node == nullptr)
    {
        assert(false);
        return;
    }
    
    m_hpChangedValue->addChild(node);
}

static const float kTurnDownAmbientMusicVolume = 0.5f;
static const float kTurnDownVolumeTime = 4.0f;
static const float kTurnUpVolumeTime = 2.0f;
void BattleSceneView::turnDownAmbientMusicVolume()
{
	if(m_isAmbientMusicVolumeTurnUping)
	{
		return;
	}
	m_turnDownAmbientMusicVolumeTime = kTurnDownVolumeTime;
	
	setAmbientMusicVolume(kTurnDownAmbientMusicVolume);
}

void BattleSceneView::setAmbientMusicVolume(float volume)
{
	IAudioEx * audioEx = AudioMgr::theMgr()->getAudioEx();
	if (audioEx)
	{
		audioEx->setEnvVolume(volume);
		audioEx->setMusicVolume(volume);
	}
	if(m_sound)
	{
		//m_sound->setVolume(volume);
	}
}

void BattleSceneView::updateTurnDownAmbientMusicVolume(float dt)
{
	if(m_isAmbientMusicVolumeTurnUping)
	{
		m_turnUpVolumeElaspedTime += dt;
		float volume = min(1.0f, m_turnUpVolumeElaspedTime * (1.0f - kTurnDownAmbientMusicVolume) / kTurnUpVolumeTime + kTurnDownAmbientMusicVolume);
		
		setAmbientMusicVolume(volume);
		if(m_turnUpVolumeElaspedTime > kTurnUpVolumeTime)
		{
			m_isAmbientMusicVolumeTurnUping = false;
			m_turnUpVolumeElaspedTime = 0.0f;
		}
	}
	else if(m_turnDownAmbientMusicVolumeTime > FLT_EPSILON)
	{
		m_turnDownAmbientMusicVolumeTime -= dt;
		
		if(m_turnDownAmbientMusicVolumeTime < FLT_EPSILON)
		{
			m_isAmbientMusicVolumeTurnUping = true;
			m_turnDownAmbientMusicVolumeTime = 0.0f;
		}
	}
}

void BattleSceneView::onAddSupportGeneral(const SupportGeneralData &data, int moveObjectId)
{
}

void BattleSceneView::onRemoveSupportGeneral(int64_t generalId)
{
}

void BattleSceneView::onAddNewOpenSolider(int soliderTid)
{
}

void BattleSceneView::onOpenCurrentNodeGate()
{
	if (!Director::getInstance()->getIsRender())
		return;
	m_map->removeCurrentNodeGate();
	if (isInThisBattleMode(MainScene::kBattleDungeonTraining))
	{
		int cageNum = m_model->getBattleStatistics().getCageSoldier().size();
		if ( cageNum > m_model->getBattleStatistics().getCageIndex()+1)
		{
			m_model->getBattleStatistics().addCageIndex();

			BattleTroop *troop = m_model->getBattleStatistics().getCurCageTroop();
			troop->setStartDead(true);
		}
	}
}

void BattleSceneView::onRemoveAllNodeGates()
{
	m_map->removeAllNodeGates();
}

void BattleSceneView::onEnemyGroupsRunAway(vector<BattleGroup *> groups)
{/*
	pauseGroupsState(groups);
	CCArray *arr = CCArray::create();
	int index = 1;
	for (auto iter = groups.begin(); iter != groups.end(); ++iter)
	{
		index++;
		CCDelayTime *delay = CCDelayTime::create(0.5f * index);
		CCCallFuncND *callback = CCCallFuncND::create(this,
			std::bind(&BattleSceneView::dealEnemyTroopRunAway, this, (*iter)->getGeneralId(), (*iter)->getTroopId()));
		CCSequence *tmp = CCSequence::createWithTwoActions(delay,callback);
		arr->addObject(tmp);
	}
	CCSequence *seq = CCSequence::create(arr);
	runAction(seq); */ 
	
}
void BattleSceneView::dealEnemyTroopRunAway(int generalId,int troopId)
{
	BattleMoveObject *general = m_model->getMoveObject(generalId);
	assert(general);
	BattleMoveObjectView *generalObjView = getMoveObjectView(general->getId());

	m_model->pause();
	focusTo(generalObjView->getPosition());

	CCDelayTime *delay = CCDelayTime::create(0.4f);
	CCCallFuncND *callback = CCCallFuncND::create(this,[=](void){
		enemyTroopRunAway(generalId,troopId);
		m_model->resume();
	});

	runAction(CCSequence::createWithTwoActions(delay,callback));
}

//所有需要逃跑的group暂停动作
void BattleSceneView::pauseGroupsState(vector<BattleGroup *> groups)
{
	for (auto iter = groups.begin(); iter != groups.end(); ++iter)
	{
		BattleGroup *group = *iter;
		BattleMoveObject *general = m_model->getMoveObject(group->getGeneralId());
		assert(general);
		BattleMoveObjectView *generalObjView = getMoveObjectView(general->getId());
		if (generalObjView)
		{
			general->setSilent(true);
			general->setCloak(true, false);
			general->setInvincible(true);
			general->stopRunning();
			general->setState(BattleObject::kIdle);
		}
		BattleTroop *troop = m_model->getTroop(group->getTroopId());
		assert(troop);
		vector<BattleMoveObject *> mems = troop->getMembers();
		for (auto iter = mems.begin(); iter != mems.end(); ++iter)
		{
			(*iter)->setSilent(true);
			(*iter)->setCloak(true, false);
			(*iter)->setInvincible(true);
			(*iter)->stopRunning();
			(*iter)->setState(BattleObject::kIdle);
		}
	}
}

//处理逃跑的武将和士兵的动作
void BattleSceneView::enemyTroopRunAway(int generalId,int troopId)
{
	BattleMoveObject *general = m_model->getMoveObject(generalId);
	assert(general);
	BattleMoveObjectView *generalObjView = getMoveObjectView(general->getId());
	
	if (generalObjView)
	{
		generalObjView->onSpeak(kSpeakBubble,8339,2);
	}
	BattleTroop *troop = m_model->getTroop(troopId);
	assert(troop);
	vector<BattleMoveObject *> mems = troop->getMembers();
	CCDelayTime *delay = CCDelayTime::create(2.0f);
	CCCallFuncND *callBack = CCCallFuncND::create(generalObjView, [=](void) ->void
	{
		GridPosition pos = m_model->getEnemyBornPosition();
		doEnemyRunToDestAction(generalId,pos);
		vector<BattleMoveObject *> mems = troop->getMembers();
		for (auto iter = mems.begin(); iter != mems.end(); ++iter)
		{
			doEnemyRunToDestAction((*iter)->getId(),pos);
		}
	});
	CCSequence *seq = CCSequence::create(delay,callBack,nullptr);

	generalObjView->runAction(seq);
}
//逃跑到指定位置
void BattleSceneView::doEnemyRunToDestAction(uint16_t id,GridPosition pos)
{
	BattleMoveObject *obj = m_model->getMoveObject(id);
	if (!obj) 
	{
		assert(false);
		return;
	}


	BattleMoveObjectView *objView = getMoveObjectView(obj->getId());


	const float scaleFactor = CCDirector::sharedDirector()->getContentScaleFactor();
	const CCPoint &startPos = objView->getPosition();

	PixelPoint destPos = GridUtil::sharedGridUtil().gridToPix(pos);
	//CCPoint destPoint =CCPoint(destPos.x,destPos.y);
	Size size = getLayer()->getContentSize();
	CCPoint destPoint = ccp(size.width+800,size.height+600);
	obj->setSilent(true);
	obj->setCloak(true, false);
	obj->setInvincible(true);
	obj->stopRunning();
	obj->removeRoute();
	obj->setManualMode(true, true);
	obj->setState(BattleObject::kRun);
	obj->setToward(startPos, destPoint);


	float duration = 5.0f;

	objView->onlyShowMainAndShadow();
	float offsetX = GridUtil::sharedGridUtil().getHalfTileWidth() / scaleFactor;
	CCMoveTo *moveTo = CCMoveTo::create(duration, ccp(destPoint.x-offsetX, destPoint.y));
	CCCallFuncND *func = CCCallFuncND::create(objView, [=](void) ->void
	{
		m_model->disappearEnemyMoveObject(id);
		checkBattleResult();
	});

	objView->runAction(CCSequence::create(moveTo, func, nullptr));
}
static Node *sentryTalkNode()
{
	vector<float> txts = battle_para_cfg::getVector("sentry_speak_text_ids");
	int index = rand() % txts.size(); 
	int textId = int(txts[index]);
	xyui::Layout *layout = xyui::Layout::create("res/new_layout/dialogue_sence.xml");
	assert(layout);
	xyui::Label *txt = static_cast<xyui::Label *>(layout->getChildById(3));
	assert(txt);
	txt->setString(TEXT_ZHCHS(textId));
	xyui::Image *m_imgIcon = static_cast<xyui::Image *>(layout->getChildById(2));
	assert(m_imgIcon);
	xyui::Label *name = static_cast<xyui::Label *>(layout->getChildById(4));
	name->setVisible(false);
	assert(name);
	m_imgIcon->setFile(SOLDIERCOMMON_ICON_SMALL(1));
	m_imgIcon->setVisible(false);
	name->setString(TEXT_ZHCHS(2010));
	return layout;
}
float calDistance(const cocos2d::CCPoint &p1, const cocos2d::CCPoint &p2)
{
	return sqrtf((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}
void BattleSceneView::sentryRunToBarrack()
{
	
}
void BattleSceneView::setAutoTrackingCameraPos(cocos2d::CCPoint cameraPoint)
{
	setPosition(convertToPerfectFocusPos(cameraPoint));
}

void BattleSceneView::setAutoTrackingCameraViewPos(cocos2d::CCPoint viewPoint)
{

	const cocos2d::Size &winSize = cocos2d::Director::sharedDirector()->getWinSize();
	CCPoint pt2(viewPoint.x, viewPoint.y);
	float w = m_model->getWidth() / getScaleFactor()*m_mapScale;
	float h = m_model->getHeight() / getScaleFactor()*m_mapScale;
	if (pt2.x > 0.0f) pt2.x = 0.0f;
	else if (pt2.x < winSize.width - w) pt2.x = winSize.width - w;

	if (pt2.y > m_bottomOffsetPos.y) pt2.y = m_bottomOffsetPos.y;
	else if (pt2.y < (winSize.height - h - m_topOffsetPos.y)) pt2.y = (winSize.height - h - m_topOffsetPos.y);
	setPosition(pt2);


	setPosition(pt2);
}

void BattleSceneView::endInitBattleSceneCameraMove()
{
	if (kBSCTBuilding == m_battleSceneCameraState) return;
	stopActionByTag(kMoveTag);

	m_battleSceneCameraState = KBSCTAuto;
}

void BattleSceneView::setManualCamera()
{
	if (m_battleSceneCameraState != KBSCTAuto) return;

	m_battleSceneCameraState = kBSCTManual;
}
bool BattleSceneView::isAutoTrackingCamera() const
{
	return m_battleSceneCameraState == KBSCTAuto;
}

bool BattleSceneView::getCurrentSceneFocusPos(cocos2d::CCPoint *point)
{
	std::vector<BattleMoveObject *> objects;
	int currentNodeIndex = m_model->getCurrentNodeIndex();

	const auto &friendObjects = m_model->getMoveObjects(kFriendParty);

	for (auto it = friendObjects.cbegin(); it != friendObjects.cend(); ++it)
	{
		if (it->second->getNodeIndex() == currentNodeIndex)
		{
			objects.push_back(it->second);
		}
	}

	const auto &enemyObjects = m_model->getMoveObjects(kEnemyParty);
	for (auto it = enemyObjects.cbegin(); it != enemyObjects.cend(); ++it)
	{
		if (it->second->getNodeIndex() == currentNodeIndex)
		{
			objects.push_back(it->second);
		}
	}

	if (objects.empty())
	{
		return false;
	}

	auto iter = objects.begin();
	float minX, minY, maxX, maxY;
	minX = maxX = (*iter)->getViewPosition().x;
	minY = maxY = (*iter)->getViewPosition().y;
	for (++iter; iter != objects.end(); ++iter)
	{
		const CCPoint &point = (*iter)->getViewPosition();

		if (point.x < minX)
		{
			minX = point.x;
		}
		else if (point.x > maxX)
		{
			maxX = point.x;
		}

		if (point.y < minY)
		{
			minY = point.y;
		}
		else if (point.y > maxY)
		{
			maxY = point.y;
		}
	}

	point->x = (minX + maxX) * 0.5f;
	point->y = (minY + maxY) * 0.5f;

	return true;
}
void BattleSceneView::fromInitBattleSceneCameraToAutoTracking()
{
	if (getParent() != nullptr)
	{
		if (m_battleSceneCameraState != kBSCTInit) return;

		CCPoint pint;
		if (getCurrentSceneFocusPos(&pint))
		{
			stopActionByTag(kMoveTag);
			cocos2d::CCPoint moveEndPoint = convertToPerfectFocusPos(pint);

			float distance = ccpDistance(getPosition(), moveEndPoint);
			float moveTime = distance / BATTLEPARA_VALUE("first_cameramove");
			CCMoveTo *move = CCMoveTo::create(moveTime, moveEndPoint);
			CCCallFuncND *func = CCCallFuncND::create(this, [=]()->void{
				endInitBattleSceneCameraMove();
			});
			CCSequence *sequence = CCSequence::create(move, func, nullptr);
			sequence->setTag(kMoveTag);
			runAction(sequence);
		}
	}
}
