﻿#ifndef _LUA_LOGIC_UTIL_
#define _LUA_LOGIC_UTIL_

#include <stdint.h>
#include <math.h>
#include <vector>
#include <map>
#include "battle/BattleHurt.inl"
#include "platform/CCPlatformMacros.h"
#include <string.h>

class BattleMoveObject;
struct CalcHurtAttackProp;
class GameSoldier;

class LuaLogicVariable
{
public:
	static LuaLogicVariable *theMgr()
	{
		static LuaLogicVariable mgr;
		return &mgr;
	}
	CalcHurtDamage getHurtDamage();
	void setHurtDamage(CalcHurtDamage newhurt);

	GameSoldier* getInitPropModel(){ return m_initPropModel; };
	void setInitPropModel(GameSoldier* value){ m_initPropModel = value; };

	void setInitProp(std::vector<int> value);
	std::vector<int> getInitProp();


	CC_SYNTHESIZE(int, m_initPropTid, InitPropTid);
	CC_SYNTHESIZE(int, m_troopIndex, TroopIndex);
	CC_SYNTHESIZE(bool, m_isMonster, IsMonster);
	CC_SYNTHESIZE(int, m_initPropType, InitPropType);
	CC_SYNTHESIZE(int, m_propSoliderNum, PropSoliderNum);
	CC_SYNTHESIZE(const char*, m_battleResult, BattleResult);
	CC_SYNTHESIZE(const char*, m_serverData, ServerData);
	CC_SYNTHESIZE(const char*, m_svrBattlecalData, BattlecalData);
	CC_SYNTHESIZE(int, m_svrBattlecalDataLen, BattlecalDataLen);
	CC_SYNTHESIZE(const char*, m_retBattlecalResult, BattlecalResult);
	CC_SYNTHESIZE(int, m_retBattlecalResultLen, BattlecalResultLen);
	CC_SYNTHESIZE(bool, m_isDebugMo, IsDebugMo);
	CC_SYNTHESIZE(int, m_nodePort, NodePort);     //战斗节点的端口
	CC_SYNTHESIZE(int, m_nodeIndex, NodeIndex);   //战斗节点的序号

	bool popHeadHttpData();
	bool respHeadHttpData();

	void clearHurt();
	void clearInitProp();

	void addFriendSoldierId(int id);
	void addEnemySoldierId(int id);
	std::map<int, int> getFriendSoldierIds();
	std::map<int, int> getEnemySoldierIds();
	void clearSoldierIds(){ m_friendSoldierIds.clear(); m_enemySoldierIds.clear(); }
private:
	CalcHurtDamage m_calcHurtDamage;
	std::vector<int> m_initPropByLua;
	GameSoldier* m_initPropModel;
	LuaLogicVariable();
	~LuaLogicVariable();

	std::map<int, int> m_friendSoldierIds;
	std::map<int, int> m_enemySoldierIds;
};

class LuaCHelper
{
public:
	static LuaCHelper *theHelper()
	{
		static LuaCHelper helper;
		return &helper;
	}

	void luaCAssert();
	void runLog(const char *log);
	void crashC();
	void pushNotificationFromCpp(std::string title, std::string msg, std::string ext);
	void pushNotificationFromCppOnceLater(std::string title, std::string msg, std::string ext, std::string delaySecond);
	void pushNotificationRepeatEveryDay(std::string title, std::string msg, std::string ext, std::string hour, std::string minutes, std::string second);
	void cancelAllLocalNotificationsFromCpp();
private:
	LuaCHelper();
	~LuaCHelper();
};

namespace LuaLogicUtil
{
	float moveObjUpdateBylua(int objId, float dt);
	float battleUpdateForlua(float dt);
	bool isBattleVictory();
	bool isBattleFail();
	void dealBattleFinished(bool isWin);
	void onBattleTimeChanged(float nowBattleTime);
	void onClickNodeGate(int index);
	void callLuaCalcHurt();
	void onTroopHpChange(int party, int troopId, int num);
	void onCreateTroop(int party, int troopId, bool isMonster, int soldierTid, int num);
	void addSoldierDeadMsg(int soldierTid, bool isMonster);
	void armySoldierHpChange(const char *playerId, int match, int changeNum);

	void callBattleCalculat(char * msgPack, int lenth);

	void onBattleSceneExit();
	void onInitFinish();

	int canTrapTrigger(int tId);
	int doBuildingLuaAction(int tid, int objId);
	int getTowerDefence();
	int getWallDefence();
	int getWallLife();
	int getWallArmor();
	int getTowerAtk();
	int getTowerLife();
	int getTowerArmor();
	int getRandomSeed();
	void sendWildEvent();

	int getNeedCreateTroopSoldiers();

	int startBattleThread();
	int startNetMessageThread();

	bool initBattleobjPropByLua(const std::vector<int> prop);
	bool initBattleBuildingPropByLua();

	int initStaticObjectByLua(int oldTid);
	int getBuildingTypeByLua(int tid);
	int getTrapTidFromLuaWithPosTid(int tid);

	void reInitBattleData();

	const char* textContent(int id);
	const char* stringValue(const char* key);

	//--------------------------------------------------------------------------------------------------
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleMoveObject *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId);

	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId);

	// ----------------------------------------------------------------

	// 下面函数只是为了genSkillBattleReport()模块展开能通过，目前无其他用处(a bit ugly)
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleBuilding *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTower *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void doCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleBuilding *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId);

	template<typename T1, typename T2>
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, T1 attacker, CalcHurtAttackProp *calcHurtAttackProp, T2 defender, int damageType, bool isNormalAttack, int32_t skillLvId)
	{
		doCalcHurt(state, damage, attacker, calcHurtAttackProp, defender, damageType, isNormalAttack, skillLvId);
		LuaLogicVariable::theMgr()->setHurtDamage(*damage);
		callLuaCalcHurt();
		(*damage) = LuaLogicVariable::theMgr()->getHurtDamage();
		LuaLogicVariable::theMgr()->clearHurt();
	}
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleMoveObject *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleTower *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
	void luaCalcHurt(int8_t *state, CalcHurtDamage *damage, BattleTrap *attacker, CalcHurtAttackProp *calcHurtAttackProp, BattleBuilding *defender, int damageType, bool isNormalAttack, int32_t skillLvId);
};

#endif
